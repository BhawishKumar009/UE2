Unit 3 PAGE | 141 Writing a Literature Review

| Pre-unit activity 1: Assess your skills before studying Unit 3   | 143   |
|------------------------------------------------------------------|-------|
| What is a literature review?                                     | 144   |
| Why undertake a literature review?                               | 145   |
| Activity 3.1: Is this literature review effective?               | 146   |
| Steps for preparing the literature review assignments            | 148   |
| Activity 3. 2: Identifying relevant source texts                 | 149   |
| Structure of a self-contained literature review                  | 152   |
| How to cite research evidence                                    | 153   |
| Typology of rhetorical functions of citations                    | 155   |
| Activity 3.3: In-text citations & rhetorical functions           | 157   |
| Synthesising articles                                            | 159   |
| Activity 3.4: Identifying different instances of synthesis       | 159   |
| Language features of a literature review                         | 163   |
| A sample literature review draft/outline (with rubrics)          | 166   |
| A sample literature review (final version) (with rubrics)        | 172   |
| A citation table                                                 | 179   |
| Language features: hedging                                       | 181   |
| Activity 3.5: Describing hedging strategies used in statements   | 185   |
| Activity 3.6: Revise the passage using hedging                   | 186   |
| Verb tenses in a literature review                               | 187   |
| Differences between Academic English and General English         | 188   |
| Activity 3.7: Video Clip - 12 common errors in Academic English  | 188   |
| Academic style language/formal language                          | 189   |
| Activity 3.8: Rewriting sentences in a more academic style       | 194   |
| Activity 3.9: Rewriting sentences in a more academic style       | 195   |
| Activity 3.10: Proofreading, revising and editing                | 195   |
| Activity 3.11: Questions to consider                             | 197   |
| Activity 3.12: Proofreading                                      | 198   |
| Common mistakes/issues in Literature Review                      | 200   |
| Activity 3.13: End-of the-unit survey                            | 206   |
| Self-learning online resources for Unit 3                        | 207   |
| References                                                       | 208   |

Pre-unit activity 1 Assess your skills before studying Unit 3 Below is a list of skills and topics in this unit. Please tick the number that best describes your knowledge of the topic. Tick 5 for 'most knowledgeable' about the topic to 1 for 'least knowledgeable'. 

## Outline Of The Main Topics And Skills

| Topics and skills                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | 5   | 4   | 3   | 2   | 1   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|-----|-----|-----|-----|
| What a literature review is  Reasons for undertaking a literature review Some questions a literature review should  answer Steps in writing a literature review The structure of a self‐contained literature  review Summarising and synthesising the research  findings reported in published studies Identifying different points of view How to cite research evidence In‐text citations & rhetorical functions Language use in literature reviews Differences between academic English and  general English Rewriting sentences in an academic style The language of hedging  Proofreading, revising and editing |     |     |     |     |     |

# What Is A Literature Review?

The ability to critically assess published literature is a skill that all university students should develop as literature review is a specific genre in academic writing. Literature reviews may vary from discipline to discipline or across different level of studies in terms of scope, breadth and depth of analysis, but it is generally understood as an analytical evaluation of previously published literature. The survey of scholarly articles, books or other credible sources presented in a literature review should be relevant to a particular subject, providing a description, summary, synthesis and critical examination of the work. There are a number of circumstances under which you might be asked to write a literature review. It may be a stand-alone unit, a review in its own right or a preface to and justification for engaging in a new research study. Research proposals, honours projects and often theses and dissertations require a review of existing literature. It is, therefore, an essential part of the research process. Have a look at the following quotes explaining what a literature review is:
"A literature review surveys scholarly articles, books and other sources relevant to a particular issue, area of research, or theory, and by so doing, provides a description, summary, and critical evaluation of these works" (Ramdhani et al., 2014). "In the initial stages of research, it helps you to establish the theoretical roots of your study, clarify your ideas and develop your research methodology. Later in the process, the literature review serves to enhance and consolidate your own knowledge base and helps you to integrate your findings with the existing body of knowledge" (Kumar, 2014).

Literature review is an important genre that novice academic writers should master in order to become full members of the academic community. Depending on the contexts, writers may be motivated to write a literature review for different reasons. This unit guides students to explore how to review the literature in academic writing.

## Why Undertake A Literature Review?

The aim of doing a literature review is to find out what is already known about a specific topic. As such the objectives may be
- to summarise recent scholarship on a specific topic;
- to improve understanding of the literature by discovering the relationships among different research studies;
- to form your own views on a research issue and develop arguments to defend your views Here are some of the questions a literature review should answer 1. What issues have the scholars studied regarding this topic? 2. What new knowledge has been created in these studies? 3. What methodological approaches have been taken in these studies? 4. How were data collected and analysed? Which theoretical perspectives or models were adopted? 

5. In what ways do the scholars agree or disagree? How do their findings and arguments relate to one another? 

6. What are the possible limitations or gaps that need to be addressed?

Activity 3.1 Is this literature review effective? Read the following literature review and answer questions 1‐4 below.

Until recently many researchers have shown interest in the field of coastal erosion and the resulting beach profiles. They have carried out numerous laboratory experiments and field observations to illuminate the darkness of this field. Their findings and suggestions are reviewed here.

Jachowski (1964) developed a model investigation conducted on the interlocking precast concrete block seawall. After a result of a survey of damages caused by the severe storm at the coast of USA, a new and especially shaped concrete block was developed for use inshore protection. This block was designed to be used in a revetment type seawall that would be both durable and economical as well as reduce wave run-up and overtopping, and scour at its base or toe. It was proved that effective shore protection could be designed utilising these units. Hom-ma and Horikawa (1964) studied waves forces acting on the seawall which was located inside the surf zone. On the basis of the experimental results conducted to measure waves forces against a vertical wall, the authors proposed an empirical formula of wave pressure distribution on a seawall. The computed results obtained by using the above formula were compared well with the field data of wave pressure on a vertical wall. Selezov and Zheleznyak (1965) conducted experiments on scour of sea bottom in front of harbor seawalls, basing on the theoretical investigation of solitary wave interaction with a vertical wall using Boussinesque type equation. It showed that the numerical results were in reasonable agreement with laboratory experimental data.

(Source: Language Center (2004). *Writing up research: Using the literature.* Asian Institute of Technology.)
1. Which of the questions (listed on page 130) does this literature review answer?

![6_image_0.png](6_image_0.png) 2. Which of the questions (listed on page 130) does this literature review not answer? 3. Which method has the writer used to organise the literature review? 4. Is the text an effective literature review? Why or why not?

![6_image_1.png](6_image_1.png)

Shore protection by sea walls

# Steps For Preparing The Literature Review Assignments

| Step 1   | Choose one topic for your survey/review of the literature out of the ten topics (see the  10 given topics outlined in Unit 1);                                                                                                                                                                                                                                                                                          |
|----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Step 2   | Explore and collect source texts that are credible and relevant using journal article  databases, library catalogues, JSTOR, and Google Scholar (please refer to Unit 1);                                                                                                                                                                                                                                               |
| Step 3   | Read and understand the different themes and research issues addressed in the  literature on the topic;                                                                                                                                                                                                                                                                                                                 |
| Step 4   | Narrow your topic and determine the purpose/scope of your literature review by  selecting a specific research issue and a number of source texts; when choosing the  source texts, read carefully and evaluate what you find. Make sure the source texts are  credible and relevant;                                                                                                                                    |
| Step 5   | Prepare for the first presentation scheduled for week 4 (after the Chinese New Year  holidays);                                                                                                                                                                                                                                                                                                                         |
| Step 6   | Organise the selected sources by looking for patterns and by developing sub‐ themes/sub‐topics. Try to discover relationships between the source texts; look for  major themes, concepts, gaps or disagreements and critically assess the work while  taking notes and paraphrasing the excerpts in order to cite properly and prepare the  citation table (see pp.164 of Unit 3 for an example of the citation table); |
| Step 7   | Prepare the draft of the literature review providing (a) a complete introduction; (b)  topic sentences of each paragraph; (c) and your plan of what supporting details are  covered in the body paragraphs and sources are to be used (see pp.151‐154 of Unit 3  for the requirements of the draft), and submit the draft/outline to Moodle (Deadline:  week 7: 3 March 2023);                                          |
| Step 8   | (optional) Book an appointment with a peer tutor for feedback preferably 2 weeks in  advance (see this link for details: Student‐tutor Writing Consultation Programme  https://lc.hkbu.edu.hk/peertutoring/) (Required) Discuss with your lecturer in a face‐to‐face consultation meeting your  literature review draft/outline (in week 8: 6‐10 March 2023);                                                           |
| Step 9   | Write the final version of the literature review; revise, edit and proofread your work  before submitting it to Moodle (Deadline: week 10: 24 March 2023).                                                                                                                                                                                                                                                              |

Activity 3. 2 Identifying relevant source texts After a preliminary search of the literature, you find yourself interested to read more about the correlation between use of social media and its impact on mental health. Consider the following abstracts of research articles, some of which are more relevant to your topic than others. Which set of articles can be included in your literature review? Please explain why. 

Article 1: Coyne, S. M., Rogers, A. A., Zurcher, J. D., Stockdale, L., & Booth, M. (2020). Does time spent using social media impact mental health?: An eight year longitudinal study. *Computers in* Human Behavior, 104, 106160. 

https://doi.org/10.1016/j.chb.2019.106160 

Many studies have found a link between time spent using social media and mental health issues, such as depression and anxiety. However, the existing research is plagued by cross‐sectional research and lacks analytic techniques examining individual change over time. The current research involves an 8‐ year longitudinal study examining the association between time spent using social media and depression and anxiety at the intra‐individual level. Participants included 500 adolescents who completed once‐ yearly questionnaires between the ages of 13 and 20. Results revealed that increased time spent on social media was not associated with increased mental health issues across development when examined at the individual level. Hopefully these results can move the field of research beyond its past focus on screen time. Article 2: Hunt, M. G., Marx, R., Lipson, C., & Young, J. (2018). No More FOMO: Limiting Social Media Decreases Loneliness and Depression. *Journal of Social and Clinical Psychology, 37*(10), 751– 768. 

https://doi.org/10.1521/jscp.2018.37.10.751 

Introduction: Given the breadth of correlational research linking social media use to worse well‐being, we undertook an experimental study to investigate the potential causal role that social media plays in this relationship. Method: After a week of baseline monitoring, 143 undergraduates at the University of Pennsylvania were randomly assigned to either limit Facebook, Instagram and Snapchat use to 10 minutes, per platform, per day, or to use social media as usual for three weeks. Results: The limited use group showed significant reductions in loneliness and depression over three weeks compared to the control group. Both groups showed significant decreases in anxiety and fear of missing out over baseline, suggesting a benefit of increased self‐monitoring. Discussion: Our findings strongly suggest that limiting social media use to approximately 30 minutes per day may lead to significant improvement in well‐being. Article 3: Syvertsen, T., & Enli, G. (2019). Digital detox: Media resistance and the promise of authenticity. Convergence: *The International Journal of Research into New Media* Technologies, 26(5–6), 1269–1283. https://doi.org/10.1177/1354856519847325

A fascination for the authentic is pervasive in contemporary culture. This article discusses texts recommending digital detox and how these accentuate dilemmas of what it means to be authentically human in the age of constant connectivity. Digital detox can be defined as a periodic disconnection from social or online media, or strategies to reduce digital media involvement. Digital detox stands in a long tradition of media resistance and resistance to new communication technologies, and non‐use of media, but advocates balance and awareness more than permanent disconnection. Drawing on the analysis of 20 texts promoting digital detox: self‐help literature, memoirs and corporate websites, the article discusses how problems with digital media are defined and recommended strategies to handle them. The analysis is structured around three dominant themes emerging in the material: descriptions of temporal overload and 24/7 connectivity, experiences of spatial intrusion and loss of contact with 'real life' and descriptions of damage to body and mind. A second research topic concerns how arguments for digital detox can be understood within a wider cultural and political context. Here, we argue that digital detox texts illuminate the rise of a self‐regulation society, where individuals are expected to take personal responsibility for balancing risks and pressures, as well as representing a form of commodification of authenticity and nostalgia.

Article 4: Wood, N. T., & Mun oz, C. (2020). Unplugged: Digital detox enhances student learning. 

Marketing Education Review, 31(1), 14–25. https://doi.org/10.1080/10528008.2020.1836973 

Technology and new digital media tools can enhance student learning; however, the opposite also can be true. Abstaining from technology and digital media can help students understand how such technology influences consumer behaviour and how marketers may use it. This paper describes the purpose, design, and methods of an unplugged class assignment. Students pledged to abstain from all forms of digital media for 48 consecutive hours to help them develop an appreciation for how digital media influences their behaviour. Students created a video documenting their experiences and applied consumer behaviour concepts. Quantitative and qualitative data support the effectiveness of the project. Opportunities and challenges associated with replicating the assignment in additional marketing classes are discussed. Article 5: Vanman, E. J., Baker, R., & Tobin, S. J. (2018). The burden of online friends: The effects of giving up Facebook on stress and well‐being. *The Journal of Social Psychology, 158*(4), 496– 508. https://doi.org/10.1080/00224545.2018.1453467

People occasionally choose to cut themselves off from their online social network by taking extended breaks from Facebook. This study investigated whether abstaining from Facebook reduces stress but also reduces subjective well‐being because of the resulting social disconnection. Participants (138 active Facebook users) were assigned to either a condition in which they were instructed to give up Facebook for 5 days or continue to use Facebook as normal. Perceived stress and well‐being, as well as salivary cortisol, were measured before and after the test period. Relative to those in the Facebook Normal condition, those in the No Facebook condition experienced lower levels of cortisol and life satisfaction. Our results suggest that the typical Facebook user may occasionally find the large amount of social information available to be taxing, and Facebook vacations could ameliorate this stress—at least in the short term.

# Structure Of A Self-Contained Literature Review

| Literature Review Introduction -   | Identify your topic and establish its importance                                                                                               |                                                                                  |
|------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------|
| -                                  | Define terminology or provide background information if necessary (with  citations)                                                            |                                                                                  |
| -                                  | Include overall themes, ideas, or theories found in the articles with citations                                                                |                                                                                  |
| -                                  | Provide an outline                                                                                                                             |                                                                                  |
| Body                               | -                                                                                                                                              | Focus on one major idea and begin with a topic sentence                          |
| -                                  | Show the similarities or differences between different sources when it is  possible (with citations)                                           |                                                                                  |
| -                                  | Synthesise information accurately from the sources using your own words (e.g.  paraphrasing, reported speech and summarising) (with citations) |                                                                                  |
| -                                  | Use 4‐8 sources                                                                                                                                |                                                                                  |
| Conclusion                         | -                                                                                                                                              | Restate the most significant theme(s) you have found (with citations)            |
| -                                  | Give your opinion/evaluation/analysis of the articles and comment on the  significance of the issue in a wider context                         |                                                                                  |
| References                         | -                                                                                                                                              | List your sources in alphabetical order according to the surnames of the authors |
| -                                  | Use hanging indentations                                                                                                                       |                                                                                  |

# How To Cite Research Evidence

Empirical studies provide the key support for the thesis statement of a Literature Review. These studies need to be cited and discussed in greater detail following a logical structure. Observe how the study Kaur and Mohamad (2017) is cited by taking the following steps.

![12_image_0.png](12_image_0.png)

Mariana (2010) analysed the moves of oral presentations of 23 engineering graduates from four different faculties undergoing industrial training. She analysed the moves based on Seliman's (1996) moves and sub-moves. According to her, most engineering oral presentations adhered to the format prescribed for the introduction and termination sections where sub-moves such as 'greeting the audience' in the introduction section and 'thanking audience' at the termination section were relatively fixed. However, she highlights that it was not easy to determine the moves and sub-moves in the body or content section of the oral presentations mainly because of the differences in the requirements of the tasks set by the faculty. Thus, she claims that the moves in the body section relied on the requirement of the tasks as outlined in the assessment criteria. Overall, she concludes that students had knowledge of the structure of the engineering oral presentations or the 'script knowledge' thus they adhered to the prescribed moves that were fixed in a linear form from introduction, body, conclusion, and termination.

Source: Kaur, K., & Mohamad Ali, A. (2017). Exploring the genre of academic oral presentations: A critical review. 

International Journal of Applied Linguistics and English Literature, 7(1), 152-162. http://dx.doi.org/10.7575/aiac.ijalel.v.7n.1p.152 Read the following extract on student models and academic achievement from Zawacki-Richter et al., (2019) and note how empirical studies are cited effectively. 

## Student Models And Academic Achievement

Many more studies are concerned with profiling students and modelling learning behaviour to predict their academic achievements at the course level. Hussain et al. (2018) applied several machine learning algorithms to analyse student behavioural data from the virtual learning environment at the Open University UK, in order to predict student engagement, which is of particular importance at a large scale distance teaching university, where it is not possible to engage the majority of students in face-to-face sessions. The authors aim to develop an intelligent predictive system that enables instructors to automatically identify low-engaged students and then to make an intervention. Spikol, Ruffaldi, Dabisias, and Cukurova (2018) used face and hand tracking in workshops with engineering students to estimate success in project-based learning. They concluded that results generated from multi- modal data can be used to inform teachers about key features of project-based learning activities. Blikstein et al. (2014) investigated patterns of how undergraduate students learn computer programming, based on over 150,000 code transcripts that the students created in software development projects. They found that their model, based on the process of programming, had better predictive power than the midterm grades. Another example is the study of Babić (2017), who developed a model to predict student academic motivation based on their behaviour in an online learning environment. 

This paragraph begins with a topic sentence that provides an overview of the studies to be reviewed (i.e. focusing on studies concerning how profiling students and modelling learning behaviour can predict academic achievements at the course level). This is followed by information about four studies. The first three studies are presented in a similar manner: one sentence introducing the study followed by another sentence offering more information about the purpose or the findings of the study. The paragraph ends with information about the fourth study reviewed. 

## Typology Of Rhetorical Functions Of Citations

We cite for a variety of purposes. Besides knowing the rules of presenting research evidence, students also need to be familiar with different citation purposes. Bojana Petrić, a British scholar on English for academic purposes, developed a typology of rhetorical functions for citation practices based on the analysis of high-quality and low-quality master theses and found that citations serving certain purposes are more frequently found in higher-rated student essays. To write a literature review of a higher quality, you are encouraged to cite studies to achieve a wider variety of purposes. 

Source: Petrić, B. (2007). Rhetorical functions of citations in high-and low-rated master's theses. *Journal of English for* Academic Purposes, 6(3), 238-253.

| Exemplification (3% vs. 2%)   |
|-------------------------------|

| Citation purpose  and percentages  found in high                       | Definitions              | Realisation                                    |
|-----------------------|--------------------------|------------------------------------------------|
| quality vs. lowquality essays                       |                          |                                                |
| Attribution           | attribute information or | realised as a summary/paraphrase or quotation. |
| activity to an author |                          |                                                |
| (79% vs. 92%)         |                          |                                                |

Example *According to feminist film critic Laura Mulvey's (1975) analysis of the gaze, in binary looking* relations men tend to assume the active role of a looking subject while women tend to be passive objects to be looked at, which in turn supports and symbolises the patriarchal power relations between the sexes. Example *Different adaptive methods are: adaptive ordering, link hiding, link removal, and adaptive link* annotation. Examples of these systems are: MLTutor (Smith & Blandford, 2003), MAS–PLANG (Peña et 

| provide information on     | illustrated as a general statement with a specific   |
|----------------------------|------------------------------------------------------|
| the source(s) illustrating | example                                              |
| the writer's statement.    |                                                      |

al., 2002), KBS‐Hyperbook (Henze & Nejdl, 2001) and ELM–ART (Brusilovsky, Schwarz, & Weber, 1996). 

| Further reference (1% vs. 1%)   |
|---------------------------------|

Source: Schiaffino (2008) https://bit.ly/eteacher2008 Example As regards the problem of student modelling, many works in the two areas discussed above have addressed it (see (Brusilovsky & Peylo, 2003) for a review). These works can be categorised 

| provide                  | further   | in parentheses or a footnote and preceded by "see"   |
|--------------------------|-----------|------------------------------------------------------|
| information on the issue |           |                                                      |

according to different characteristics, such as the content of the student model, the type of student being modelled, how the student model is updated, what the model is used for, among others. 

Source: Schiaffino (2008) https://bit.ly/eteacher2008 Example In further analysis I will rely on Rosemary Henessy's (1998) theorisation of how queer visibility can be appropriated for commodity purposes.

| Application (7% vs. 2%)   |
|---------------------------|

| the writer's authorial decisions that are in the  foreground   |
|----------------------------------------------------------------|

| state                       | what   | works   | are   |
|-----------------------------|--------|---------|-------|
| used in the thesis and  why |        |         |       |

Example Having been in contact with high school life and students gave me a tacit or inarticulate knowledge that helps formulate interview questions in the language of the interviewee now that I 

| make                                     | connections   |
|------------------------------------------|---------------|
| between the cited and  the writer's work |               |

became a "retrospective researcher" (Reinhartz, 1992, p. 27). Example *Although I consider this definition to be useful, I think that due to its general character, it does* 

| Establishment       | of      |
|---------------------|---------|
| links               | between |
| sources (6% vs. 3%) |         |

not say much about the effects of gender in social and institutional relationships.

| Evaluation (6% vs. 1%)   |
|--------------------------|

| the                 | use     | of    | evaluative                    |
|---------------------|---------|-------|-------------------------------|
| language            | ranging | from  | clauses expressing evaluation |
| individual          | words   | (e.g. |                               |
| evaluative adverbs) |         |       |                               |

Example It is often mentioned in migration studies that the loss of the breadwinner role deteriorates 

| use                            | the   | arguments,   | concepts,   | terminology   | or   |
|--------------------------------|-------|--------------|-------------|---------------|------|
| procedures from the cited work |       |              |             |               |      |

men's status within the family and community (Al‐Ali, 2002; Kibria, 1990; Matsuoka & Sorenson, 1999; McSpadden, 1999). Example As in the cases of classical patriarchy (Kandiyoti, 1988), also in a Chechen family the husband's 

| Statement of use (4% vs. 1%)   |
|--------------------------------|

| Comparison   | of                     | indicate   | similarities           | or            |              |       |    |    |                |      |
|--------------|------------------------|------------|------------------------|---------------|--------------|-------|----|----|----------------|------|
| one's        | work                   | with       | differences            | between       | contribution | needs | to | be | differentiated | from |
| those        | of                     | other      | one's own work and the | previous work |              |       |    |    |                |      |
| authors      | works of other authors |            |                        |               |              |       |    |    |                |      |
| (2% vs. 2%)  |                        |            |                        |               |              |       |    |    |                |      |

| point                         | to      | links,   | usually                                           |
|-------------------------------|---------|----------|---------------------------------------------------|
| comparison                    | and     |          |                                                   |
| contrast,                     | between | or       | indicate differences in existing views on a topic |
| among different sources  used |         |          |                                                   |

kin appropriates his wife's labour. 

Activity 3.3

![16_image_0.png](16_image_0.png)

In-text citations & rhetorical functions Read the following extract with a number of in‐text citations and determine the rhetorical functions/purposes of these citations based on the typology above.

An alternative strategy involves the use of corpus linguistic methods to identify and explore recurrent patterns of expression that only become evident when considering large volumes of discourse (Mautner, 2007; Stubbs & Gerbig, 1993). . . . . Mahlberg (2007), for example, explores the phrasal patterns in which the term "sustainable development" is used in the news media. Her analysis identifies eleven different aspects of the term that are socially important enough to merit regular discussion in the press, but which nevertheless embody diverse and often incompatible sets of presuppositions and assumptions about the means and goals of the entire process. . . . . In related work, Piper (2000) examines the systematic differences between the representation of "individuals" and "people" in educational policy. Although their real-world referents are the same, these two terms are construed in characteristically different ways in a policy discourse strongly influenced by neoliberal individualism. The documents were converted to plain text, ignoring all visual information and layout but retaining textual elements such as . . . . This list of terms was used to construct search queries for the software tools employed in the analysis, the corpus toolkit AntConc (Anthony, 2005) and the online Sketch Engine (Kilgarriff et al., 2004). To investigate the textual behavior of each stakeholder, two main methods were employed. . . . . Two collocation measures were computed: Pointwise Mutual Information (PMI), which provides a good index of the strength of association between collocate and node (i.e., whether the occurrence of a term is a good predictor of the occurrence of another); and t-score, which indexes the overall likelihood of the collocation occurring (see chapter 3.5 in Barnbrook et al., 2013, for details). Whether the environment is actually portrayed as a stakeholder in CSR strategy and reporting is, of course, entirely independent of whether it should be so considered. As Laine (2010, p. 77) points out, the issue is hard to decide on purely philosophical terms. 

Source: Lischinsky, A. (2014). What is the environment doing in my report? Analyzing the environment-asstakeholder thesis through corpus linguistics. *Environmental Communication, 9*(4), 539–559. https://doi.org/10.1080/17524032.2014.967705

| Examples of in-text citations   | Rhetorical functions   |
|---------------------------------|------------------------|

## Synthesising Articles

A literature review is not merely descriptive but also must include a synthesis of previous studies. Most often, studies will be reviewed and synthesised in the introduction, discussion or conclusion sections of a paper. Sources should be integrated in order to identify similarities and differences and show how perspectives, findings or discussions fit together. The activities in Unit 2 should be able to prepare you for working on the following activity. 

![18_image_0.png](18_image_0.png)

Identifying different instances of synthesis Each of the paragraphs below has several instances of synthesis. Discuss how the published authors synthesise the ideas and consider how you could re‐use their strategies when you write the Literature Review. The following paragraphs are all authentic extracts from journal papers on the topic of Google Translate. The first one is given to you as an example. 

## Organ (2022)

Although numerous researchers have already explored student attitudes to the use of machine translation in language learning, these studies have largely been case‐study or survey‐based and have also been carried out in higher education settings. Case studies including those by Garcia and Pena (2011), Groves and Mundt (2015), and Kol et al. (2018) have explored how FOMT can be used by university students of English to improve their writing. Among others, Bower (2010), Koros ec (2011), Kumar (2012), Clifford et al. (2013a, 2013b), Sukkhwan (2014), Groves and Mundt (2015), 
Jolley and Maimone (2015), Farzi (2016), Alhaisoni and Alhaysony (2017) and Maulidiyah (2018) 
have carried out surveys of FOMT usage by university students studying European languages (including English) at institutions outside the UK, while Somers et al. (2006) and Nin o (2009) carried out research involving students of modern foreign languages (MFL) in the UK. This is the first study of school‐aged UK students' own FOMT usage (as opposed to tasks given to them), as evidenced by the fact that the majority of the posts relevant to this study concerned GCSEs, with a smaller number from A level students. In the UK, GCSEs are largely taken at the end of year 11 (when students are approximately 16 years of age), and A levels at the end of year 13, (18 years of age).

Source: Organ, A. (2022). Attitudes to the use of Google Translate for L2 production: Analysis of chatroom discussions among UK secondary school students. *The Language Learning Journal,* 1–16. https://doi.org/10.1080/09571736.2021.2023896
(1) Although numerous researchers have already explored student attitudes to the use of machine translation in language learning, these studies have largely been case‐study or survey‐based and have also been carried out in higher education settings.

The first sentence serves as the topic sentence that summarises the next two sentences where the specific studies are reviewed. While there are no in‐text citations in this sentence, the author refers to the researchers and their studies that will be further reviewed.

(2) Case studies including those by Garcia and Pena (2011), Groves and Mundt (2015), and Kol et al. (2018) have explored how FOMT can be used by university students of English to improve their writing.

In the second sentence, a set of similar case studies are reviewed together. To do so, it is essential to identify multiple studies that shared the same methodogical approaches and research objectives. 

(3) Among others, Bower (2010), Koros ec (2011), Kumar (2012), Clifford et al. (2013a, 2013b), Sukkhwan (2014), Groves and Mundt (2015), Jolley and Maimone (2015), Farzi (2016), Alhaisoni and Alhaysony (2017) and Maulidiyah (2018) have carried out surveys of FOMT usage by university students studying European languages (including English) at institutions outside the UK, while Somers et al. (2006) and Nin o (2009) carried out research involving students of modern foreign languages (MFL) in the UK.

In the third sentence, the author lists a set of studies that adopt one approach (survey) to study non‐UK students and are contrasted with two other studies focusing on UK students. 

It is useful to group studies based on the identities of research participants. 

(4) This is the first study of school‐aged UK students' own FOMT usage (as opposed to tasks given to them), as evidenced by the fact that the majority of the posts relevant to this study concerned GCSEs, with a smaller number from A level students. In the UK, GCSEs are largely taken at the end of year 11 (when students are approximately 16 years of age), and A levels at the end of year 13, (18 years of age).

The last sentence serves the purpose of the literature review which is to highlight the novelty of the present study, i.e. investigating a different group of UK students and their FOMT usage. 

Although there is no need to conduct a novel research study for this course, it is important to keep in mind that identifying a gap in the literature to justify a present study is a common reason for reviewing literature. 

## Rowe (2022)

Digital translation tools, such as Google Translate or online bilingual dictionaries, are widely available and easily accessible in classrooms with internet access. A small, emerging body of research examines how teachers and students use such tools as they translate both orally and in text. For instance, Lake and Beisly (2019) suggest that digital translation tools can be used by teachers to connect with emergent bilingual students, by facilitating communication when the teacher does not share all of the language resources of a student. Similarly, Hansen‐Thomas et al. (2021) describe how monolingual teachers used Google Translate to design lesson plans that included the use of multiple languages. Students who were emerging users of a language have also been documented using Google Translate as a tool to communicate with their teachers 
(Prince, 2017) or peers (Hell et al., 2021). In addition to facilitating communication, several scholars suggest that digital translation tools can support emergent bilingual students' English vocabulary acquisition by providing in‐the‐moment translation support (Dalton & Grisham, 2011; Liu et al., 2014; Prince, 2017). Importantly, a few studies suggest that, when writing, students' use of digital translation tools might also support their composing in multiple languages (Hell et al., 2021; Rowe, 2020), although more research is needed describing how students use the tool in this way. 

Source: Rowe, L. W. (2022). Google Translate and biliterate composing: Second‐graders' use of digital translation tools to support bilingual writing. *TESOL Quarterly, 56*(3), 883–906. https://doi.org/10.1002/tesq.3143 Discussion
(S1‐2) Digital translation tools, such as Google Translate or online bilingual dictionaries, are widely available and easily accessible in classrooms with internet access. A small, emerging body of research examines how teachers and students use such tools as they translate both orally and in text. (S3‐4) For instance, Lake and Beisly (2019) suggest that digital translation tools can be used by teachers to connect with emergent bilingual students, by facilitating communication when the teacher does not share all of the language resources of a student. Similarly, Hansen‐Thomas et al. (2021) describe how monolingual teachers used Google Translate to design lesson plans that included the use of multiple languages. (S5‐6) Students who were emerging users of a language have also been documented using Google Translate as a tool to communicate with their teachers (Prince, 2017) or peers (Hell et al., 2021). In addition to facilitating communication, several scholars suggest that digital translation tools can support emergent bilingual students' English vocabulary acquisition by providing in‐the‐moment translation support (Dalton & Grisham, 2011; Liu et al., 2014; Prince, 2017). (S7) Importantly, a few studies suggest that, when writing, students' use of digital translation tools might also support their composing in multiple languages (Hell et al., 2021; Rowe, 2020), although more research is needed describing how students use the tool in this way. 

# Language Features Of A Literature Review

| Rhetorical functions                                                                                                                                               | Sentence patterns                                                                                                                                                                            |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| General comments on the                                                                                                                                            | ‐ Much of the current literature on X pays particular attention to                                                                                                                           |
| relevant literature                                                                                                                                                | …                                                                                                                                                                                            |
| ‐ A large and growing body of literature has investigated … ‐ Different theories exist in the literature regarding …                                               |                                                                                                                                                                                              |
| Previous research:                                                                                                                                                 | ‐ Over the past decade, most research on X has emphasised the                                                                                                                                |
| A historical perspective                                                                                                                                           | use of …                                                                                                                                                                                     |
| ‐ It was not until the late 1960s that historians considered X  worthy of scholarly attention.  ‐ For many years, this phenomenon was surprisingly neglected by  … |                                                                                                                                                                                              |
| Previous research:                                                                                                                                                 | ‐ Using this approach, researchers have been able to …                                                                                                                                       |
| Methodological approaches                                                                                                                                          | ‐ Much of the X research has focused on identifying and                                                                                                                                      |
| taken                                                                                                                                                              | evaluating the …                                                                                                                                                                             |
| ‐ Publications that concentrate on X more frequently adopt a  historical or chronological approach …                                                               |                                                                                                                                                                                              |
| Previous research:                                                                                                                                                 | ‐ A great deal of previous research into X has focused on …                                                                                                                                  |
| Area investigated                                                                                                                                                  | ‐ A number of studies have begun to examine … ‐ Various studies have assessed the efficacy of …                                                                                              |
| Previous research:                                                                                                                                                 | ‐ Several lines of evidence suggest that …                                                                                                                                                   |
| What has been established or                                                                                                                                       | ‐ Many recent studies (e.g. Smith, 2001; Jones, 2005) have shown                                                                                                                             |
| proposed                                                                                                                                                           | that …                                                                                                                                                                                       |
| ‐ There is a consensus among social scientists that … (e.g. Jones,  1987; Johnson, 1990; …                                                                         |                                                                                                                                                                                              |
| Stating what is currently known                                                                                                                                    | ‐ X, Y and Z appear to be closely linked (Smith, 2008).                                                                                                                                      |
| about the topic                                                                                                                                                    | ‐ X has been found to oppose the anti‐inflammatory actions of Y  on Z (Alourfi, 2004). ‐ A relationship exists between an individual's working memory  and their ability to … (Jones, 2002). |

| Reference to a previous                                                                                                                                                                                                    | ‐ XXX investigated the differential impact of formal and non‐                                                                                        |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|
| investigation:                                                                                                                                                                                                             | formal education on …                                                                                                                                |
| Researcher prominent                                                                                                                                                                                                       | ‐ XXX demonstrated that when the maximum temperature is  exceeded … ‐ XXX analysed the data from 72 countries and concluded that …                   |
| Reference to a previous                                                                                                                                                                                                    | ‐ In the 1950s, Gunnar Myrdal pointed to some of the ways in                                                                                         |
| investigation:                                                                                                                                                                                                             | which …                                                                                                                                              |
| Time prominent                                                                                                                                                                                                             | ‐ In 1859, the publication of X had a major impact on … ‐ Almost 20 years ago, Jones (1985) formulated his X theory,  centred around …               |
| Reference to a previous                                                                                                                                                                                                    | ‐ A qualitative study by Smith (2003) described how …                                                                                                |
| investigation:                                                                                                                                                                                                             | ‐ A recent study by Smith and Jones (2012) involved …                                                                                                |
| Investigation prominent                                                                                                                                                                                                    | ‐ The study of the structural behaviour of X was first carried out  by Jones et al. (1986).                                                          |
| Reference to a previous                                                                                                                                                                                                    | ‐ To better understand the mechanisms of X and its effects, Jones                                                                                    |
| investigation:                                                                                                                                                                                                             | (2013) analysed the …                                                                                                                                |
| Topic prominent                                                                                                                                                                                                            | ‐ To determine the effects of X, Jones et al. (2005) compared … ‐ X formed the central focus of a study by Smith (2002) in which  the author found … |
| Reference to what other writers                                                                                                                                                                                            | ‐ By drawing on the concept of X, Smith has been able to show                                                                                        |
| do in their text                                                                                                                                                                                                           | that …                                                                                                                                               |
| ‐ Other authors (see Harbison, 2003; Kaplan, 2004) question the  usefulness of such an approach                                                                                                                            |                                                                                                                                                      |
| Reference to another writer's                                                                                                                                                                                              | ‐ According to Smith (2003), preventative medicine is far more                                                                                       |
| idea or position                                                                                                                                                                                                           | cost effective, and therefore …                                                                                                                      |
| ‐ Smith (2013) concludes that preventative medicine is far more  cost effective, and therefore better adapted to the developing  world. ‐ Smith (2013) proposes an explanatory theory for each type of  irrational belief. |                                                                                                                                                      |
| Synthesising material:                                                                                                                                                                                                     | ‐ This view is supported by Jones (2000) who writes that …                                                                                           |
| Bringing sources together                                                                                                                                                                                                  | ‐ Unlike Smith, Jones (2013) argues that …                                                                                                           |

| ‐ While Smith (2008) focusses on X, Jones (2009) is more  concerned with …   |                                                                                                                                                                                  |
|------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Some ways of introducing                                                     | ‐ Commenting on X, Smith (2003) argues, "… …"                                                                                                                                    |
| quotations                                                                   | ‐ As Carnoy (2004: 215) states, "there are many good reasons to  be sceptical". ‐ In the final part of the Theses on Feuerbach, Marx writes, "Philosophers have hitherto only …" |
| Summarising the review or                                                    | ‐ Overall, these studies highlight the need for …                                                                                                                                |
| parts of the review                                                          | ‐ Taken together, these studies support the notion that … ‐ These studies clearly indicate that there is a relationship  between …                                               |

Source: Academic Phrase Bank https://www.phrasebank.manchester.ac.uk/referring-to-sources/
A sample literature review draft/outline with **reference to the grading** rubrics 

## The Effects Of Digital Detox On Stress Levels

With the ubiquity of smartphones and widespread use of social media, concerns have been raised on the harmful effects of excessive use of digital devices and the time spent on social networking sites, e.g. the link between screen time and health conditions, such as obesity (e.g. Twenge & Campbell, 2018) and depression (e.g. 

Hunt et al., 2018). Digital detoxing, or taking a break from the internet or social media for a varying amount of time, has been advocated as a solution to this The Literature problem (see Radtke et al., 2021, for an overview). Yet scholars disagree on the Review draft extent to which using social media may impact mental health with some finding should include the positive relationships between the time spent on social networking and an introductory mental health problems, e.g. level of depressive symptoms (e.g. Coyne et al., 2020), 
paragraph which and others raising the possibility that people visit social media sites because of students may their mental problems (Hartanto et al., 2021). Studies on the effectiveness of revise after digital detox intervention also yield mixed results as the effects on well‐being meeting with the could be positive or negative (e.g. Radtke et al., 2021). This literature review lecturer for explores the studies on how digital detox interventions might alleviate mental consultation. 

health problems triggered by social media and smartphone users alike, focusing on the levels of stress experienced by those who practice digital detox and those who do not. It is hoped that the findings of the review could contribute to the discovery of the best practices of social media use, and also to the implementation of an effective warning mechanism which could alert users to issues of potentially grave consequences. 

## Plan For Body Paragraph 1

Most studies reviewed suggest that taking a break from the internet (or social media) could reduce the levels of stress.

A topic sentence needs to be given for each This paragraph focuses on studies reporting the positive correlation between digital detox and low stress levels. A few studies will be covered:

| paragraph. The  sources to be  used and how  they are relevant   |
|------------------------------------------------------------------|

- Anrijs et al. (2018): participants experienced significantly lower stress according to their skin conductance response rate during the week when their phones are offline compared to the week when they used social media freely.

- Turel et al.'s (2018) study: taking a break from social media for a short period of time (e.g. a week) can help reduce stress among the participants though results are not statistically significant.

- Turel et al. (2018) study: support the impact of digital detox especially on people who are addicted to social media although the results are not significant.

## Plan For Body Paragraph 2

On the other hand, there are other studies which obtained mixed results from tackling the subject of digital detox. This paragraph focuses on some studies which produced mixed results:
- Vally & D'Souza, 2019; Vanman et al., 2018: Although a break from Facebook reduces stress as reflected on cortisol levels, the participants reported a drop in their subjective well‐being and an increase in negative effects along with loneliness
- Possible explanation: Social connection is a fundamental need for human beings and is also likely to be the prime reason why people join social media; thus, being randomly assigned to do digital detox may make many experimental participants, who are unready to take such a break, become less receptive to this kind of experience and undergo a sudden drop in their own sense of well‐being.

Plan for body paragraph 3 (if any)
should also be outlined clearly. A topic sentence needs to be given for each 

| paragraph. The  sources to be  used and how  they are relevant  should also be  outlined clearly.   |
|-----------------------------------------------------------------------------------------------------|

References

| Anrijs, S., Bombeke, K., Durnez, W., Van Damme, K., Vanhaelewyn, B., Conradie, P.,  Smets, E., Cornelis, J., De Raedt, W., Ponnet, K., & De Marez, L. (2018).  MobileDNA: Relating physiological stress measurements to smartphone  usage to assess the effect of a digital detox. In C. Stephanidis (Ed.), HCI  International 2018 - Posters' Extended Abstracts, 851, 356–363. Springer  International Publishing. https://doi.org/10.1007/978‐3‐319‐92279‐ 9_48 Coyne, S. M., Rogers, A. A., Zurcher, J. D., Stockdale, L., & Booth, M. (2020). Does  time spent using social media impact mental health?: An eight year  longitudinal study. Computers in Human Behavior, 104, 106160.  https://doi.org/10.1016/j.chb.2019.106160  Hartanto, A., Quek, F. Y. X., Tng, G. Y. Q., & Yong, J. C. (2021). Does social media use  increase depressive symptoms? A reverse causation perspective. Frontiers  in Psychiatry, 12, 335. https://doi.org/10.3389/fpsyt.2021.641934  Martino, J., Pegg, J., & Frates, E. P. (2017). The connection prescription: Using the  power of social interactions and the deep desire for connectedness to  empower health and wellness. American Journal of Lifestyle Medicine,  11(6). https://doi.org/10.1177/1559827615608788  Radtke, T., Apel, T., Schenkel, K., Keller, J., & von Lindern, E. (2021). Digital detox:  An effective solution in the smartphone era? A systematic literature  review. Mobile Media & Communication, 10(2), 190–215. https://doi.org/10.1177/20501579211028647  Turel, O., Cavagnaro, D. R., & Meshi, D. (2018). Short abstinence from online  social networking sites reduces perceived stress, especially in excessive  users. Psychiatry Research, 270, 947–953.  https://doi.org/10.1016/j.psychres.2018.11.017  Twenge, J. M., & Campbell, W. K. (2018). Associations between screen time and  lower psychological well‐being among children and adolescents: Evidence  from a population‐based study. Preventive Medicine Reports, 12, 271–283.  https://doi.org/10.1016/j.pmedr.2018.10.003  Vally, Z., & D'Souza, C. G. (2019). Abstinence from social media use, subjective  well‐being, stress, and loneliness. Perspectives in Psychiatric Care, 55(4),  752–759. https://doi.org/10.1111/ppc.12431   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Vanman, E. J., Baker, R., & Tobin, S. J. (2018). The burden of online friends: The effects of giving up Facebook on stress and well‐being. *The Journal of* Social Psychology, 158(4), 496–508. https://doi.org/10.1080/00224545.2018.1453467 

| Literature Review Draft (10%)                                                                                                                                                                                                    |                                                                                                                                                |                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                               |                                                                                                                                 |                                                                                                                                                                                                      |                                                                                                                                                    |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| Marking                                                                                                                                                                                                                          | Excellent                                                                                                                                      | Good                                                                                                                                                                                                                             | Satisfactory                                                                                                                                                                                                                                  | Pass                                                                                                                            | Fail                                                                                                                                                                                                 |                                                                                                                                                    |
| Criteria                                                                                                                                                                                                                         | 15-14 marks                                                                                                                                    | 13-11 marks                                                                                                                                                                                                                      | 10-8 marks                                                                                                                                                                                                                                    | 7 marks                                                                                                                         | 6-0 marks                                                                                                                                                                                            |                                                                                                                                                    |
|  A well‐structured  introduction is complete  with opening sentences to  give background  information and establish  the importance of the  topic being examined, a  clear scope of the review  and a clear structure  outline. |  A structured introduction  with relevant information  prepares readers for  subsequent paragraphs.                                           |                                                                                                                                                                                                                                 | The introduction contains  an acceptable purpose  statement and a structure  outline presented in a  logical order. Some more  relevant background  information could be  included for readers to  understand the  significance of the topic. |                                                                                                                                | The introduction includes  an acceptable purpose  statement but it is  incomplete (e.g. missing  opening sentences,  and/or structure outline).  Information is not  presented in a structured  way. |  The introduction does not  allow readers to have a  clear idea of what the  literature review is about,  or the introduction is  simply missing. |
| Introduction                                                                                                                                                                                                                     |                                                                                                                                               | An engaging  introduction prepares  readers for body  paragraphs effectively.                                                                                                                                                    |                                                                                                                                                                                                                                               |                                                                                                                                 |                                                                                                                                                                                                      |                                                                                                                                                    |
| Marking                                                                                                                                                                                                                          | Excellent                                                                                                                                      | Good                                                                                                                                                                                                                             | Satisfactory                                                                                                                                                                                                                                  | Pass                                                                                                                            | Fail                                                                                                                                                                                                 |                                                                                                                                                    |
| Criteria                                                                                                                                                                                                                         | 20-18 marks                                                                                                                                    | 17-15 marks                                                                                                                                                                                                                      | 14-12 marks                                                                                                                                                                                                                                   | 11-10marks                                                                                                                      | 9-0 marks                                                                                                                                                                                            |                                                                                                                                                    |
|  Very effective use of topic  sentences. They are  accurate, specific and can  clearly address the  purpose statement. They  are also presented in a  logical order as indicated  in the outline.                               |  Effective use of topic  sentences. Most topic  sentences are accurate and  address the purpose  clearly.                                     |  Adequate use of topic  sentences. Some of the  topic sentences are  relevant but they may be  vague.                                                                                                                           |  Inadequate use of topic  sentences. Topic  sentences are attempted  but some are not clear, or  are not relevant in  supporting the thesis or  addressing the topic.                                                                        |  Ineffective use of topic  sentences. They are not  relevant in addressing the  topic, or topic sentences  are simply missing. |                                                                                                                                                                                                      |                                                                                                                                                    |
|  Very effective plan of  relevant points included.  Very clear transition of  paragraphs/ideas.                                                                                                                                |  Effective plan of relevant  points included.  Clear transition of  paragraphs/ideas.                                                        |  Adequate plan of some  relevant points included.   Some attempt of showing  transition of  paragraphs/ideas.  Adequate use of 4‐8  relevant and credible  source texts in addressing  the purpose of the  literature review. |  Few relevant points  included  Transitional phrases are  attempted but they are  not clear.  Inadequate use of 4‐8  source texts. Few source  texts are relevant and  credible.                                                           |  Irrelevant points included.                                                                                                   |                                                                                                                                                                                                      |                                                                                                                                                    |
| Writing Plan/  Research  Evidence                                                                                                                                                                                                |  The links between  paragraphs and ideas are  confusing and not clear.  Ineffective use of 4‐8  sources. They are not  relevant or credible. |                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                               |                                                                                                                                 |                                                                                                                                                                                                      |                                                                                                                                                    |
|  Effective use of 4‐8  relevant and credible  source texts in addressing  the purpose of the  literature review.                                                                                                                |  Good use of 4‐8 relevant  and credible source texts  in addressing the purpose  of the literature review.                                    |  Lack of relevant and  credible research  evidence.                                                                                                                                                                             |                                                                                                                                                                                                                                               |                                                                                                                                 |                                                                                                                                                                                                      |                                                                                                                                                    |

| Marking                                                                 | Excellent                                                                       | Good        | Satisfactory                                                                     | Pass      | Fail                                                                            |                                                                                                         |
|-------------------------------------------------------------------------|---------------------------------------------------------------------------------|-------------|----------------------------------------------------------------------------------|-----------|---------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------|
| Criteria                                                                | 5-4.5 marks                                                                     | 4-3.5 marks | 3 marks                                                                          | 2.5 marks | 2-0 marks                                                                       |                                                                                                         |
|  Sources are accurately  cited in the reference list  using APA style. |  Sources are mostly  accurately cited in the  reference list using APA  style. |            | Sources are sometimes  accurately cited in the  reference list using APA  style. |          | Most sources are not  adequately cited in the  reference list using APA  style. |  The reference list is  inaccurate most of the  time or simply missing.  Sources are not cited at all. |
| Format of  References                                                   |                                                                                 |             |                                                                                  |           |                                                                                 |                                                                                                         |

The total marks you obtained from the marking scheme: 31 out of 40(12+14+5) Your actual marks 7.75 out of 10% (total marks/4) Grade: B+

# A Sample Literature Review (Final Version) With Reference To The Grading

## Rubrics

Read the following literature review and determine its effectiveness by answering the questions that follow.

## The Effects Of Digital Detox On Stress Levels

With the ubiquity of smartphones and widespread use of social media, concerns have been raised on the harmful effects of excessive use of digital devices and the time spent on social networking sites, e.g. the link between screen time and health conditions, such as obesity (e.g. Twenge & Campbell, 2018) and depression (e.g. Hunt et al., 2018). Digital detoxing, or taking a break from the internet or social media for a varying amount of time, has been advocated as a solution to this problem (see Radtke et al., 2021, for an overview). Yet scholars disagree on the extent to which using social media may impact mental health with some finding the positive relationships between the time spent on social networking and mental health problems, e.g. level of depressive symptoms (e.g. Coyne et al., 2020), and others raising the possibility that people visit social media sites because of their mental problems (Hartanto et al., 2021). Studies on the effectiveness of digital detox intervention also yield mixed results as the effects on well‐being could be positive or negative (e.g. Radtke et al., 2021). This literature review explores the studies on how digital detox interventions might alleviate mental health problems triggered by social media and smartphone users alike, focusing on the levels of stress experienced by those who practice digital detox and those who do not. It is hoped that the findings of the review could contribute to the discovery of the best practices of social media use, and also to the implementation of an effective warning mechanism which could alert users to issues of potentially grave consequences. Most studies reviewed suggest that taking a break from the internet (or social media) could reduce the levels of stress. Developing a mobile phone app to collect data on participants' smartphone usage and measuring their stress levels through wearable devices, Anrijs et al. (2018) found that the participants experienced significantly lower stress according to their skin conductance response rate during the week when their phones were offline compared to the week when they used social media freely. Turel et al.'s (2018) study, in which a group of participants was asked to abstain from using Facebook for one week and compared their self‐reported stress levels with those of a control group, also suggests that taking a break from social media for a short period of time (e.g. days or a week) can help reduce the levels of stress among the participants; however, the result is not statistically significant. The findings of Turel et al. (2018) further support the impact of digital detox especially on people who are addicted to social media although the results are not significant either. It is suggested that if heavy social networking sites users are encouraged to practise digital detox, they can benefit more substantially in terms of stress reduction compared to typical users. It seems that a period of disconnection from online platforms is likely to help improve the mental state of people who suffer from stress due to online activities.

On the other hand, there are other studies which obtained mixed results from tackling the subject of digital detox. While Vanman's (2018) team asked one group of participants to stop using Facebook and compared the cortisol levels of their saliva samples with those of the control group, researchers of the 2019 study (Vally & D'Souza, 2019) asked one group of participants to delete social media apps from their mobile phones and the control group to continue using the apps so their stress levels along with levels of well‐being reported through questionnaires could be compared. Although a break from Facebook reduces stress as reflected on cortisol levels, the participants reported a drop in their subjective well‐being (Vally & D'Souza, 2019; Vanman et al., 2018) and an increase in negative effects along with loneliness (Vally & D'Souza, 2019). Social connection is a fundamental need for human beings and is also likely to be the prime reason why people join social media in the first place (Martino et al., 2017); thus, being randomly assigned to do digital detox may make many experimental participants, who are unready to take such a break, become less receptive to this kind of experience and undergo a sudden drop in their own sense of well‐being. In conclusion, stress decline to a varying extent from digital detox has been reported, yet here are several withdrawal symptoms showing that digital detox might have their own negative effects on social media users. Further analysis and study of digital detox and mental well‐being should be conducted in order to provide social media users with more incentives and evidence to reduce digital overuse and find a solution to alleviate active users' dependence upon, or even addiction to, social media, preventing the exacerbation of possible mental health issues. Word count: 794 References Anrijs, S., Bombeke, K., Durnez, W., Van Damme, K., Vanhaelewyn, B., Conradie, P., Smets, E., Cornelis, J., De Raedt, W., Ponnet, K., & De Marez, L. (2018). MobileDNA: Relating physiological stress measurements to smartphone usage to assess the effect of a digital detox. In C. Stephanidis (Ed.), HCI International 2018 - Posters' Extended Abstracts, 851, 356–363. Springer International Publishing. https://doi.org/10.1007/978‐3‐319‐92279‐9_48 Coyne, S. M., Rogers, A. A., Zurcher, J. D., Stockdale, L., & Booth, M. (2020). Does time spent using social media impact mental health?: An eight year longitudinal study. Computers in Human Behavior, 104, 106160. https://doi.org/10.1016/j.chb.2019.106160 Hartanto, A., Quek, F. Y. X., Tng, G. Y. Q., & Yong, J. C. (2021). Does social media use increase depressive symptoms? A reverse causation perspective. *Frontiers in Psychiatry*, 12, 335. https://doi.org/10.3389/fpsyt.2021.641934 Martino, J., Pegg, J., & Frates, E. P. (2017). The connection prescription: Using the power of social interactions and the deep desire for connectedness to empower health and wellness. American Journal of Lifestyle Medicine, 11(6). https://doi.org/10.1177/1559827615608788 Radtke, T., Apel, T., Schenkel, K., Keller, J., & von Lindern, E. (2021). Digital detox: An effective solution in the smartphone era? A systematic literature review. *Mobile Media &* Communication, 10(2), 190–215. https://doi.org/10.1177/20501579211028647 Turel, O., Cavagnaro, D. R., & Meshi, D. (2018). Short abstinence from online social networking sites reduces perceived stress, especially in excessive users. Psychiatry Research, 270, 947–953. https://doi.org/10.1016/j.psychres.2018.11.017 Twenge, J. M., & Campbell, W. K. (2018). Associations between screen time and lower psychological well‐being among children and adolescents: Evidence from a population‐based study. Preventive Medicine Reports, 12, 271–283. https://doi.org/10.1016/j.pmedr.2018.10.003 Vally, Z., & D'Souza, C. G. (2019). Abstinence from social media use, subjective well‐being, stress, and loneliness. *Perspectives in Psychiatric Care*, 55(4), 752–759. https://doi.org/10.1111/ppc.12431 Vanman, E. J., Baker, R., & Tobin, S. J. (2018). The burden of online friends: The effects of giving up Facebook on stress and well‐being. The Journal of Social Psychology, 158(4), 496–508. 

https://doi.org/10.1080/00224545.2018.1453467 Your comments Read the literature review and answer the following questions: 1. How do you find the introduction? 2. Do you have a better understanding of how digital detox reduces one's stress levels after reading the literature review? Why? 3. Are the topic sentences effective? In what way?

4. Are the references cited effectively to achieve the intended purposes?

| Final Literature Review (15%)                                                                                                                                                                                                                                                                                                   |                                                                                                       |                                                                                                      |                                                                                                                                            |                                                                                                                                                         |                                         |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------|
| Marking                                                                                                                                                                                                                                                                                                                         | Excellent                                                                                             | Good                                                                                                 | Satisfactory                                                                                                                               | Pass                                                                                                                                                    | Fail                                    |
| Criteria                                                                                                                                                                                                                                                                                                                        | 15-14 marks                                                                                           | 13-11 marks                                                                                          | 10-8 marks                                                                                                                                 | 7 marks                                                                                                                                                 | 6-0 marks                               |
| - Appropriate source texts  examined and covered in  depth.                                                                                                                                                                                                                                                                     | - Major works included and  generally covered in  depth.                                              | - Some works included but  not necessarily covered in  adequate depth.                               | - Few works included and  not covered in adequate  depth.                                                                                  | - Major works omitted.                                                                                                                                  |                                         |
| - Clear understanding of  the sources of  information selected.                                                                                                                                                                                                                                                                 | - Good understanding of                                                                               | - Satisfactory                                                                                       |                                                                                                                                            |                                                                                                                                                         |                                         |
| original texts.                                                                                                                                                                                                                                                                                                                 | understanding of original  texts.                                                                     | - Inadequate  understanding of original  texts.                                                      | - Misunderstanding of  original texts.                                                                                                     |                                                                                                                                                         |                                         |
| - Effective use of credible  research evidence (4‐8  sources) to achieve  different rhetorical  functions (e.g. attribution,  exemplification, further  reference, statement of  use, application,  evaluation, establishing  links between sources,  comparison of one's own  findings or interpretation  with other sources). | - Good use of credible  research evidence (4‐8  sources) to achieve  different rhetorical  functions. | - Satisfactory use of  research evidence (4‐8  sources) to achieve  different rhetorical  functions. | - Inadequate use of  research evidence (4‐8  sources) to achieve  different rhetorical  functions.                                         | - Ineffective use of research  evidence. Fewer than 4  source texts are used. The  relevance and details of  the research evidence  used are not clear. |                                         |
| Content Marking                                                                                                                                                                                                                                                                                                                 | Excellent                                                                                             | Good                                                                                                 | Satisfactory                                                                                                                               | Pass                                                                                                                                                    | Fail                                    |
| Criteria                                                                                                                                                                                                                                                                                                                        | 15-14 marks                                                                                           | 13-11 marks                                                                                          | 10-8 marks                                                                                                                                 | 7 marks                                                                                                                                                 | 6-0 marks                               |
| - Very clear text structure.  Opening and closing of  the literature review are  very effective.                                                                                                                                                                                                                                | - Clear text structure.  Opening and closing of  the literature review are  effective.                | - Satisfactory text  structure. Opening and  closing of the literature  review are fairly effective. | - Unclear and confusing  text structure with  introduction and/or  conclusion missing or  being mixed up with  other parts.                | - Very confusing text  structure with  introduction and  conclusion missing.                                                                            |                                         |
| Organisation                                                                                                                                                                                                                                                                                                                    | - Very logical and clear  sequencing of main ideas  and supporting  information within  paragraphs.   | - Logical and clear  sequencing of main ideas  and supporting  information within  paragraphs.       | - Sequencing may be  mechanical, with  insufficient attention to  transitions between ideas  and paragraphs. Some  links may be confusing. | - Sequencing may be  occasionally erratic or  illogical.                                                                                                | - Sequencing is erratic and  illogical. |

| - A wide range of cohesive  devices are used  effectively (e.g.  references, synonyms,  substitution and ellipsis).       | - Cohesive devices are used                                                                                    | - Some cohesive devices                                                                                                                          | -                                                                                                                                         | Limited cohesive devices                                                                                                                    | -                                                                                                          | No cohesive devices   |
|---------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|-----------------------|
| effectively.                                                                                                              | are used.                                                                                                      | are used.                                                                                                                                        | attempted.                                                                                                                                |                                                                                                                                             |                                                                                                            |                       |
| Marking                                                                                                                   | Excellent                                                                                                      | Good                                                                                                                                             | Satisfactory                                                                                                                              | Pass                                                                                                                                        | Fail                                                                                                       |                       |
| Criteria                                                                                                                  | 10-9 marks                                                                                                     | 8-7 marks                                                                                                                                        | 6 marks                                                                                                                                   | 5 marks                                                                                                                                     | 4-0 marks                                                                                                  |                       |
| - Excellent level of  grammatical accuracy,  with no or hardly any  grammatical errors.                                   | - Good level of grammatical  accuracy, with occasional  grammatical errors, but  not impede  communication.    | - Satisfactory level of  grammatical accuracy, but  with some grammatical  errors.                                                               | - Low level of grammatical  accuracy with many  grammatical errors.                                                                       | - Extremely low level of  grammatical accuracy  with significant  grammatical errors.                                                       |                                                                                                            |                       |
| - Wide range of sentence  structures including  complex ones.                                                             | - Good range of mostly  accurate complex  structures.                                                          | - Satisfactory range of                                                                                                                          | - Limited range of sentence                                                                                                               | - Very limited range of                                                                                                                     |                                                                                                            |                       |
| sentence structures.                                                                                                      | structures.                                                                                                    | sentence structures.                                                                                                                             |                                                                                                                                           |                                                                                                                                             |                                                                                                            |                       |
| - Effective word choice and  usage with high degree of  sophistication and  precision.                                    | - Wide range of word  choice and usage with  some precision.                                                   | - Satisfactory range of  word choice and usage  with some errors. Some  impediment in  communication. Meaning  may be confusing in some  places. | - Limited range of word  choice and usage with  errors which impede  communication.                                                       | - Very limited range of  word choice and usage  with errors that greatly  impede communication.                                             |                                                                                                            |                       |
| - *Excellent skills in  paraphrasing,  summarising and  synthesising ideas, as  evident in the citation  table submitted. | - *Good skills in  paraphrasing,  summarising and  synthesising, as evident in  the citation table  submitted. | - *Some ability to  paraphrase, summarise  and synthesise, as evident  in the citation table  submitted.                                         | - *Limited ability to  paraphrase, with quite a  few sentences copied  from original texts, as  evident in the citation  table submitted. | - *Much copying from  original texts with little or  no attempt to paraphrase  and summarise, as  evident in the citation  table submitted. |                                                                                                            |                       |
| Language Use                                                                                                              | - Writes formally at all  times (e.g. does not use  contractions, idioms,  slang or personal  pronouns).       | - Writes formally most of  the time (e.g. does not use  contractions, idioms,  slang or personal  pronouns).                                     | - Writes formally on some  occasions (e.g. does not  use contractions, idioms,  slang or personal  pronouns).                             | - Writes in an informal way  most of the time (e.g. uses  contractions, idioms,  slang or personal  pronouns).                              | - Writes in an informal way  at all times (e.g. uses  contractions, idioms,  slang or personal  pronouns). |                       |

| Marking                                                                                                            | Excellent                                                                                                                                      | Good                                                                                               | Satisfactory                                                                                      | Pass                                                                                                           | Fail      |
|--------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|-----------|
| Criteria                                                                                                           | 10-9 marks                                                                                                                                     | 8-7 marks                                                                                          | 6 marks                                                                                           | 5 marks                                                                                                        | 4-0 marks |
| - Sources are always  accurately cited in the  text and accurately listed  in the reference list using  APA style. | - Sources are mostly  accurately cited in the  text and listed in the  reference list using APA  style.                                        | - Sources are sometimes  accurately cited in the  text and in the reference  list using APA style. | - Most sources are not  adequately cited in the  text and in the reference  list using APA style. | - Sources are not cited at  all in the text with the  reference list missing or  inaccurate most of the  time. |           |
| In-text                                                                                                            |                                                                                                                                                |                                                                                                    |                                                                                                   |                                                                                                                |           |
| Citations and  References                                                                                          | - *Only relies on one type  of in‐text citation when  there is a need for other  types of in‐text citation to  achieve the intended  purposes. |                                                                                                    |                                                                                                   |                                                                                                                |           |
| Marking                                                                                                            | Excellent                                                                                                                                      | Good                                                                                               | Satisfactory                                                                                      | Pass                                                                                                           | Fail      |
| Criteria                                                                                                           | 10-9 marks                                                                                                                                     | 8-7 marks                                                                                          | 6 marks                                                                                           | 5 marks                                                                                                        | 4-0 marks |
| - *Excellent choice of in‐ text citation types to  achieve different  purposes.                                    | - *Satisfactory use of in‐ text citation types to  achieve different  purposes.                                                                | - *Inadequate use of in‐text  citation types to achieve  different purposes.                       |                                                                                                   |                                                                                                                |           |
| - *Good choice of in‐text  citation types to achieve  different purposes.                                          |                                                                                                                                                |                                                                                                    |                                                                                                   |                                                                                                                |           |
| - Excellent efforts of  revising the draft by  following the teacher's  feedback.                                  | - Good efforts of revising  the draft by following the  teachers' feedback.                                                                    | - Adequate efforts of  revising the draft by  following the teacher's  feedback.                   | - Some efforts of revising  the draft by following the  teacher's feedback.                       | - Limited or no efforts of  revising the draft.                                                                |           |
| Efforts of  Revising the  Draft                                                                                    |                                                                                                                                                |                                                                                                    |                                                                                                   |                                                                                                                |           |

## Final Submission:

The total marks you obtained from the marking scheme: 45 out of 60 (11+11+9+8+6) Your actual marks 11.25 out of 15 **(total marks/4)** Grade: B+

## * You Can Use Three Types Of In-Text Citation:

a) Integral (Author prominent): Verb controlling. The citation acts as the agent and controls a verb, in active or passive voice. For example, Kennedy et al. 

(2005) reported that parents who reject compulsory vaccination often feel that vaccines are not needed for their children and that their children can overcome infections without the aid of vaccines.

b) Integral (Author prominent): Naming. In naming citations, the citation is a noun phrase or a part of a noun phrase. For example, as indicated by/according to Kennedy et al. (2005), parents who reject compulsory vaccination often feel that vaccines are not needed for their children and that their children can overcome infections without the aid of vaccines.

c) Non-integral (Information prominent): Cite the author's name after the information or at the end of the sentence. For example, parents who reject compulsory vaccination often feel that vaccines are not needed for their children and that their children can overcome infections without the aid of vaccines. (Kennedy et al., 2005)
* You need to:
 submit a citation table (a) demonstrating your understanding of citing sources effectively, and (b) your paraphrasing, summarising and synthesising skills. 

 Please refer to Unit 3 for details. Failing to submit the table together with the literature review assignment may will incur a mark penalty.

## A Citation Table

Students are required to select 5 excerpts (in the form of a table) to demonstrate their understanding of the original sources and their competence to present relevant ideas/findings effectively in achieving the intended purposes. The original sources should be outlined specifically as shown in the following example. Example: A literature review on the effects of digital detox on stress levels

| Original sources                                                                                                                                                                                                                                                                                | Parts paraphrased/synthesised in the                       | Intended purposes                          |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|--------------------------------------------|
| literature review                                                                                                                                                                                                                                                                               |                                                            |                                            |
| Coyne, S. M., Rogers, A. A., Zurcher, J. D., Stockdale, L., &                                                                                                                                                                                                                                   | Yet scholars disagree on the extent to which               | This is put in the introduction to help    |
| Booth, M. (2020). Does time spent using social media                                                                                                                                                                                                                                            | using social media may impact mental health                | readers understand the overall picture     |
| impact mental health?: An eight year longitudinal                                                                                                                                                                                                                                               | with some finding the positive relationships               | (i.e. there are studies reporting that     |
| study. Computers in Human Behavior, 104, 106160.                                                                                                                                                                                                                                                | between the time spent on social networking                | digital detox can help but others not).    |
| https://doi.org/10.1016/j.chb.2019.106160                                                                                                                                                                                                                                                       | and mental health problems, e.g. level of                  | Details will be given in the body          |
| Hartanto, A., Quek, F. Y. X., Tng, G. Y. Q., & Yong, J. C.                                                                                                                                                                                                                                      | depressive symptoms (Coyne et al., 2020), and  paragraphs. |                                            |
| (2021).Does social media use increase depressive symp                                                                                                                                                                                                                                           | others raising the possibility that people visit           |                                            |
| toms? A reverse causation perspective. Frontiers in                                                                                                                                                                                                                                             | social media sites because of their mental                 |                                            |
| Psychiatry, 12, 335.                                                                                                                                                                                                                                                                            | problems (Hartanto et al., 2021)                           |                                            |
| https://doi.org/10.3389/fpsyt.2021.641934  Turel, O., Cavagnaro, D. R., & Meshi, D. (2018). Short  abstinence from online social networking sites reduces  perceived stress, especially in excessive  users. Psychiatry Research, 270, 947–953.  https://doi.org/10.1016/j.psychres.2018.11.017 | Turel et al.'s (2018) study, in which a group of           | This is a summary of Turel et al.'s (2018) |
| participants was asked to abstain from using                                                                                                                                                                                                                                                    | study concerning the methodology and                       |                                            |
| Facebook for one week and compared their                                                                                                                                                                                                                                                        | relevant findings. This is used to                         |                                            |
| self‐reported stress levels with a control                                                                                                                                                                                                                                                      | demonstrate how digital detox can help                     |                                            |
| group, also suggests that taking a break from                                                                                                                                                                                                                                                   | reduce one's stress levels. The results                    |                                            |
| Method: pp. 948 Section 2.2 Findings: pp. 949‐950 Section 3                                                                                                                                                                                                                                     | social media for a short period of time (e.g. a            | are similar to Anrijs et al. (2018).       |
| week) can help reduce stress among the  participants; yet the result is not statistically  significant.                                                                                                                                                                                         |                                                            |                                            |

| "Our findings suggest that if people with strong SNS                                                                                                                                                                                          | It is suggested that if heavy social networking                                              | This is a relevant and specific suggestion   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------|----------------------------------------------|
| addiction‐like symptomology can be convinced to                                                                                                                                                                                               | sites users are encouraged to practice digital                                               | made by the researcher based on the          |
| abstain from social media use (e.g., by parents, teachers,                                                                                                                                                                                    | detox, they can benefit more substantially in                                                | findings that digital detox can reduce       |
| or therapists), they may have much to benefit in terms                                                                                                                                                                                        | terms of stress reduction compared to typical                                                | one's stress levels. This is included in the |
| of stress reduction" (pp. 951, Section 4, third                                                                                                                                                                                               | users (Turel et al., 2018).                                                                  | first body paragraph for illustration.       |
| paragraph) Vally, Z., & D'Souza, C. G. (2019). Abstinence from social                                                                                                                                                                         | On the other hand, both Vanman et al. (2018)                                                 | This is the theme of another body            |
| media use, subjective well‐being, stress, and                                                                                                                                                                                                 | and Vally and D'Souza (2019) obtain a mixed                                                  | paragraph reporting opposite findings        |
| loneliness. Perspectives in Psychiatric Care, 55(4), 752–                                                                                                                                                                                     | result on this issue through their studies on                                                | (i.e. digital detox does not seem to help    |
| 759. https://doi.org/10.1111/ppc.12431                                                                                                                                                                                                        | participants who experimented with digital                                                   | reduce one's stress levels). The             |
| detox.                                                                                                                                                                                                                                        | paragraph focuses on these studies for                                                       |                                              |
| Vanman, E. J., Baker, R., & Tobin, S. J. (2018). The burden                                                                                                                                                                                   | illustration.                                                                                |                                              |
| of online friends: The effects of giving up Facebook on  stress and well‐being. The Journal of Social  Psychology, 158(4), 496–508.  https://doi.org/10.1080/00224545.2018.1453467 Vally, Z., & D'Souza, C. G. (2019). Abstinence from social | Although a break from Facebook reduces                                                       | The findings of these studies show that      |
| media use, subjective well‐being, stress, and                                                                                                                                                                                                 | stress as reflected on cortisol levels, the                                                  | digital detox brings negative effects        |
| loneliness. Perspectives in Psychiatric Care, 55(4), 752–                                                                                                                                                                                     | participants reported a drop in                                                              | instead.                                     |
| 759. https://doi.org/10.1111/ppc.12431                                                                                                                                                                                                        | their subjective well‐being (Vally & D'Souza,  2019; Vanman et al., 2018) and an increase in |                                              |
| Vanman, E. J., Baker, R., & Tobin, S. J. (2018). The burden                                                                                                                                                                                   | negative effects along with loneliness (Vally &                                              |                                              |
| of online friends: The effects of giving up Facebook on                                                                                                                                                                                       | D'Souza, 2019).                                                                              |                                              |
| stress and well‐being. The Journal of Social  Psychology, 158(4), 496–508.  https://doi.org/10.1080/00224545.2018.1453467                                                                                                                     |                                                                                              |                                              |

# Language Features: Hedging

In University English 1, you were introduced to the techniques of hedging to reduce the degree of certainty in academic writing. When writing a literature review, you may also need to use hedging to soften your claims.

Hedges "imply then that the writer is less than fully committed to the certainty of the referential information given….. academic writing involves epistemic modality" (Hyland, 1994, p. 240) Getkham (2011) defined hedging as one mechanism whose main function is managing the tone, attitude, and information within spoken or written discourse.

Why is hedging needed in academic writing?

"Hedges are linguistic devices like 'perhaps', 'I guess' speakers employ to reduce the degree of liability or responsibility they might face in expressing the ideational material" (Mukheef, 2012, p. 754). Hyland (2009) indicates that "hedges imply that a claim is based on plausible reasoning rather than certain knowledge and so both indicate the degree of confidence it might be wise to attribute to a claim while allowing writers to open a discursive space for readers to dispute interpretations" (Hyland, 2009, p. 75) Hyland (2005, p. 80) states that "hedges are devices like might and perhaps, that indicate the writer's decision to withhold complete commitment to proposition, allowing information to be presented as opinion rather than accredited facts".

Hyland (1996) categorised hedges into four groups, explaining how to achieve hedging in academic writing.

1. Writer-oriented hedges
- It is referring to the **relationship between a claim and a writer**.

- It is an attribution to other sources and impersonal expressions to withdraw personal commitment from propositional truth (Hyland, 1996).

- This could be realised by 
(i) impersonal subjects with epistemic speculative verbs (e.g. this chapter/this section will);
(ii) passive;
(iii) hedging strategies such as reference to a wider body of knowledge through the use of non‐integral citations and; 
(iv) reference to information presented earlier in the articles.

e.g. Clearly, vocabulary teaching itself is only one of the "four strands" language courses should include… (Nation, 2008).

## More Examples:

- This again can be discussed in relation to the threshold hypothesis…
- As evidenced in Table 1, there is frequent use of the hesitation marker 'uh'.

- The following sections will discuss the findings in light of the previous research and suggest potential future revenues for language pedagogy and policy.

## 2. Attribute-Oriented Hedges

- It is used by writers to **express claims with precision** by keeping interpretations and deductions close to findings.

- It is neither used to reduce their certainty nor withhold commitment but to present claims with precision.

- This could be realised by 
(i) adverbs (degree of precision such as somewhat or partially); (ii) style disjuncts (e.g. generally), and; (iii) the use of qualification.

e.g. Generally, hard sciences have the label of reliability because they seem to be involved with objective, empirically verifiable knowledge.

More examples:
- The data we draw on in this study (7 questionnaire items) are somewhat limited. 

- Considering the content and structure of the course, a number of factors are likely to have aided.

- The response of the assembly of PSII proteins to be the solute environment is unique in some ways, but quite normal and predictable in others.

## 3. Reliability-Oriented Hedges

- It is used to indicate **the writer's confidence in the truth of a proposition.**
- This could be realised by 
(i) modal verbs (e.g. may); 
(ii) adverbs of certainty (e.g. likely) which weaken the force of an attribute and; (iii) evidential verbs (seems).

e.g. Undergraduate students are likely to pay more attention to tutor feedback on their own writing than to ....

More examples:
- Our study seems to support the notion that ...

- One may criticise that the listing has undergone various stages of filtering ...

## 4. Reader-Oriented Hedges

- It is employed to **mark claims as provisional** and give room for the readers to involve in a dialogue.

- This could be realised by 
(i) first‐person pronouns (e.g. we); (ii) adverbs/sentence modifiers (e.g. Arguably) and; (iii) the hypothetical conditionals (e.g. if) and contrastive connectors (e.g. however). e.g. This holds true even if we take into account the omitted interactions.

More examples:
- Arguably, the interactional markers are not equally distributed. - A word of caution is, however, due here since the explicit teaching of rhetoric and composition is rather uncommon in many non‐Anglophone contexts. 

- English native speakers are also only an option if they hold a degree in the subject they need to teach.

Source: Hyland, K. (1996). Writing without conviction? Hedging in science research articles. *Applied Linguistics, 17*(4), 433-454.

Hedging devices introduced by Salager-Meyer (1997) 1. Modal Auxiliary Verbs - e.g. *may, might, can, could, would, should* 2. Modal Lexical Verbs - e.g. *seem, appear, believe, suggest, assume, indicate* 3. Adjectival, adverbial and nominal modal phrases 
(i) adjectival modal phrases - e.g. *possible, probable, un/likely*

![43_image_0.png](43_image_0.png)

![43_image_1.png](43_image_1.png)

![43_image_2.png](43_image_2.png)

(ii) adverbial modal phrases - e.g. *perhaps, possibly, probably, likely, presumably*
(iii) nominal modal phrases - e.g. *assumption, claim, possibility, estimate*

![43_image_3.png](43_image_3.png)

![43_image_4.png](43_image_4.png)

4. Approximators of degree, frequency, quantity and time - e.g. approximately, roughly, about, 

often, occasionally, generally, usually, somewhat, somehow

![43_image_5.png](43_image_5.png)

5. Introductory phrases - e.g. I believe, I think, I feel, to our knowledge, in my opinion 6. 'If' clauses - e.g*. "if true…" and "if anything…"*
Compound hedges (combine two or more hedges) - e.g. *"it would seem somewhat unlikely"*

![43_image_9.png](43_image_9.png)

Source: Salager-Meyer, F. (1997). I think that perhaps you should: A study of hedges in written scientific discourse. Functional Approaches to Written Text: Classroom Applications, 1, 127-143.

![43_image_6.png](43_image_6.png)

![43_image_7.png](43_image_7.png)

![43_image_8.png](43_image_8.png)

Further readings: Afshar, H. S., & Bagherieh, M. (2014). The use of hedging devices in English and Persian abstracts of Persian literature and civil engineering MA/MS theses of Iranian writers. Procedia - *Social and* Behavioral Sciences, 98, 1820–1827. https://doi.org/10.1016/j.sbspro.2014.03.611 Kim, L. C., & Lim, J. M. H. (2015). Hedging in academic writing - A pedagogically-motivated qualitative study. Procedia - Social and Behavioral Sciences, 197, 600– 607. https://doi.org/10.1016/j.sbspro.2015.07.200 Rezanejad, A., Lari, Z., & Mosalli, Z. (2015). A cross-cultural analysis of the use of hedging devices in scientific research articles. *Journal of Language Teaching and Research*, 6(6), 1384. https://doi.org/10.17507/jltr.0606.29 Weisi, H., & Asakereh, A. (2020). Hedging devices in applied linguistics research papers: Do gender and nativeness matter? *Glottotheory*, 12(1), 71–83. https://doi.org/10.1515/glot-2020-2013 After reviewing relevant studies in the literature on a particular topic, you may want to conclude by summarising the literature about the topic or suggesting what future studies can be conducted for a better understanding of the topic. You may consider using hedging devices to soften your claims in doing so. One strategy of being cautious is to use **'hedging'** or language that is not direct, such as modal verbs (could, may, might), adverbs (probably, likely), adjectives (possible) and nouns (assumption). 

| Activity 3.5                                                                                                                                                 |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Describing hedging strategies used in statements Indicate whether the following sentences have used hedging devices and underline the hedging  devices used. |

| Hedging devices  used? (Yes/No)   |                                                                                                                                                                                                                                                |
|-----------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.                                | These examples appear to give an honest portrayal of the  psychological impact of childhood trauma.                                                                                                                                            |
| 2.                                | The results of this research are in line with Bachman's theory on  psychological trauma in adolescents, thereby disproving Lendl's  theory. Hence, we should not apply Lendl's theory in the context of  Hong Kong for the foreseeable future. |
| 3.                                | The result seems to be related to children's behavioural  characteristics such as hyperactivity and conduct problems.                                                                                                                          |
| 4.                                | Family support appears to improve the internality of parental focus  of control which, as a result, leads to reduction or parental stress.                                                                                                     |
| 5.                                | There is a strong likelihood that the students of Hong Kong fail to  live up to their parents' expectations.                                                                                                                                   |
| 6.                                | The results indicate that the outcome of treatment may not be  favourable because they seek help out of desperation which may in  turn lead to discontinuation of treatment.                                                                   |

Activity 3.6 Revise the passage using hedging The language of the following passage does not conform to the academic style. Its lack of caution gives an impression of simplicity and ignorance. Revise the passage by applying hedging techniques where appropriate.

A team of American scientists have found a way to reverse the ageing process. They fed diet supplements, found in health food shops, to elderly rats, which were then tested for memory and stamina. The animals displayed more active behaviour after taking the supplements, and their memory improved. In addition, their appearance became more youthful and their appetite increased. The researchers say that this experiment is a clear indication of how the problems of old age can be overcome. They state that in a few years' time everyone will be able to look forward to a long and active retirement.

Source: Bailey, S (2011). *Academic writing: A handbook for international students. (3rd ed.)*. Routledge.

Your answer:

## Verb Tenses In A Literature Review

Use verb tenses strategically in your literature review. Study the table below to have a good idea of when to use one of the three main tenses commonly employed in literature reviews.

| When…                        | Tense                      | Purpose                          | Example             |
|------------------------------|----------------------------|----------------------------------|---------------------|
| To view the definition       |                            |                                  |                     |
| Giving a definition          | Present                    | The term…is often                |                     |
| as a permanent fact.         | defined as…                |                                  |                     |
| To emphasise the effect      | The term…has been          |                                  |                     |
| Present perfect              | up to the moment of        | defined as…                      |                     |
| the writing. To regard other |                            |                                  |                     |
| Referring to what has        | authors' ideas as a fact   | Jackson (2006) claims            |                     |
| been said in an in‐text      | Present                    | that stays the same              | that …              |
| citation                     | over time. To regard other | Byram (2003) argued              |                     |
| Past                         | authors' ideas as a past   | that…                            |                     |
| event.                       |                            |                                  |                     |
| Referring to what has        | To describe a complete     | Lee et al. (2005)                |                     |
| been done in an in‐text      | Past                       | action that happened             | conducted a similar |
| citation                     | in the past.               | survey showing… ... represents a |                     |
| Referring to a current       | To describe what is        |                                  |                     |
| Present                      |                            |                                  |                     |
| debate or issue              | significant                |                                  |                     |
| going on currently.          | breakthrough in…           |                                  |                     |
| To describe what was         |                            |                                  |                     |
| Referring to a debate        | previously discussed       | …has long been a key             |                     |
| or issue that has a          | Present perfect            | and is still ongoing to          | issue for many…     |
| lasting effect               | the moment of writing.     |                                  |                     |

# Differences Between Academic English And General English

Activity 3.7 Video Clip - **12 common errors in Academic English** Watch the YouTube video clip "12 Common Errors in Academic English - and how to fix them" and complete the following activity. https://www.youtube.com/watch?v=mZQgd2sPxpk (Duration: 8 minutes)
1. What are the differences between academic English and general English? 2. In academic English or formal writing, we should avoid using the following:

| a.   | (e.g. use 'cannot' instead of 'can't')                                                           |
|------|--------------------------------------------------------------------------------------------------|
| b.   | (e.g. use 'increase' instead of 'go up')                                                         |
| c.   | (e.g. use 'excellent' instead of 'A1')                                                           |
| d.   | (e.g. use 'children' instead of 'kids') (e.g. use 'the graph shows' instead of 'you can see from |
| e.   | the graph')                                                                                      |
| f.   | (e.g. use 'ineffective' instead of 'not effective')                                              |
| g.   | (use 'in conclusion' instead of 'when all is said and done')                                     |
| h.   | (use the correct style)                                                                          |
| i.   | (use 'a considerable amount of' instead of 'a lot of')                                           |
| j.   | (e.g. use 'a major distinction' instead of 'a big difference')                                   |
| k.   | (e.g. use 'according to…' instead of 'I think')                                                  |

## Academic Style Language/Formal Language

An academic style/tone is essential in academic writing, and needs to be **accurate, formal/** impersonal and objective. 

## What Makes A Piece Of Writing Academic? A. Verbs

Use one-part verbs instead of phrasal verbs/prepositional verbs.

| Less formal style                              | Academic style                                     |
|------------------------------------------------|----------------------------------------------------|
| According to some biologists, coming up with   | According to some biologists, offering clear proof |
| clear proof of the decreasing numbers of frogs | of the decreasing numbers of frogs has been        |
| has been difficult.                            | difficult.                                         |

## B. Nouns And Other Parts Of Speech

There are nouns and phrases which are vague and informal too. They should also be avoided in 

| writing.                  | Less formal style   | Academic style   |
|---------------------------|---------------------|------------------|
| Really important          | An integral part of |                  |
| Just about                | Nearly              |                  |
| A lot of                  | Considerable        |                  |
| Got                       | Obtained            |                  |
| Getting bigger and bigger | Increasing          |                  |

## C. Grammar 1. Avoid Contractions

e.g. Export figures won't improve until the economy is stronger.

Export figures will not improve until the economy is stronger.

## 2. Use Formal Negative Forms

Use formal negative forms instead of less formal ones.

| Less formal                                     | More formal                                     |
|-------------------------------------------------|-------------------------------------------------|
| Not…any                                         | No                                              |
| The analysis didn't yield any new results.      | The analysis yielded no new results.            |
| Not…much                                        | Little                                          |
| The government didn't allocate much funding for | The government allocated little funding for the |
| the programme.                                  | programme.                                      |

## D. Avoid "Run-On" Expressions, Such As And So Forth And Etc.

E. **Avoid first person pronouns (i.e. I, we) and second person pronoun (i.e. you)**

## F. Place Adverbs Near The Verb

| Do not Use                           | Use                                                     |
|--------------------------------------|---------------------------------------------------------|
| These semi‐conductors can be used in | These semi‐conductors can be used in robots, CD players |
| robots, CD players, etc.             | and other electronic devices.                           |

| Few This problem has few viable solutions.   |
|----------------------------------------------|

| Do not Use                             | Use                                                   |
|----------------------------------------|-------------------------------------------------------|
| You can see the results in Table 1.    | The results can be seen in Table 1.                   |
| As everyone knows... As we all know…   | This paper will discuss/focus on…                     |
| I would like to discuss….I am going to | It should be emphasised that…/It will be argued that… |
| talk about… As I mentioned before…     | As stated before…                                     |
| In my opinion,                         | It is posited that/It is argued that…                 |

## G. Avoid Sweeping Generalisations

| Less formal                              | More formal                                               |
|------------------------------------------|-----------------------------------------------------------|
| Actually, very little is known about the | Very little is actually known about the general nature of |
| general nature of scientific dishonesty. | scientific dishonesty.                                    |
| This model was developed by Krugman      | This model was originally developed by Krugman (1979).    |
| (1979) originally.                       |                                                           |

| Not…many This problem doesn't have many viable  solutions.   |
|--------------------------------------------------------------|

| Incorrect                             | Correct                                                |
|---------------------------------------|--------------------------------------------------------|
| Every student at our university wants | Roughly half of the students at our university want to |
| to participate in an exchange         | participate in an exchange programme.                  |
| programme.                            |                                                        |

All of the courses offered are boring. Some of the courses offered can often be boring. People never exercise regularly. Some people may not exercise regularly.

H. **Avoid clichés (a cliché is an idea or expression that is overused and unoriginal)**

## I. Avoid Abbreviations J. Nominalisation

| Cliché expressions                       | Alternative                                                      |
|------------------------------------------|------------------------------------------------------------------|
| Nowadays                                 | in this age/in the present day/presently/currently               |
| last but not least                       | in conclusion                                                    |
| in a nutshell                            | to summarise                                                     |
| Hong Kong is an international city.      | Hong Kong is a cosmopolitan city.                                |
| As we all know,..                        | It is common knowledge that…/It has been established  that…      |
| ________________is a hot topic nowadays. | __________________is a subject of much debate in today's  world. |

Nominalisation is the process of converting verb phrases, adjectives or clauses to noun phrases (NP). 

| Abbreviations   | Alternative                 |
|-----------------|-----------------------------|
| BTW             | By The Way                  |
| FYI             | For Your Information        |
| IMHO            | In My Humble/Honest Opinion |
| RSN             | Real Soon Now               |
| TIA             | Thanks In Advance           |

The strategy is effective in increasing the formality and impersonality of the language. 

| Nominalisation Techniques 1. Change active verbs into nouns. - '‐tion'/ '‐ment' / '‐ty' / … - '‐ing' (gerund) - Other noun forms 2. Some adjectives can also be changed into nouns. e.g. unequal ‐> inequality   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

3. Use the structure of:
- The (Adj) N of N (The unequal distribution of resources)
- The (Adj)N to (The full ability to) - The/A (Adj) N in (A marked increase in)
Examples:
1. I handed in my work late because my kids got sick.

Step 1 : Replace informal words
- I submitted my work late because my children were ill.

Step 2 : Apply nominalisation
- Submit (v) ‐> submission (NP)
- My children were ill ‐> my children's illness (NP)
 My children's illness led to the late submission of my work.

2. Because the jobs are more complex, programmes to train staff will take longer.

Step 1 : Replace informal words
- Take longer => increase the duration - Because… => Since Step 2 : Apply nominalisation
- complex => complexity (NP) - Programmes to train staff => training (NP)
 The duration of the training will increase with the complexity of the jobs.

## K. Using Cautious Language

Academic writers need to be cautious about the claims made. Over-generalisation and exaggeration give an impression of simplicity and ignorance.

Cautious Language Examples: Over‐generalisation/inaccuracy: Poor education leads to crime.

➔ 1. Poor education may lead to crime. (modal verb)
2. Poor education often leads to crime. (adverb) 3. Poor education tends to lead to crime. (verb/phrase) 4. There is a tendency for poor education to lead to crime.

## L. Avoiding Redundancy

Redundancy or wordliness is a common problem in academic writing, weakening the accuracy, clarity and conviction of a sentence. 

Avoiding redundancy Examples:
Poor : Homelessness is a global problem in the whole world. Good : Homelessness is a global problem. Poor : In my personal opinion, we must listen to and think over in a careful manner each and every suggestion that is offered to us.

Good : We must consider each suggestion carefully. Even better : The suggestions deserve careful considerations. 

- Redundant pairs (same meaning)
e.g. each and every = each
- Other examples: full and complete, true and accurate, first and foremost, basic and fundamental, questions and problems…
- Redundant modifiers (adjectives/adverbs)
e.g. vitally important = important
- Other examples: (completely) finish, (past) memories, each (individual), (basic) 
fundamentals, (future) plans, (personal) beliefs, consensus (of opinion), (final) outcome…
- Excessive detail e.g. suggestion that is offered to us = suggestion
(As suggestion is by definition something offered to others.)
- Meaningless modifiers e.g. really
- Other examples: kind of, really, basically, actually, generally, certain, particular…
(These modifiers are verbal tics/fillers, but not for concise writing.)
Activity 3.8 Rewriting sentences in a more academic style In teams, rewrite the following sentences in a more academic/ formal style.

1. I will first talk about the two arguments for the provision of free healthcare.

 e.g. The two arguments for the provision of free healthcare will be discussed.

2. This argument is bad. 3. Some research proves that with better health, people can live a longer life. 4. I looked at the reasons leading to the rise in drug addiction among teenagers in Hong Kong. 5. The issue of mandatory retirement is a hot topic nowadays. 6. I will explain the seriousness of the drug addiction problem. 7. Many people will commit crimes if they are given the opportunity to do so. 8. You can clearly see that this argument is fallacious. 9. Students come across difficulties in adapting to university life. 10. I think reality TV is really bad for people's psychological development.

 Activity 3.9 Rewriting sentences in a more academic style Rewrite the following sentences to avoid the use of "you" and "we"
..

You can apply the same theory of learning to small children.

1.

 You can only do this after the initial preparation has been conducted.

2.

3. In the second section of the essay, we will consider the environmental consequences.

## Activity 3.10

Proofreading, revising and editing Have you revised, edited and proofread your work? How are they different?

nn

==
Revising Adding, cutting, re‐writing, reorganising, expanding and clarifying sentences/paragraphs/sections Aims: to sharpen the argument, smoothen the logical flow and enrich the discussion Sentence/section/essay level

## Editing

Rephrasing/improving sentences, altering word choice, changing the order of sentences/paragraphs Aims: to improve the language and tighten the structure Sentence/paragraph level

## Proofreading

Checking for spelling, grammatical errors, incorrect punctuations and errors in following APA conventions Aim: to prevent basic errors Word/sentence level

## Note:

![55_Image_0.Png](55_Image_0.Png)

When we work on our own writing, we must always revise => edit => proofread. There is no point in fixing sentence and word problems when the text has bigger problems. Fix macro‐structure before fixing micro‐structure before fixing grammatical/word choice/spelling/punctuation problems.

Activity 3.11 Questions to consider What are the questions you need to consider when revising, editing and proofreading your work? 

Number the questions as follows.

Revising (A few questions are given for your reference) Everything we do aim towards increasing the clarity, logic, insightfulness and persuasiveness of the essay. 1. Do I have an informative and attractive title? 2. What is/are the new or original insight(s) that my essay offers? __________________________________________________________________________________________________________________ __________________________________________________________________________________________________________________ __________________________________________________________________________________________________________________ __________________________________________________________________________________________________________________ __________________________________________________________________________________________________________________ Editing Editing is about rephrasing/improving sentences, altering word choice, changing the order of sentences/paragraphs. The aims are to improve the language and tighten the structure. 1. Check that the thesis statement is within the scope of the essay topic. 2. Check that the essay body delivers the points/structure promised in the introduction. __________________________________________________________________________________________________________________ __________________________________________________________________________________________________________________ __________________________________________________________________________________________________________________ Proofreading 1. Are there any grammatical mistakes? 2. Are there any inappropriate word choices?

## Activity 3.12

Proofreading Identify and correct the grammatical errors (e.g. subject‐verb agreement, prepositions, linking words, pronouns, plural nouns and comma splices) in the following paragraphs.

| The following paragraphs are taken from a research essay on this topic: Choose one theory in organisational behaviour (e.g. motivation) and evaluate how it is applied in an  organisation you know well.  Introduction (1) It is with a large extent that the practices implemented by ABC Company increases the  motivation of their employees which lead to a low turnover rate and higher performance.  A few motivational theories will be described first followed with the practices of ABC  Company with the application of these theories and the effect these practices have in  employee performance and turnover within the company. Body Paragraphs (2) Hackman and Oldham (1975) are known for their development of the Job Characteristics  Model. In its study, it is emphasized that there are five characteristics in a job: skill variety,  task identity, task significance, autonomy and feedback, which can impact the three critical  psychological states in an employee, the meaningfulness of the work, responsibility for the  work, the quality of outcome and impact of the work. According to Hackman and Oldman,  if jobs were designed with the presence of these five characteristics, the psychological  states occur, and thus work motivation and job satisfaction will be high. PAGE | 198   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| (3)                                                                                                                                                                                                                                                                                                                                                                           | The process theory of Locke and Latham (1990) or the Goal Setting Theory explain how  individuals are motivated. Locke and Latham state that individuals are motivated to work  towards achieving goals. Once individuals set the goals they wish to achieve, the intention  of attaining the goal motivate them to work harder. The goals enhance the performance by  illustrating what type and level or performance is expected or required. As such, if the  individual achieves those goals, they gain job satisfaction and their performance increases.  If they do not achieve the goals, they work harder to achieve them, resulting in an increase  in job performance.                                                                                                                                                                                                                                                                                                                            |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| (4)                                                                                                                                                                                                                                                                                                                                                                           | A form of on‐the‐job‐training that ABC Company encourages is job rotation. The company  gives the opportunity to their employee to rotate through different positions. It is usually  the administrative/support staff and recent graduates/trainees that are assigned to  assume different positions in different divisions. For example, a secretary to a product  development manager is given an opportunity to take up an administrative position in the  HR department. Through job rotation, employees acquire new skill and gain a better  understanding on the different divisions of the company. The greater variety of tasks make  it more challenging for them. It is believed that job rotation is viewed as a mechanism that  increase motivation, as it reduces employees' boredom, keeps them interested in their job  and gives them a sense of belonging (Ortega, 2001). Job rotation contributes to the skill  variety characteristic of Hackman and Oldham's Job Characteristic Model. |
| (5)                                                                                                                                                                                                                                                                                                                                                                           | ABC Company also believes in providing a good work environment, and sports  tournaments such as bowling, swimming, and tennis are held from time to time. All  employee of ABC can participate such tournaments, this helps employees maintain a good  relationship with other staff of the company. The company also celebrates its anniversary  and Christmas every year, organizes annual Open Days filled with an afternoon of fun and  games. These activities are in line with Maslow's social need of relationship with colleague. References                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Hackman, J., & Oldham, G. (1975). Development of the job diagnostic survey. Journal of Applied  Psychology, 60(2), 159‐170. Locke, E. A., & Latham, G. P. (1990). A theory of goal‐setting and task performance. Prentice‐Hall. Ortega, J. (2001). Job rotation as a learning mechanism. Management Science, 47(10), 1361‐1370. https://doi.org/10.1287/mnsc.47.10.1361.10257 |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |

## Common Mistakes/Issues In Literature Review

Please note the following common mistakes/issues found in students' literature review on the topic of digital detox. 

## Synthesising 1. Listing But Not Synthesising Different Source Texts

- In the first article, 'Digital detox: The politics of disconnecting', Syvertsen states that digital detox reclaims the presence, productivity and privacy from internet abuse (2020). Syvertsen stands for digital detox. (2020) In the second article, 'Digital detox: Media resistance and the promise of authenticity', Syvertsen and Enli assure that the practice of digital detox can achieve a balanced media life and thus improve people's performance in workplaces (2020). Syvertsen and Enli support digital detox (2020). In the third article, 'Digital detoxes are a solution looking for a problem', Ellis and Davidson reveal that digital detox lacks scientific supports. 

| -   | In article A, the writer thinks that digital detox is new…..   |
|-----|----------------------------------------------------------------|

In the article B, the writer thinks that sometimes social media do help people to reduce their stress….. Besides, in article C, the writer mentions some of the reasons which may cause depression to the users….. 

- First from the first article: Digital detox: The politics of disconnecting, the writer thinks that digital detox is a good way to let people feel their presence, increase productivity, and protect privacy. Second, according to the second article, digital detox is a method to fight a dangerous trend called digital overload. Third, the point of view ofthe third article is that digital detox has its own unintended negative consequences. 

## Quoting

1. The quote introduced improperly and wrong use of quotation marks 
- The definition of digital detox: 'a period of time during which a person refrains from using electronic devices such as smartphones or computers, regarded as an opportunity to reduce stress or focus on social interaction in the physical world' (Lexico, nd., Definition 1).

## 2. Missing Quotation Marks

- Digital detox means a period of time during which a person refrains from using electronic devices such as smartphones, regarded as an opportunity to reduce stress or focus on social interaction in the physical world (Lexico, nd., Definition 1). 

# Use Of Topic Sentences

1. A topic sentence is not about the opinion of a specific researcher. 

Note the difference between (a) and (b)

## (A) Less Effective Topic Sentences

- First, from the first article: Digital detox: The politics of disconnecting, the writer thinks that digital detox is a good way to let people feel their presence, increase productivity, and protect privacy.

- According to Syvertsen (2020), digital detox should be promoted as it retains the geographical and social presence of online users, preserves productivity and protects privacy. 

- According to Trine S (2020), digital detox helps people reclaim the presence and improve productivity and privacy. 

## (B) More Effective Topic Sentences

- Proponents of digital media claim that restructuring usage of digital devices and social media can be beneficial to one's mental health and productivity. Syvertsen (2020) argues that prolonged usage of digital device and social media could hinder one's ability to socialise physically as interactions are done virtually instead, and worsen one's anxiety and productivity….. 

- First and foremost, one of the biggest benefits of digital detox is enhancing employees' working efficiency. 

- Some experts believe digital detox is necessary and explain that digital detox is bad for people's mental and physical health. 

- Research explains the importance of studying how abstaining from social media affects the mental health of people. One significant advantage is that digital detoxification can develop authenticity in the natural environment (Syvertsen, 2020).

## Use Of Reporting Verbs

1. Fail to note the implications of different reporting verbs (e.g. "point out" and "mention" introduce statements considered factual and are not used to refer to matters of opinion. "Mention" also implies casualness and cannot be used in describing the main point of someone's speech.) 
- Syvertsen (2020) points out digital detox can increase physical human interaction as the digital devices confines people from interacting with each other face‐to‐face. 

- Firstly, Syvertsen (2020) mentioned digital detox helps to strengthen offline communication between people and enhance their relationship. 

2. Wrong spelling (e.g. similar word forms)
- Snow (2017) purpose that the engagement in social media would induce the users to release dopamine due to the sense of excitement. 

## 3. Wrong Use Of Subject

- An opinion opposed by Moen and Bratberg (2015) state that people using digital devices ….. 

## Language Use

1. Verb forms
- As more and more people being dependent on digital devices, digital detox is then applied by them to escape from the digital world. 

- Digital detox helping people regain presence. 

## 2. Word Choice

- In other works, …. (should be words) - Digital overload is a kind of addition. (should be addiction)

## 3. Wrong Use Of Parts Of Speech

- Ravatn (2014, as cited in Syvertsen, 2020) reported that due to a high obsession with using digital media, she feels less motivation of finishing her works. 

- People living on the earth need social with other people. - Digital overload becomes a growing concern that damages people's health in both physically and mentally. 

- Firstly, the researchers find digital detox is importance. - The third article opposites to the first two articles.

## 4. Use Of Be Before Bare Verbs

- It can be show how digital detox plays a key role….. 

## 5. Wrong Use Of The

- It shows that the overuse of digital media will reduce the productivity. - Digital detox plays an important role in the society.

6. Number (e.g. countable/uncountable)
- It is a strong evidence to prove is it beneficial or not.

# Formality

## 1. Use Of Personal Pronouns

- I believe that it is a good solution to online addiction. - Overall I think further studies are needed as digital detox is still a new term to us.

## 2. Contractions

- Social media helps us a lot, but we can't too rely on it. - Screen time doesn't harm a lot.

## 3. Casual Use Of Words

- This essay is going to talk about benefits of digital detox in productivity, presence and mental state.

 

## 4. Wrong Use Of 'You' To Address Readers

- Digital detox is suggested to help you stay away from technology and avoid offline disconnections.

 

## In-Text Citation

1. Redundant journal/book title and missing publication year
- In the first article, 'Digital detox: The politics of disconnecting', Syvertsen states that digital detox reclaims ….. In the second article, 'Digital detox: Media resistance and the promise of authenticity', Syvertsen and Enli assure that the practice of digital detox can….. In the third article, 'Digital detoxes are a solution looking for a problem', Ellis and Davidson reveal that …..

## 2. Redundant First Name (Initials) And Missing Publication Year

- The articles from T. Syvertsen, G Enli, D Ellis and B. Davidson discussed 'Digital Detox'.

3. Redundant full stop for non-integral referencing
- It refers to people quitting technological devices such as smartphones and computers for a period of time. (Syvertson & Enli, 2020).

## 4. Redundant Publication Year Of The Same Work Produced By Two Authors

- Even though Syvertson (2020) and Enli (2020) share similar thoughts about digital detox in improving one self, especially through enhancing one's productivity, Ellis and Davidson (2019) pose great doubt on the vagueness of their studies results.

5. Wrong way of using integral referencing 
- In another article written by Syvertsen and Enli (2020), they agree with the need for digital detox being a method to tackle the problem induced by digital overload such as FOMO.

6. Limited phrases used to introduce integral referencing
- According to…. according to…. according to…

## Reference List

1. No referencing at all 
- The reference list at the end of the literature review is missing.

2. Incorrectly formatted reference list (not APA style) 
(a) Initials of authors' first names missing; should use "&" instead of "and"; month/day of publication not given; title of cited online document not italicised; website name not capitalised; web address of source not given. 

- Ellis and Davidson (2019). Digital detoxes are a solution looking for a problem. The conversation. 

(b) Initials of author's first name missing; title of book not italicised; no page number given. 

- Syvertsen (2020). Digital detox: The politics of disconnecting. Emerald Group Publishing. 

(c) Initials of authors' first names missing; should use "&" instead of "and"; journal title not italicised; volume number, issue number, page number and DOI not given. 

- Syvertsen and Enli (2020). Digital detox: Media resistance and the promise of authenticity. 

Convergence. 

## Conclusion

Less effective conclusion
- To conclude, the similarities and differences of digital detox suggest that there are opinions for and against digital detox.

- To conclude, there are three main benefits of taking digital detox that are enhancing work efficiency, strengthening relationship and resisting internet addiction. 

- In conclusion, according to the findings, it could prove that digital detox is beneficial. There is no need for further studies.

## More Effective Conclusions

- It seems hard to assess whether digital detox is beneficial or not based on the studies. There are arguments for and against digital detox, thus further studies are needed in order to have a deeper discussion on the benefits and necessities of digital detox. 

- In conclusion, digital detox has numerous benefits towards people's mental and physical health according to Syvertsen and Enli (2020) while Ellis and Davidson (2019) consider there is no evidence showing the negative relationship between social media and health of digital users. According to Ellis and Davidson (2019), complete abstinence from social media has been shown to have negative effects on mental health. Therefore, extensive study and research on digital detox and both mental and physical health should be carried out in order to equip social media users with additional incentives and evidence to limit their digital usage. 

Activity 3.13 End-of-the-unit survey This is the end of Unit 3. Please complete the following survey to measure your knowledge.

Read each statement and tick the appropriate box. Please tick your level of understanding on the Likert scale of 1 to 5.

Excellent - 5

![65_image_0.png](65_image_0.png)

![65_image_1.png](65_image_1.png) Good - 4

Satisfactory - 3
Fair - 2 Poor - 1

| Statement                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | 5   | 4   | 3   | 2   | 1   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|-----|-----|-----|-----|
| Writing a Literature Review                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |     |     |     |     |     |
| What a literature review is  Reasons for undertaking a literature review Some questions a literature review should answer Steps in writing a literature review The structure of a self‐contained literature review Summarising and synthesising the research findings  reported in published studies Identifying different points of view How to cite research evidence In‐text citations & rhetorical functions Language use in literature reviews Differences between academic English and general  English Rewriting sentences in an academic style The language of hedging Proofreading, revising and editing |     |     |     |     |     |

# Self-Learning Online Resources For Unit 3

UNSW - **Writing a Literature Review** 

![66_image_0.png](66_image_0.png) https://student.unsw.edu.au/literature‐review This website explains in detail the characteristics of a good literature review.

Monash University- **Stand-alone Literature Review**

![66_image_1.png](66_image_1.png) https://www.monash.edu/rlo/assignment‐samples/assignment‐types/stand‐alone‐ literature‐review This website provides strategies on how to write an effective literature review. In particular, students will learn how to paraphrase and summarise effectively in a literature review.

University of Toronto - The Literature Review - **A few tips on conducting it**

![66_image_2.png](66_image_2.png) http://www.writing.utoronto.ca/advice/specific‐types‐of‐writing/literature‐review This website provides advice on what sources should be used and what should be included in a literature review. 

# References

Anrijs, S., Bombeke, K., Durnez, W., Van Damme, K., Vanhaelewyn, B., Conradie, P., Smets, E., Cornelis, J., De Raedt, W., Ponnet, K., & De Marez, L. (2018). MobileDNA: Relating physiological stress measurements to smartphone usage to assess the effect of a digital detox. In C. Stephanidis (Ed.), HCI International 2018 - Posters' Extended Abstracts, 851, 356–363. Springer International Publishing. https://doi.org/10.1007/978-3-319-92279-9_48 Caffeine in coffee linked with delayed Alzheimer's onset: Study. (2012, June 7). *Huffington Post*. 

http://www.huffingtonpost.com/2012/06/07/ coffee-alzheimers-disease- onsetcaffeine_n_1571090.html Carr, N. (2010, June 5). Does the Internet make you dumber? *The Wall Street Journal.* 
https://www.wsj.com/articles/SB10001424052748704025304575284981644790098 Coyne, S. M., Rogers, A. A., Zurcher, J. D., Stockdale, L., & Booth, M. (2020). Does time spent using social media impact mental health?: An eight year longitudinal study. *Computers in Human Behavior,* 104, 106160. https://doi.org/10.1016/j.chb.2019.106160 Denney, A.S., & Tewksbury, R. (2013). How to write a literature review. Journal of Criminal Justice Education, 24. https://doi.org/10.1080/10511253.2012.730617 Griffith University. (2015, August 26). Learn English - *Hedging and boosting* [Video]. YouTube.

https://www.youtube.com/watch?v=VU-KgiVsAxY
Hartanto, A., Quek, F. Y. X., Tng, G. Y. Q., & Yong, J. C. (2021). Does social media use increase depressive symptoms? A reverse causation perspective. *Frontiers in Psychiatry, 12*, 335. https://doi.org/10.3389/fpsyt.2021.641934 Hunt, M. G., Marx, R., Lipson, C., & Young, J. (2018). No more FOMO: Limiting social media decreases loneliness and depression. *Journal of Social and Clinical Psychology, 37*(10), 751–768. 

https://doi.org/10.1521/jscp.2018.37.10.751 Kaur, K., & Mohamad Ali, A. (2017). Exploring the genre of academic oral presentations: A critical review. *International Journal of Applied Linguistics and English Literature, 7*(1), 152-162. http://dx.doi.org/10.7575/aiac.ijalel.v.7n.1p.152 Kumar, R. (2014). *Research Methodology.* SAGE. Learn English with Rebecca [RebeccaESL] (2015, March 27). *12 Common Errors in Academic English* –
and How to Fix Them [Video]. YouTube. https://www.youtube.com/watch?v=mZQgd2sPxpk Lischinsky, A. (2014). What is the environment doing in my report? Analyzing the environment-asstakeholder thesis through corpus linguistics. *Environmental Communication, 9*(4), 539–559. https://doi.org/10.1080/17524032.2014.967705 Literature review on coastal erosion. (n.d.). 

http://west.asu.edu/aedutto/documents/litreviewexercise.doc Monash University. (n.d.). *Matching introductions and conclusions.*
http://www.monash.edu.au/lls/htmlWord2.php?file=/lls/hdr/write/5.7.8.html Petrić, B. (2007). Rhetorical functions of citations in high-and low-rated master's theses. Journal of English for Academic Purposes, 6(3), 238-253.

Pinker, S. (2010, June 10). Mind over mass media. *The New York Times.* 
http://www.nytimes.com/2010/06/11/opinion/11Pinker.html Poole, R., Kennedy, O.J., Roderick, P., Fallowfield, J.A., Hayes, P.C., & Parkes, J. (2017). Coffee consumption and health: Umbrella review of meta-analyses of multiple health outcomes. British Medical Journal, 359, j5024. https://doi.org/10.1136/bmj.j5024 Radtke, T., Apel, T., Schenkel, K., Keller, J., & von Lindern, E. (2021). Digital detox: An effective solution in the smartphone era? A systematic literature review. *Mobile Media & Communication*, 10(2), 190–215. https://doi.org/10.1177/20501579211028647 Ramdhani, A., Ramdhani, M., & Amin, A. (2014). Writing a Literature Review Research Paper: A stepby-step approach. *International Journal of Basic and Applied Science, 3*. 47-56.

Sifferlin, A. (2015, November 17). How coffee can help you live longer. *TIME.* 
http://time.com/4116129/coffee-longer-life/
Storm, B.C., Stone, S.M., & Benjamin, A.S. (2016). Using the Internet to access information inflates future use of the Internet to access other information. *Memory*, 25(6), 717-723. https://doi.org/10.1080/09658211.2016.1210171 The University of Manchester. (n.d.). *Academic phrase bank*.

https://www.phrasebank.manchester.ac.uk/referring-to-sources/
Turel, O., Cavagnaro, D. R., & Meshi, D. (2018). Short abstinence from online social networking sites reduces perceived stress, especially in excessive users. *Psychiatry Research, 270*, 947–953. https://doi.org/10.1016/j.psychres.2018.11.017 Twenge, J. M., & Campbell, W. K. (2018). Associations between screen time and lower psychological well-being among children and adolescents: Evidence from a population-based study. Preventive Medicine Reports, 12, 271–283. https://doi.org/10.1016/j.pmedr.2018.10.003 University of New South Wales. (n.d.). *Some general criteria for evaluating texts*. 

https://student.unsw.edu.au/some-general-criteria-evaluating-texts University of Queensland. (n.d.). *Examples of critical analysis*. http://www.uq.edu.au/studentservices/learning/examples-critical-analysis Vally, Z., & D'Souza, C. G. (2019). Abstinence from social media use, subjective well‐being, stress, and loneliness. *Perspectives in Psychiatric Care*, 55(4), 752–759. https://doi.org/10.1111/ppc.12431 Vanman, E. J., Baker, R., & Tobin, S. J. (2018). The burden of online friends: The effects of giving up Facebook on stress and well-being. *The Journal of Social Psychology, 158*(4), 496–508. https://doi.org/10.1080/00224545.2018.1453467