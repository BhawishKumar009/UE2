Unit 2 PAGE | 68 Exploring the Unknown Academic World

| What are the skills that are needed in academic writing?                                                                                                                                                                                                   | 70   |     |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------|-----|
| Activity 2.1: Are they acceptable?                                                                                                                                                                                                                         | 70   |     |
| Activity 2.2: Quoting                                                                                                                                                                                                                                      | 72   |     |
| Activity 2.3: Paraphrasing                                                                                                                                                                                                                                 | 89   |     |
| Activity 2.4: Summarising                                                                                                                                                                                                                                  | 94   |     |
| Summarising steps                                                                                                                                                                                                                                          | 94   |     |
| Activity 2.5: Differences between summarising and paraphrasing?                                                                                                                                                                                            | 97   |     |
| Activity 2.6: Summarising Skills Check                                                                                                                                                                                                                     | 99   |     |
| Synthesising information from different sources                                                                                                                                                                                                            | 100  |     |
| Activity 2.7: Writing a synthesis                                                                                                                                                                                                                          | 105  |     |
| Useful Phrases/Expressions for Synthesis Writing                                                                                                                                                                                                           | 108  |     |
| Activity 2.8: Academic Word List (AWL)                                                                                                                                                                                                                     | 110  |     |
| Activity 2.9: Collocation                                                                                                                                                                                                                                  | 120  |     |
| Reporting Verbs                                                                                                                                                                                                                                            | 121  |     |
| Activity 2.10: Reporting verbs                                                                                                                                                                                                                             | 123  |     |
| Activity 2.11: Reporting verbs/signal phrases used in a literature review                                                                                                                                                                                  |      | 125 |
| Activity 2.12: Revising the Paragraph                                                                                                                                                                                                                      | 128  |     |
| Use of tenses in academic writing                                                                                                                                                                                                                          | 130  |     |
| Use of three types of in-text citation in your Literature Review and Argumentative  Research Paper 132 Activity 2.13: In-text citation practice 133 Activity 2.14: End-of-the-unit survey 135 Self-learning online resources for Unit 2 136 References 138 |      |     |

Engagement: 

# What Are The Skills That Are Needed In Academic Writing?

Do you have fear about exploring new academic topics? How does your fear stem from?

University policy on plagiarism Plagiarism is not tolerated at Hong Kong Baptist University (HKBU). Should a case of plagiarism be established, University regulations will be strictly applied. Please check https://ar.hkbu.edu.hk/quality-assurance/university-policy-and-guidelines/academic-integrity for details regarding regulations. You should have also finished a requirement to take a plagiarism quiz in the beginning of the second semester. 

You are encouraged to read the plagiarism booklet developed by HKBU Language Centre. It is available on Moodle (All sections --> course material of UEII) or you can visit the link as follows: https://lcsystem.hkbu.edu.hk/newmain/flipbook/2022/Avoid-Plagiarism/ You are also encouraged to visit and use the Trails of Integrity and Ethics developed by the Centre for Holistic Teaching and Learning at HKBU. The link is as follows: https://chtl-bu.hkbu.edu.hk/nso/AY2223-student/\#aie-ap Activity 2.1 Discussion Fear about doing academic research and solutions at the university. 

My fear

How common is this 

fear among your new 

Solutions

1. Fear of starting a new topic 2. Fear of using unknown technologies 3. Fear of not meeting the academic 'standards'? 4. Fear of not understanding things and appearing ignorant to your professors 5. Fear of not knowing the answers 6. Fear of reading the long sentences, the statistics and the abstract ideas. 7. Fear of writing the next…and the next sentences. 

![3_image_0.png](3_image_0.png) It is like pulling your tooth out.

## Habits Of Mind…

Academic writing is not just about writing skills, but an exploration, thinking process, and after that you should have felt I have done it! The essence of academic writing is putting ideas down on paper, **clear, lucid ideas that interest** the reader. If you are only obsessed about words and and University English II does exactly that to support your writing about the unknown. 

Adapted from: Bailey, S. (2011). Academic writing: A handbook for international students (3rd *ed.)*. Routledge.

![4_image_0.png](4_image_0.png)

A Gateway takes you through a series of readings and interesting ideas and thoughts. If you are attempting this Gateway in your writing, you will be reading a lot about artificial intelligence, intelligence, and society in the future. However, your guide (teacher) will only be able to read with you the debut readings.

![4_image_2.png](4_image_2.png)

![4_image_1.png](4_image_1.png)

render s
How could you characterise an intelligent person from an unintelligent person? What are the smart features of your phone? Why? What is the most intelligent software you have ever used. Introduce it to the class. What is intelligence, in general, and in your field of study? Please read a section from this debut article. 

In our exploration of the future of intelligence, we want to tak maximally broad and inclusive view, not limited to the sorts of inp ligence that exist so far. That's why the definition I gave in the I,
chapter, and the way I'm going to use the word throughout this bod is very broad:

## Intelligence = Ability To Accomplish Complex Goals

This is broad enough to include all above-mentioned definition since understanding, self-awareness, problem solving, learning, es are all examples of complex goals that one might have. It's also brow enough to subsume the Oxford Dictionary definition—"the ability, acquire and apply knowledge and skills"—since one can have as a go to apply knowledge and skills.

Because there are many possible goals, there are many possible types of intelligence. By our definition, it therefore makes no sens to quantify intelligence of humans, non-human animals or maching by a single number such as an IQ. What's more intelligent: a com puter program that can only play chess or one that can only play Ge There's no sensible answer to this, since they're good at differen things that can't be directly compared. We can, however, say that; third program is more intelligent than both of the others if it's at lear as good as them at accomplishing all goals, and strictly better at a least one (winning at chess, say).

It also makes little sense to quibble about whether something is a isn't intelligent in borderline cases, since ability comes on a spectrun and isn't necessarily an all-or-nothing trait. What people have the ability to accomplish the goal of speaking? Newborns? No. Radio hosts? Yes. But what about toddlers who can speak ten words? Or five hundred words? Where would you draw the line? I've used the deliberately vague word "complex" in the definition above, because it's not very interesting to try to draw an artificial line between intel To see this, imagine how you'd react if someone claimed that the ability to acomplish Olympic-level athletic feats could be quantified by a single number called the
"athletic quotient," or AQ for short, so that the Olympian with the highest M

![5_image_0.png](5_image_0.png)

ligence and non-intelligence, and it's more useful to simply quantify the degree of ability for accomplishing different goals.

To classify different intelligences into a taxonomy, another crucial distinction is that between narrow and broad intelligence. IBM's Deep Blue chess computer, which dethroned chess champion Garry Kasparov in 1997, was only able to accomplish the very narrow task of playing chess—despite its impressive hardware and software, it couldn't even beat a four-year-old at tic-tac-toe. The DQN AI system of Google DeepMind can accomplish a slightly broader range

## 52   Life 3.0

of goals: it can play dozens of different vintage Atari compu, games at human level or better. In contrast, human intelligence thus far uniquely broad, able to master a dazzling panoply of skills healthy child given enough training time can get fairly good not on at any game, but also at any language, sport or vocation. Comps, ing the intelligence of humans and machines today, we humans wi hands-down on breadth, while machines outperform us in a sma but growing number of narrow domains, as illustrated in figure 2.1 The holy grail of AI research is to build "general AI" (better know as artificial general intelligence, AGI) that is maximally broad: able , accomplish virtually any goal, including learning. We'll explore th in detail in chapter 4. The term "AGI" was popularized by the a researchers Shane Legg, Mark Gubrud and Ben Goertzel to mon specifically mean buman-level artificial general intelligence: the abl ity to accomplish any goal at least as well as humans. 1 I'll stick with their definition, so unless I explicitly qualify the acronym (by wit ing "superhuman AGI," for example), I'll use "AGI" as shorthand for
"human-level AGI."'
Although the word "intelligence" tends to have positive connots.

tions, it's important to note that we're using it in a completely value neutral way: as ability to accomplish complex goals regardless of whether these goals are considered good or bad. Thus an intelligen person may be very good at helping people or very good at hurting people. We'll explore the issue of goals in chapter 7. Regarding goals we also need to clear up the subtlety of whose goals we're referring to. Suppose your future brand-new robotic personal assistant has m goals whatsoever of its own, but will do whatever you ask it to do and you ask it to cook the perfect Italian dinner. If it goes online and researches Italian dinner recipes, how to get to the closest supermarket, how to strain pasta and so on, and then successfully buys the ingredients and prepares a succulent meal, you'll presumably consider it intelligent even though the original goal was yours. In fact it adopted your goal once you'd made your request, and then brok

![6_image_0.png](6_image_0.png)

elevation represents difficulty for computers, and the rising sea level represents what computers are able to do.

it into a hierarchy of subgoals of its own, from paying the cashier to grating the Parmesan. In this sense, intelligent behavior is inexorably linked to goal attainment.

It's natural for us to rate the difficulty of tasks relative to how hard it is for us humans to perform them, as in figure 2.1. But this can give a misleading picture of how hard they are for computers. It feels much harder to multiply 314,159 by 271,828 than to recognize a friend in a photo, yet computers creamed us at arithmetic long before I was born, while human-level image recognition has only recently become possible. This fact that low-level sensorimotor tasks seem easy despite requiring enormous computational resources is known as Moravec's paradox, and is explained by the fact that our brain makes such tasks feel easy by dedicating massive amounts of customized hardware to them—more than a quarter of our brains, in fact.

I love this metaphor from Hans Moravec, and have taken the liberty to illustrate it in figure 2.2:
Computers are universal machines, their potential extends uniformly over a boundless expanse of tasks. Human potentials, on the other hand, are strong in areas long important for survival, but weak in things far removed. Imagine a "landscape of human competence," having lowlands with labels like "arithmetic" and "rote memorization," foothills like "theorem proving" and "chess play.

ing," and high mountain peaks labeled "locomotion," "hand-eye coordination" and "social interaction." Advancing computer per. formance is like water slowly flooding the landscape. A half century ago it began to drown the lowlands, driving out human calculators and record clerks, but leaving most of us dry. Now the flood has reached the foothills, and our outposts there are contemplatin 2 retreat. We feel safe on our peaks, but, at the present rate, those too will be submerged within another half century. I propose that we build Arks as that day nears, and adopt a seafaring life! 2 During the decades since he wrote those passages, the sea lev has kept rising relentlessly, as he predicted, like global warming a steroids, and some of his foothills (including chess) have long sing been submerged. What comes next and what we should do about it the topic of the rest of this book.

As the sea level keeps rising, it may one day reach a tipping point triggering dramatic change. This critical sea level is the one comsponding to machines becoming able to perform AI design. Before this tipping point is reached, the sea-level rise is caused by buman improving machines; afterward, the rise can be driven by machine improving machines, potentially much faster than humans could have done, rapidly submerging all land. This is the fascinating and cos troversial idea of the singularity, which we'll have fun exploring in chapter 4.

Computer pioneer Alan Turing famously proved that if a computer can perform a certain bare minimum set of operations, then, give enough time and memory, it can be programmed to do anything that any other computer can do. Machines exceeding this critical thresh old are called universal computers (aka Turing-universal computers); a of today's smartphones and laptops are universal in this sense. Anale gously, I like to think of the critical intelligence threshold required for AI design as the threshold for universal intelligence: given enough time and resources, it can make itself able to accomplish any goal a well as any other intelligent entity. For example, if it decides thati wants better social skills, forecasting skills or AI-design skills, it cn acquire them. If it decides to figure out how to build a robot factory, then it can do so. In other words, universal intelligence has the potential to develop into Life 3.0.

The conventional wisdom among artificial intelligence researchers is that intelligence is ultimately all about information and computation, not about flesh, blood or carbon atoms. This means that there's no fundamental reason why machines can't one day be at least as intelligent as us.

But what are information and computation really, given that physics has taught us that, at a fundamental level, everything is simply matter and energy moving around? How can something as abstract, intangible and ethereal as information and computation be embodied by tangible physical stuff? In particular, how can a bunch of dumb particles moving around according to the laws of physics exhibit behavior that we'd call intelligent?

If you feel that the answer to this question is obvious and consider it plausible that machines might get as intelligent as humans this century—for example because you're an AI researcher—please skip the rest of this chapter and jump straight to chapter 3. Otherwise, you'll be pleased to know that I've written the next three sections specially for you.

## What Is Memory?

If we say that an atlas contains information about the world, we mean that there's a relation between the state of the book (in particular, the positions of certain molecules that give the letters and images their colors) and the state of the world (for example, the locations of continents). If the continents were in different places, then those molecules would be in different places as well. We humans use a panoply of different devices for storing information, from books and brains to hard drives, and they all share this property: that their state can be related to (and therefore inform us about) the state of other things that we care about.

What fundamental physical property do they all have in common that makes them useful as memory devices, i.e., devices for storing information? The answer is that they all can be in many different long-
// Activity 2.1 Basic encounters What is intelligence ? Please read a few sentences expressing the author's views. Analyze the underlined words with your partner.

The debut article Make your choice a.

❏ Claims of evaluation or So there's clearly no undisputed "correct" definition of intelligence. Instead, there are many competing ones, including appraisal:
capacity for logic, understanding, emotional knowledge, selfawareness, creativity, problem solving and learning.

PAGE | 75

| b.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | (p.50) In our exploration of the future of intelligence, we want to   |  Claims of action or policy in   |                          |        |       |         |                |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------|-----------------------------------|--------------------------|--------|-------|---------|----------------|
| take a maximally broad and inclusive view, not limited to the sorts                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | one's book/chapter                                                    |                                   |                          |        |       |         |                |
| of intelligence that exist so far. That's why the definition I give in  the last chapter, and the way I'm going to use the word throughout  this book is very broad.                                                                                                                                                                                                                                                                                                                                                                                                                                              |                                                                       |                                   |                          |        |       |         |                |
| c.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | (p.50) Because there are many possible goals, there are many          |                                  | Claims of definition and |        |       |         |                |
| possible types of intelligence. By our definition, it therefore makes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | classification                                                        |                                   |                          |        |       |         |                |
| no sense to quantify intelligence of humans, non—human animals                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |  Claims of fact or existence:                                        |                                   |                          |        |       |         |                |
| or machines by a single number such as an IQ.' What's more  intelligent: a computer program that can only play chess or one that  can only play Go? There's no sensible answer to this, since they're  good at different things that can't be directly compared. It also makes little sense to quibble about whether something is or  isn't intelligent in borderline cases, since ability comes on a  spectrum and isn't necessarily an all-or-nothing trait.                                                                                                                                                    |                                                                       |                                   |                          |        |       |         |                |
| d.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | To classify different intelligences into a taxonomy, another crucial  |                                  | Claims                   | of     | cause | and     |                |
| distinction is that between narrow and broad intelligence.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | consequence:                                                          |                                   |                          |        |       |         |                |
| e.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Although the word "intelligence" tends to have positive               |                                  | The author is trying to  |        |       |         |                |
| connotations, it's important to note that                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | we're using it in a                                                   | legitimise the author's own       |                          |        |       |         |                |
| completely neutral way: as ability to accomplish complex goals                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | research. It functions as a                                           |                                   |                          |        |       |         |                |
| regardless of whether these goals are considered good or bad. Thus                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | warrant for their research.                                           |                                   |                          |        |       |         |                |
| an intelligent person may be very good at helping people or very  good at hurting people.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |                                                                       |                                   |                          |        |       |         |                |
| f.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | The conventional wisdom among artificial intelligence researchers     |                                  | The                      | author | is    | arguing |                |
| is that intelligence is ultimately all about information and                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | something.                                                            |                                   |                          |        |       |         |                |
| computation, not about flesh, blood or carbon atoms. This means  that there's no fundamental reason why machines can't one day  be at least as intelligent as us. But what are information and computation really, given that  physics has taught us that, at a fundamental level, everything is  simply and energy moving around? How can something as abstract, intangible and ethereal as information and computation be  embodied by tangible physical stuff? In particular, how can a bunch  of dumb particles moving around according to the laws of physics  exhibit behaviour that we'd call intelligent? |                                                                       |                                   |                          |        |       |         |                |
| g.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | This fact that low-level sensorimotor tasks seem easy despite         |                                  | Claims of definition and |        |       |         |                |
| requiring                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | enormous                                                              | computational                     | resources                | is     | known | as      | classification |
| Moravec's paradox, and is explained by the fact that our brain  makes such tasks feel easy by dedicating massive amounts of  PAGE | 76                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |                                                                       |                                   |                          |        |       |         |                |

customized hardware to them - more than a quarter of our brains, in fact.

## Beyond The Word 'Argue'

![9_Image_0.Png](9_Image_0.Png)

Academic evaluations typically come in many different forms, not only by using words like 'argue' or 'I argue that'. While reading the material in Part I of UE2, keep these points in mind.

| Nouns                  | Verbs                 | Adjectives             | Averbs               |
|------------------------|-----------------------|------------------------|----------------------|
| effectively (explains) |                       |                        |                      |
| a wealth               | (effectively)         | substantive (lessons)  |                      |
| (of source             | exposes               | practical (lessons)    | effectively (uses)   |
| information)           | provides              | valuable (information) | convincingly (shows) |
| comprehensive          |                       |                        |                      |
| (valuable)             | (very valuable        |                        |                      |
| contribution           | information)          | (ramework)             |                      |
| (effectively)          | captivating (stories) |                        |                      |
| demonstrates           | moving (stories)      |                        |                      |
| tenacious (in his      |                       |                        |                      |
| collection)            |                       |                        |                      |
| thorough (in his       |                       |                        |                      |
| research)              |                       |                        |                      |
| persuasive (elements)  |                       |                        |                      |

/ Activity 2.2 Engrossing discussion Hopefully, these few pages have been useful, and you have learned a good deal from this reading. Sit in a circle and choose to two terms to explain to the classmates. You can use AI tools, such as ChatGPT,
to help you.

1. What is *Intelligence*? 2. What is *AI threshold*? 3. What are *universal machines*? 4. What is *narrow and broad intelligence*? 5. What do you see in Hans Moravec's landscape *of human* competence?

![10_image_0.png](10_image_0.png)

![10_image_1.png](10_image_1.png)

Activity 2.3 Evaluating language To make an arguments, writers use all sorts of techniques. Tell your classmates what techniques they use in the following sentences.

| adjective   | adverb   | Prepositional   | Clause   |
|-------------|----------|-----------------|----------|
| phrase      |          |                 |          |

| Adjective   | Adverb   | Prepositional   | Clause   | Examples   |
|-------------|----------|-----------------|----------|------------|
| phrase      |          |                 |          |            |

amounts of customized 

| intelligence is   | By our definition,   | So there's clearly no   | Our         | brain   |      |
|-------------------|----------------------|-------------------------|-------------|---------|------|
| ultimately all    | it                   | therefore               | undisputed… | makes   | such |
| about             | makes no sense       | tasks feel easy         |             |         |      |
| information and   | to                   | by                      | dedicating  |         |      |
| computation       | massive              |                         |             |         |      |

hardware to them - more than a quarter 

| competing definitions   |
|-------------------------|

of our brains, in fact crucial distinction It also makes little sense to quibble about whether This means that there's no fundamental reason why machines can't one day be at least as intelligent as us. we want to take a maximally broad and inclusive view

## 52   Life 3.0

of goals: it can play dozens of different vintage Atari compus games at human level or better. In contrast, human intelligence thus far uniquely broad, able to master a dazzling panoply of skills healthy child given enough training time can get fairly good not on at any game, but also at any language, sport or vocation. Compa ing the intelligence of humans and machines today, we humans wi hands-down on breadth, while machines outperform us in a sma but growing number of narrow domains, as illustrated in figure 2.1 The holy grail of AI research is to build "general AI" (better know as artificial general intelligence, AGI) that is maximally broad: able, accomplish virtually any goal, including learning. We'll explore th in detail in chapter 4. The term "AGI" was popularized by the A
researchers Shane Legg, Mark Gubrud and Ben Goertzel to mon specifically mean buman-level artificial general intelligence: the abil ity to accomplish any goal at least as well as humans. 1 I'll stick with their definition, so unless I explicitly qualify the acronym (by wit ing "superhuman AGI," for example), I'll use "AGI" as shorthand for
"human-level AGI."
Although the word "intelligence" tends to have positive connots.

tions, it's important to note that we're using it in a completely value neutral way: as ability to accomplish complex goals regardless of whether these goals are considered good or bad. Thus an intelligen person may be very good at helping people or very good at hurting people. We'll explore the issue of goals in chapter 7. Regarding goals we also need to clear up the subtlety of whose goals we're referring to. Suppose your future brand-new robotic personal assistant has no goals whatsoever of its own, but will do whatever you ask it to do, and you ask it to cook the perfect Italian dinner. If it goes online and researches Italian dinner recipes, how to get to the closest supermarket, how to strain pasta and so on, and then successfully buys the ingredients and prepares a succulent meal, you'll presumably consider it intelligent even though the original goal was yours. In fact it adopted your goal once you'd made your request, and then broke
* Some problematic. Even a pocket calculator is a human-level AI in the name systems such as Deep Blue, Watson, and AlphaGo "weak."
gre 2.2: Illustration of Hans Moravec's "landscape of human competence," where

![12_image_0.png](12_image_0.png)

vation represents difficulty for computers, and the rising sea level represents what computers are able to do.

it into a hierarchy of subgoals of its own, from paying the cashier to grating the Parmesan. In this sense, intelligent behavior is inexorably linked to goal attainment.

It's natural for us to rate the difficulty of tasks relative to how hard it is for us humans to perform them, as in figure 2.1. But this can give a misleading picture of how hard they are for computers. It feels much harder to multiply 314,159 by 271,828 than to recognize a friend in a photo, yet computers creamed us at arithmetic long before I was born, while human-level image recognition has only recently become possible. This fact that low-level sensorimotor tasks seem easy despite requiring enormous computational resources is known as Moravec's paradox, and is explained by the fact that our brain makes such tasks feel easy by dedicating massive amounts of customized hardware to them—more than a quarter of our brains, in fact.

I love this metaphor from Hans Moravec, and have taken the liberty to illustrate it in figure 2.2:
Computers are universal machines, their potential extends uniformly over a boundless expanse of tasks. Human potentials, on the other hand, are strong in areas long important for survival, but weak in things far removed. Imagine a "landscape of human com¬
// Activity 2.4 Experiment Writing Read the following sentences, and adjust it for your own essay.

It also makes little sense to quibble about whether something is or isn't intelligent in borderline cases, since ability comes on a spectrum and isn't necessarily an all-or-nothing trait.

![12_image_1.png](12_image_1.png)

a non-sensical (Adj.)

| Tegmark                                                                                                                                                                                                                                                                                                                                                                                                                                                      | (2017)                                                                 | suggests   | that    | any    | b______________   | cases       |     |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------|------------|---------|--------|-------------------|-------------|-----|
| _____________                                                                                                                                                                                                                                                                                                                                                                                                                                                | be                                                                     | considered | (modal  | verb), | since             |             |     |
| ____________________________                                                                                                                                                                                                                                                                                                                                                                                                                                 | not a sensible (Adj.) vary in degrees (Verb) isn't an either-or (Adj.) |            |         |        |                   |             |     |
| But what are information and computation really, given that  physics has taught us that, at a fundamental level, everything  is simply and energy moving around? How can something as  abstract, intangible and ethereal (delicate) as information  and computation be embodied by tangible physical stuff? In  particular, how can a bunch of dumb particles moving around  according to the laws of physics exhibit behaviour that we'd  call intelligent? | Ingredients                                                            | for        |         |        |                   |             |     |
| experiment  Tegmark gives a critical  account…                                                                                                                                                                                                                                                                                                                                                                                                               |                                                                        |            |         |        |                   |             |     |
| As                                                                                                                                                                                                                                                                                                                                                                                                                                                           | Tegmark                                                                | (2017)     | queries | /      | questions,        | information | and |
| computation are like abstract/ concrete and ethereal/ essential particles of energy. How can such ethereal matters  _________________ as intelligence?                                                                                                                                                                                                                                                                                                       |                                                                        |            |         |        |                   |             |     |

| What have you learnt? Occasionally, you read a critical text, and sometimes you read a plain  one. All of them are written in words, but words and sentence patterns  carry subtle meanings and subtle suggestions. In your future assignments, you should be able to moderate these claims and convey them appropriately to your lecturers.   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

![13_image_0.png](13_image_0.png)

Activity 2.5 Exploring the unknown Read the following sentences, and adjust them or your own essay.

| It also makes little sense to quibble about whether something  is or isn't intelligent in borderline cases, since ability comes  on a spectrum and isn't necessarily an all-or-nothing trait.                                                                                                                                                                                                                                                                                             | Ingredients   | for        |         |        |                 |             |     |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|------------|---------|--------|-----------------|-------------|-----|
| experiment  a non-sensical (Adj.) not a sensible (Adj.) vary in degrees (Verb) isn't an either-or (Adj.)                                                                                                                                                                                                                                                                                                                                                                                  |               |            |         |        |                 |             |     |
| Tegmark                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | (2017)        | suggests   | that    | any    | b______________ | cases       |     |
| _____________                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | be            | considered | (modal  | verb), | since           |             |     |
| ____________________________ But what are information and computation really, given that  physics has taught us that, at a fundamental level, everything  is simply and energy moving around? How can something as  abstract, intangible and ethereal (delicate) as information  and computation be embodied by tangible physical stuff? In  particular, how can a bunch of dumb particles moving around  according to the laws of physics exhibit behaviour that we'd  call intelligent? | Ingredients   | for        |         |        |                 |             |     |
| experiment  Tegmark gives a critical  account                                                                                                                                                                                                                                                                                                                                                                                                                                             |               |            |         |        |                 |             |     |
| As                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Tegmark       | (2017)     | queries | /      | questions,      | information | and |
| computation are like abstract/ concrete and ethereal/ essential particles of energy. How can such ethereal matters  _________________ as intelligence?                                                                                                                                                                                                                                                                                                                                    |               |            |         |        |                 |             |     |

Activity 2.6 

Exploring the unknown Please read the following text, which is quite difficult to read. Is there a strategy you use to overcome its difficulty?

In academic reading, you will encounter long, difficult texts like these.

Computers are universal machines, their potential extends 

![15_image_0.png](15_image_0.png)

![15_image_1.png](15_image_1.png)

![15_image_2.png](15_image_2.png)

![15_image_3.png](15_image_3.png) uniformly over a boundless expenses of tasks. Human potentials (Why plural?), on the other hand, are strong in areas long important for survival, but weak in things far removed. Imagine a "landscape of human competence," having (-ing participle) lowlands with labels like "arithmetic" and "rote memorization," foothills like "theorem proving" and "chess playing," and high mountain peaks labeled "locomotion," and "hand-eye coordination" and "social interaction." Advancing (adjective) computer performance is like water slowly flooding the landscape. A half century ago it began to drown the lowlands, driving out human calculators. As the sea level keeps rising, it may one day reach a tipping point, 

![15_image_4.png](15_image_4.png) triggering (-ing participle) dramatic change. This critical sea level is the one corresponding ('equivalent') to machines becoming able to perform AI design. Before this tipping point is reached, the sea-level rise is caused by human improving machines. afterward, the rise can be driven by machines improving machines, potentially much faster than humans done, rapidly submerging all land In this short paragraph, what is being compared with what? What does 'sea level' refer to?

---

| Paraphrasing I love this metaphor from Hans Moravec, and have taken the liberty to illustrate it in figure 2.2: Computers are universal machines, their potential extends uniformly  over a boundless expenses of tasks. Human potentials, on the other hand, are strong in areas long important for survival, but weak in things far removed. Imagine a "landscape of human competence Tips for paraphrasing 1. Structure: The grammatical structure should be changed if this   | 2.                                                                                                                                                                                                                                                                                                                       |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| can be done without changing the meaning. Often this can be done  by joining up sentences or by dividing up long sentences.                                                                                                                                                                                                                                                                                                                                                       |                                                                                                                                                                                                                                                                                                                          |
| 2.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Meaning: Your paraphrase must have the same meaning as the  source; it should also have the same relationship between main  ideas and supporting details.                                                                                                                                                                |
| 3.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Words: Use different words when possible, usually more common  synonyms/expressions and simpler phrases. Keep specialised  words which have no synonyms (e.g. calcium, plastic, theory, and  neutron), proper names (e.g. Europe, and World Health  Organisation), numbers and formulae. (e.g. 50%, 200KW/m, and  1984). |
| 4.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Length: The length should not vary very much from the length of  the original.                                                                                                                                                                                                                                           |

5. Style: The style should be your own style and not an imitation of the source, even if your own style seems less perfect to you.

Reporting verbs Okay, now you have finished the task. Tell me whether there is subjective language or objective language in these excerpts We've spent this chapter exploring the nature of intelligence a its development up until now. How long will it take until machican out-compete us at all cognitive tasks? We clearly don't know. 2 need to be open to the possibility that the answer may be "never However, a basic message of this chapter is that we also need to co sider the possibility that it will happen, perhaps even in our lifeti»
After all, matter can be arranged so that when it obeys the laws physics, it remembers, computes and learns—and the matter does need to be biological. AI researchers have often been accused of over promising and under-delivering, but in fairness, some of their critic don't have the best track record either. Some keep moving the goi posts, effectively defining intelligence as that which computers se can't do, or as that which impresses us. Machines are now good of excellent at arithmetic, chess, mathematical theorem proving, stor picking, image captioning, driving, arcade game playing, Go, speed synthesis, speech transcription, translation and cancer diagnosis, but some critics will scornfully scoff "Sure—but that's not real intell gence!" They might go on to argue that real intelligence involves on the mountaintops in Moravec's landscape (figure 2.2) that haven'tw been submerged, just as some people in the past used to argue the image captioning and Go should count— while the water kept rising Assuming that the water will keep rising for at least a while longer AI's impact on society will keep growing. Long before AI reach human level across all tasks, it will give us fascinating opportunitis and challenges involving issues such as bugs, laws, weapons and job What are they and how can we best prepare for them? Let's explor this in the next chapter.

## Habits Of Mind…

Remember that Gateways units cannot read page by page with you. It is true that doing a Literature Review involves your own exploration of readings and ideas.

## A. When Is Quoting Directly From The Author Necessary?

![18_Image_0.Png](18_Image_0.Png)

This is a question of whether there is anything special about the actual words used. If the idea is important but the words in which it is expressed are quite ordinary, it is more sensible for you to paraphrase. Use quotations only when the ideas or words are relatively unusual or interesting or the idea is so difficult that it is important to consider the exact wording.

Before you use a direct quote, please consider the following:
1. Is there a need to quote? 2. Would the quote fit well into your work or would it look out of place? 3. If you are using a direct quote, are you aware exactly how to insert an in-text citation?

B. What are the different ways to quote? **How can we integrate quotations into a text?** Imagine that you are going to incorporate the following quotation into your essay. What are the PAGE | 86 different ways to do so? You can have a look at this video: https://www.youtube.com/watch?v=DhMl3eIcGbI Quotation:
"Younger generation of present era is acting as active users of social media which has affinity towards the problems of mental health. The present perilous situation requires more understanding, to know relation between social media and mental health problems is just a kick off point." (Bashir & Bhat, 2016, p. 125)
Different ways:
C. Read the following quotes and determine whether a paraphrase or direct quote is more appropriate, **and why.**
1. You are talking about ways for teachers to facilitate learning in your paper: "They teach in various ways: they set tasks for pupils, they try to motivate pupils, to help them, to control their performances, and to improve their understanding and skills" (Moore, 2010, p. 5). Paraphrase or direct quote? 2. You are trying to define motivation using studies in the literature: "Motivation is an internal state that arouses, directs, and maintains behaviour" (Woolfolk, 2010, p. 431). Paraphrase or direct quote? 3. You are trying to distinguish collaboration from cooperation: "*Collaboration is a philosophy of interaction and personal lifestyle where individuals are responsible for* their actions including learning, respecting members' abilities and their contributions. There is a sharing of authority and acceptance of responsibil*ity among group members for the groups' actions. The* underlying premise of collaborative learning (CL) is based upon consensus building through cooperation by group members, in contrast to competition in which individuals best other group members" (Laal et al, 2013, p. 1427). Paraphrase or direct quote? 4. You are discussing the direct instruction teaching approach: "…….. direct instruction applies best to the teaching of basic skills- *clearly structured knowledge and* essential skills, such as science facts, mathematics computation, reading vocabulary, and grammar rules" (Woolfolk & Margetts, 2012, p.437).

Paraphrase or direct quote? 

## Paraphrasing

The rules for paraphrasing are clear: "A good paraphrase expresses the ideas of the original source correctly; it is grammatical; and it contains nothing copied from the source except unchangeable terms" (Hamp-Lyons & Courter, 1984, p. 3).

Tips for paraphrasing 3. **Structure**: The grammatical structure should be changed if this can be done without changing the meaning. Often this can be done by joining up sentences or by dividing up long sentences.

3. **Meaning**: Your paraphrase must have the same meaning as the source; it should also have the same relationship between main ideas and supporting details.

4. **Words**: Use different words when possible, usually more common synonyms/expressions and simpler phrases. Keep specialised words which have no synonyms (e.g. calcium, plastic, theory, and neutron), proper names (e.g. Europe, and World Health Organisation), numbers and formulae. (e.g. 50%, 200KW/m, and 1984).

5. **Length**: The length should not vary very much from the length of the original. 6. **Style**: The style should be your own style and not an imitation of the source, even if your own style seems less perfect to you.

Look at the examples below:

| Original Text                                                                                              | Paraphrase                                        |
|------------------------------------------------------------------------------------------------------------|---------------------------------------------------|
| The reverence of the Chinese for the written                                                               | It is a well-known fact that the Chinese respect  |
| word is proverbial. Their script is not only the                                                           | their writing. It is the most difficult and the   |
| most complex but also the most ancient system                                                              | oldest form of writing in current use.            |
| of writing still in use today (Wong & Chan, 2012,  p.20). Encyclopedias, dictionaries, paper, and printing | Among the inventions of the Chinese were          |
| were all Chinese inventions.                                                                               | encyclopedias, dictionaries, paper, and printing. |

Watch this video to understand more about paraphrasing https://www.youtube.com/watch?v=oiM0x0ApVL

Paraphrasing Paraphrase the paragraphs for Questions 2-4 in teams. Question 1 has been done as an example.

## (1)

When Mexican pilots land their airplanes in France, they and the ground controllers use English. When German physicists want to alert the international scientific community to new discoveries, they first publish their findings in English. When Japanese executives conduct their business with Scandinavian entrepreneurs, they negotiate in English. 

Hasman, M. (2001). The role of English in the 21st century. English Teaching Forum Online, 39(1), 1-2.

## Suggested Answer:

Hasman (2001) illustrates that English is used by Mexicans when communicating with the French in the aviation industry, and Germans also use English when presenting scientific research, while the Japanese use it for business negotiations with Scandinavians. Explanation of paraphrasing to avoid plagiarism. 1. Insertion of an in-text citation (APA style) 2. Restructuring of the sentence (When Mexican pilots land their airplanes in France, they and ground controllers use English)
3. Use of a synonym (land their airplanes) 4. Use of a synonym to describe the presentation of new discoveries (alert the international scientific community to new discoveries)
5. Change of the part of speech and restructuring of the sentence (negotiate in English)
Paraphrase the following texts with the skills learned. (2) 
While the rest of the non-English speaking world, including mainland China, is busily learning and applying English, Hong Kong, it seems, is being left behind. Hong Kong young people must find avenues by which to apply their book knowledge of English in the practical domain, both in speech and in writing.

 Jacota, L. (2009). English: Using it or losing it? *Youth Hong Kong,* 4-7.

(3)
The findings were derived from a questionnaire survey of 2,030 professionals, most of them being ethnic Chinese. The respondents perceived "written English" to be of utmost importance, and they gave an average rating of 5.08 to it on a six-point scale, followed by spoken Cantonese (4.79), spoken English (4.69), written Chinese (4.09) and Putonghua (3.79).

Evans, S., & Cheng, W. (2010). *Language use in the professional world in Hong Kong.* Hong Kong Polytechnic University.

It should be recognised that Hong Kong English is used in the community, and has a long history, with a local accent and style of speech […]. Throughout Asia, local varieties of English exist and are recognised by linguists. Nevertheless, the existence of this vernacular in Hong Kong has not been recognised by many commentators. Instead, it has been dismissed as "bad" English. Bolton, K. (2009). Culture of confidence, not of complaint: Encouraging proficiency in English. 

Youth Hong Kong, 11-15.

Additional paraphrasing activities from authentic journal papers on digital detox 1)
Research exploring associations between screen time and more psychological aspects of well-being among children and adolescents has been inconsistent. Twenge, J. M., & Campbell, W. K. (2018). Associations between screen time and lower psychological well-being among children and adolescents: Evidence from a populationbased study. *Preventive medicine reports*, 12, 271–283. 

Although digital detox is ubiquitous and, per its definition, an opportunity to reduce stress or focus on social interactions in the physical world, it remains unclear whether digital detox is an effective strategy to promote a healthy way of life in the digital era. Surprisingly, no systematic review has been published on the efficacy of digital detox, yielding a body of literature with isolated findings. Radtke, T., Apel, T., Schenkel, K., Keller, J., & von Lindern, E. (2022). Digital detox: An effective solution in the smartphone era? A systematic literature review. Mobile Media & Communication, 10(2), 190–215. https://doi.org/10.1177/20501579211028647 3)
Thus, the evolutionary perspective suggests that social media can hijack our evolved tendency to monitor for social cues and perceive social information as rewarding, and depressed individuals are especially vulnerable to being sucked in by social media as they experience a stronger need to alleviate feelings of insecurity, low self-worth, or hopelessness. These arguments from multiple perspectives provide compelling justification to take the reverse association more seriously. Hartanto, A., Quek, F. Y. X., Tng, G. Y. Q., & Yong, J. C. (2021). Does social media use increase depressive symptoms? A reverse causation perspective. *Frontiers in* psychiatry, 12, 641934. https://doi.org/10.3389/fpsyt.2021.641934 Activity 2.4 Summarising What is a summary in general writing?

A summary is a shorter text written in your own words that gives the main points of a piece of writing such as a journal, a book, or a newspaper article.

Summarising steps Step 1. Determine the main ideas/most important words in each sentence Step 2. Usually verbs and nouns are the most important words to select Step 3. Underline or highlight these keywords Step 4. Use the underlined words to create a sentence Summarise the following paragraphs in 1-2 sentences. What is the point the paragraphs attempt to convey?

Number 1 has been completed as an example. 

1. "The movement toward education by computer is developing fast. Massive Open Online Courses, called MOOCs, are changing how people learn in many places. For years, people could receive study materials from colleges or universities and take part in online classes. But such classes were not designed for many thousands of students at one time, as MOOCs are" ("MOOCs", n.d., para. 3)
(Source: MOOCs are moving forward. (n.d.). *Learning English*. https://learningenglish.voanews.com/a/mooconline-learning-internet-college-university-education/1559297.html )
Summary: A fast-growing MOOCs movement allows thousands to take online classes at once, changing how we learn.

NB: The arrangement of the sentence should include all of the information that is underlined. 

It usually does not need to be in the same order as the words that are underlined. However, you should include the information coherently within the sentence.

The most important words have been highlighted and underlined for you in this example. Please use the words to write 1 or 2 sentences. Please compare yours with the suggested answer afterward. 

2. A social networking service is an online service, platform, or site that focuses on helping people to build social networks or social relations with other people who share interests, activities, backgrounds, or real-life connections. Most social network services are web-based and provide means for users to interact over the Internet. Examples of social networking services are e-mail, Facebook and Twitter. Social networking sites allow users to share ideas, activities, events, and interests.

(Source: Eura 7. (n.d.). *Social networking services.* https://www.eura7.com/en/dictionary/social-networkingservices.)
Summary: 
Please underline and highlight the most important words/ideas in examples 3 and 4 below and write 1 or 2 sentences. Compare your answer with the suggested answer afterward. 

3. Overall, the first two quarters have been profitable for the company. Nineteen of twenty departments report cutting costs at least twenty percent, and sales from fifteen departments have risen five percent, or about $5 million. Despite these positive developments, most department heads believe that they will not be able to maintain these levels for the remainder of the year.

(Source: Purdue Online Writing Lab. (n.d.). *Summarizing*. https://owl.purdue.edu/owl/english_as_a_second_language/esl_students/paraphrasing_and_summary/summa rizing.html.

Summary: 
4. In order to communicate successfully with other people, one must have a reasonably accurate idea of what they do and do not know what is pertinent to the communication. Considering people as though they have knowledge that they do not have can result in miscommunication and perhaps embarrassment. On the other hand, a fundamental rule of conversation is that one generally does not convey to others information that one can assume they already have.

Source: Nickerson, R.S. (1999). How we know - and sometimes misjudge - what others know: Imputing one's own knowledge to others. *Psychological Bulletin, 125*(6), 737-759. https://doi.org/10.1037/00332909.125.6.737 Summary: 

Differences between summarising and paraphrasing? What is the difference between paraphrasing and summarising? Please write down what you think and discuss your ideas with a partner.

Guiding questions about paraphrasing and summarising Which one is similar in length to the original text? Which one is mainly an overview of the main ideas of the original text? Which one does not include examples and other data from the original text? Which one is usually used to provide support and evidence for an argument?

| Paraphrasing   | Summarising   |
|----------------|---------------|

Note: In both a paraphrase and a summary, different words from the original text should be used.

Summarising is defined as the technique of giving a short version of a longer original source. Its main goal is to present a large amount of information in a short and concise text that includes only the most important ideas of the original text. Paraphrasing is defined as the technique of rewriting the original source using different words and sentence structures. The main purpose of paraphrasing has to do with being able to use someone else's ideas while we write our own texts. Of course, you are required to acknowledge the original source using a proper in-text citation format.

Watch this video and find out more: https://www.youtube.com/watch?v=PigfCpCg15c

![30_image_0.png](30_image_0.png)

Activity 2.6 Summarising skills check Use the skills that you learned above to summerise the method's section of the study on abstinence from social networking sites (Turel et al., 2018).

Instructions: Use the skills and knowledge you gained from the above exercises when summarising the following paragraph.

The use of different sections of the same class ensured no overlap between treatment conditions. The control group completed two online surveys one week apart. The abstain group completed the same surveys but, importantly, participants in this group were allowed to resume SNS use earlier than one week if they felt they could not abstain any longer and they were instructed to complete the second survey before use resumption. We chose an abstinence target period of one week because we wanted to balance the feasibility of the study, not asking for longer abstinence periods, and the effects of the intervention, which may be smaller in shorter periods of abstinence. Turel, O., Cavagnaro, D. R., & Meshi, D. (2018). Short abstinence from online social networking sites reduces perceived stress, especially in excessive users. *Psychiatry* Research, 270, 947–953. https://doi.org/10.1016/j.psychres.2018.11.017 Summary: 

## Synthesising Information From Different Sources

When reading articles and looking for evidence in articles, you will come across information that overlaps or differs. The process that you use to combine all this information is called a synthesis.

| Some ways to synthesise information: 1. Integrate information that overlaps and differs. 2. Use cohesive devices to connect relevant information. 3. Paraphrase and summarise the information. 4. Retain the meaning of the information. 5. Use information from 2 or more sources. 6. Synthesise by using complex sentences to join information together. 7. Use in-text citations to give credit to the authors to avoid plagiarism.   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

When reading articles and looking for evidence in articles, you will come across information that overlaps or differs. The process that you use to combine all this information is called a synthesis. Some ways to synthesise information: 1. Integrate information that overlaps and differs. 2. Use cohesive devices. 3. Retain the meaning of the information. 4. Synthesise by using complex sentences.

![32_image_0.png](32_image_0.png)

What is a synthesis? Please take time to read through these sentences slowly and carefully. The skill of synthesis can be defined as finding information from 2 or more sources and combining this information in a meaningful way. We can find areas where the sources have information that is the same or different. The information from these sources can be compared and the relationship identified. This skill can be connected to a topic or research theme to create something brand new. Synthesising strategies are skills that are necessary to excel in academic writing. Without this skill, we cannot interpret and analyse information from multiple sources in a coherent way. The process is not wholly linear, which means that a synthesis does not simply extract information piece by piece but aims to extract and connect the information. An effective literature review, for example, will have several instances of synthesis. However, the entire literature review should not be instances of synthesis.

## Quotes From Scholars About Synthesis Writing

"The ability for people to assimilate information they find into coherent personal strategies is perhaps the critical modern survival skill" (Johnson, 2009, p. 601). Spivey (1989) adds that choosing relevant information and placing it together logically is of utmost importance when gaining new writing skills and abilities.

https://emojipedia.org/microsoft/windows-10-may-2019-update/bellhop-bell/
Characteristics of synthesis writing in literature reviews tend to:
- establish associations between texts
- recognise patterns in texts (similarities and differences) from two or more sources
- organise information using transitions and cohesive devices
- identify the conversation within the literature - paraphrase and summarise using in-text citations
- use a cohesive device that displays connection, either agreement or contrast, between authors
(Source: Lundstrom et al., 2015)
More information about synthesis writing
- Read through the following information about synthesis writing
- Consider how synthesis writing can help you write your literature review
- Complete the exercises to help with your understanding Remember synthesis writing aims to **organise, select and connect** ideas from two or more authors in meaningful ways with synthesis vocabulary. Task: Read through the examples and determine if it is a reasonable synthesis or not. You may consider the following questions: - Is there a meaningful connection of ideas? - Is the synthesis put together logically? - Does the synthesis have two or more sources with a synthesis word? - Is more than one source identifiable with in-text citations? Example synthesis \#1 Smith (2004) points out that chocolate comes to us from South America, where it was once consumed as a bitter, hot beverage. The beverage quickly gained favour in Europe. Queen Isabella had an elaborate hot chocolate set that was used on important state occasions (Mackey, 2005).

## Example Synthesis #1 Is Missing A Cohesive Device Or A Connection Between Sentences.

Explanation: A good synthesis will use a cohesive device to connect the ideas together. In the example above, no synthesis word is used. There should be a connection between 'Europe and Queen Isabella'.

Examples of synthesising vocabulary Synthesising words you can use as cohesive devices

| agrees    | disagrees   | concurs   | expands on         |
|-----------|-------------|-----------|--------------------|
| clarifies | contradicts | confirms  | in accordance with |

Example synthesis \#2 According to Smith (2004), the most important invention was the milk chocolate bar as it has gained worldwide attention. Most of the world loves eating chocolate. Simpson agrees with Smith (2004) by asserting chocolate is the greatest invention ever in the history of the world. What is missing in example synthesis \#2? Hint: look at the authors cited in the synthesis. Example synthesis \#3 Perhaps the biggest reason the tariff on chocolate should be reduced is that it is a commodity and influences the economy. Smith (2004) claims that in contemporary society chocolate has become a necessity, especially to the food and beverage industry. Simpson (2005) disagrees by stating that chocolate is an important element of all food but having other flavours is also essential. What is missing from example synthesis \#3? Hint: look at the relationship between the authors. Example synthesis \#4 As Frank (2007) notes, because of the substantial lower prices of generic drugs, consumers and purchasers can save around ten billion every year. Shrank et al. (2011) agree with Frank (2007) by noting that the substitution of generic drug products can result in a reduction of costs without sacrificing the clinically approved drug quality with clinical appropriation. Why is example synthesis \#4 a good synthesis? Please list the reasons in the space provided below. Example synthesis \#5 According to findings in the research by Jacob et al. (2019), loneliness explained 84% of mental disorders (e.g. depression and anxiety) caused by living alone. Smith (2019) concurs by claiming that loneliness increases the risk of developing dementia. Why is example synthesis \#5 a good synthesis? Please list the reasons in the space provided below.

| Author: Suemedha Sood Article: The statistics of studying abroad Newspaper: BBC News Date: September 2012   |
|-------------------------------------------------------------------------------------------------------------|

Writing a synthesis You have a plan to study abroad next year. However, you have little knowledge about it and you want to know more. Read the 2 short articles and then write some short synthesised sentences in the space provided below.

![37_image_0.png](37_image_0.png)

![37_image_1.png](37_image_1.png)

Please follow the guidelines to approach this task in the most efficient way.

- Skim through the two texts quickly and annotate them - Look for information that is similar and highlight the areas - Find information that differs in the texts and highlight it in a different color or underline it
- Synthesise the information by paraphrasing and selecting a suitable connecting word - Remember to retain the original meaning - Include the in-text citations from the two authors with the year of publication - Write using complex sentences These days, record numbers of students are studying abroad all over the world. According to the International Organisation for Economic Cooperation and Development, the number of international students worldwide rose from 0.8 million in 1975 to 3.7 million in 2009. In addition, UNESCO's Institute for Statistics finds that the number is increasing by about 12% each year.

| Author: Christina Cabrera Article: Lack of information prevents some  students from studying abroad Newspaper: Washington Square News Date: March 2013 Other reasons chosen by students surveyed for  failing to study abroad included cost, concerns  about acquiring a visa, lack of proficiency in a  foreign language and difficulty leaving family and  friends. University of Warwick student Emily  Lawless, for example, said she would not feel  comfortable studying abroad. "I think if the  opportunity was there it would be a great  experience, given all the new sights and things to  do," she said. "But, as it would be expensive and I   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

The benefits of studying abroad are felt both by individuals and entire nations. International students in the US, for instance, contribute approximately $20 billion to the US economy each year. In addition, countries that encourage their students to study abroad usually do so with the hope that they will return and give back to their home economies. Among Chinese students who study overseas, more than 70% end up returning to China. International students can also boost a country's higher education standards, with universities doing their best to attract the world's best and brightest in the fields they specialise in. For the students themselves, studying abroad can present opportunities for learning new languages, travelling, career development, experiencing new cultures and forming new friendships. But there can be downsides to studying in other countries as well. Tuition and travel costs are often very high, especially for students from developing nations, and student visas can be difficult to obtain and maintain. As with any form of travel, there are health and safety concerns to take into account. Depending on where students are travelling to, vaccinations may be necessary, and they may need to get medical insurance to cover unforeseeable events during their stay.

like being around friends and family it is not something that I would do myself." Nonetheless, the British Council emphasised that the experience is usually extremely gratifying. 

Language learning happens most quickly when surrounded by the language on a daily basis and seeing and hearing it in the proper cultural context. Students who experience cultural differences personally can come to truly understand where other cultures are coming from firsthand. The encounter with other cultures also enables students to see their own culture through new eyes. Students meet not only natives to the culture in which they are studying, but also other international students who are also far from home. In general, students who study abroad return home with an informed and much less biased perspective toward other cultures and people. Weekends and academic breaks give students the opportunity to travel and explore. Some programmes have field trips planned around the curriculum. Study abroad offers experiences a classroom setting will never provide. Being immersed in a new cultural setting is an opportunity to discover new strengths and abilities, conquer new challenges and solve new problems. Overseas study enhances employment opportunities. Through an employer's eyes, a student who has studied abroad is self‐ motivated, independent, willing to embrace challenges, and able to cope with diverse problems and situations. Students may become familiar with an entirely new academic system and have the chance to take courses not offered at their home campus. As such it enhances the value of a university degree.

Remember that an instance of synthesis has vocabulary showing agreement or disagreement. Synthesising also shows the meaningful relationship between two or more sources. In order to do this activity, it is best to organise, select and connect ideas from the TWO passages. Please write synthesised sentences in the spaces provided below - try to write at least 2 or 3 sentences.

![39_image_0.png](39_image_0.png)

![39_image_1.png](39_image_1.png)

![39_image_2.png](39_image_2.png)

![39_image_3.png](39_image_3.png)

![39_image_4.png](39_image_4.png)

![39_image_5.png](39_image_5.png)

![39_image_6.png](39_image_6.png)

# Useful Phrases/Expressions For Synthesis Writing

- Similarly, Nicoladis (2006) asserts/found that X … - Likewise, Wang (2012) holds the view that … - In the same vein, Smith (1994) in his book XYZ notes … - This view is supported by Jones (2000) who writes that … - Smith argues that the data support O'Brien's (1988) view that … - Al-Masry's (1986) work on X is complemented by Smith's (2009) study of … - Almost every paper that has been written on X includes a section relating to …
- Unlike Smith, Jones (2013) argues that … - In contrast to Smith, Jones (2013) argues that …
- A broader perspective has been adopted by Smith (2013) who argues that …
- Conversely, Wang (2010) reported no significant difference in mortality between X and Y.

- However, Jennings' (2010) study of Y found no link between … - Other researchers, however, who have looked at X, have found … Jones (2010), for example, - Smith (2010) presents an X account, whilst Jones (2011) … - While Smith (2008) focusses on X, Jones (2009) is more concerned with … - Some writers (e.g. Smith, 2002) have attempted to draw fine distinctions between … Others 
(see Jones, 2003; Brown, 2004) question the usefulness of …
- Some authors have mainly been interested in questions concerning X and Y (Smith, 2001; Jones … Others have highlighted the relevance of …
- Much of the available literature on X deals with the question of … But Smith (2008) is much more concerned with …
Source: https://www.phrasebank.manchester.ac.uk/referring-to-sources/
Synthesising activity Now that you are familiar with the basic approach to text synthesis, please choose 2 articles and write at least 3 instances of synthesis. 

Instructions
- **Choose 2 articles from the activity in Unit 1 on Social Media Use and Mental health.** - **Use the 'tips' mentioned above to write at least 3 synthesised sentences.** 

| Title of the articles   | Synthesised sentences 1) 2) 3)   |
|-------------------------|----------------------------------|

Academic Word List (AWL) Below is a list of the most frequently used words in academic writing. This academic vocabulary has been sorted according to the frequency of use. Items in List 1 are the most common and List 2 is less so and so on. At the end of each list, you will find 5 extracts from journal articles for you to select a suitable word from the corresponding lists.

| List 1: analysis   | approach     | area           | assessment   |
|--------------------|--------------|----------------|--------------|
| assume             | authority    | available      | benefit      |
| concept            | consistent   | constitutional | context      |
| contract           | create       | data           | definition   |
| derived            | distribution | economic       | environment  |
| established        | estimate     | evidence       | export       |
| factors            | financial    | formula        | function     |
| identified         | income       | indicate       | individual   |
| interpretation     | involved     | issues         | labour       |
| legal              | legislation  | major          | method       |
| occur              | percent      | period         | policy       |
| principle          | procedure    | process        | required     |
| research           | response     | role           | section      |
| sector             | significant  | similar        | source       |
| specific           | structure    | theory         | variables    |

1. The purpose of the _____________ is to estimate the relative magnitudes of these processes. 2. Increasing _____________ suggests that climate change impacts are already observed around the world.

3. Another example could be, as mentioned by a new alumnus, relying on the company's online system which provides guidelines and _____________ of writing various emails.

4. We set out six _____________ priorities to build the knowledge needed to develop effective policy. 5. This paper proposes a local grammar _____________ to investigating diachronically discourse acts in academic texts.

| List 2: achieve   | acquisition   | administration   | affect       |
|-------------------|---------------|------------------|--------------|
| appropriate       | aspects       | assistance       | categories   |
| chapter           | commission    | community        | complex      |
| computer          | conclusion    | conduct          | consequences |
| construction      | consumer      | credit           | cultural     |
| design            | distinction   | elements         | equation     |
| evaluation        | features      | final            | focus        |
| impact            | injury        | institute        | investment   |
| items             | journal       | maintenance      | normal       |
| obtained          | participation | perceived        | positive     |
| potential         | previous      | primary          | purchase     |
| range             | region        | regulations      | relevant     |
| resident          | resources     | restricted       | security     |
| sought            | select        | site             | strategies   |
| survey            | text          | traditional      | transfer     |

1. According to the average score that participants _____________ on the English section of the College Entrance Examination in mainland China, it can be said that they have an intermediate level of English language proficiency.

2. The two _____________ goals of the first stage of our analysis were the development of a comprehensive move-step framework for the part-genre in question, that is, social science RA introductions, and reliable annotation of rhetorical move-steps in the corpus using this framework.

3. This study followed a qualitative _____________ and sought to examine the significance of Englishbased communication for the community of Bejaia UHPs affiliated with both Bejaia University as lecturer-researchers and Bejaia university hospital as medical practitioners.

4. This paper reports on a _____________ study that aimed at understanding the perceptions and practices of Brazilian scholars working in different disciplines.

5. This paper _____________ on standard phraseology since there is confusion around its role in radiotelephony communication.

| List 3: alternative   | circumstances   | comments      | compensation   |
|-----------------------|-----------------|---------------|----------------|
| components            | consent         | considerable  | constant       |
| constraints           | contribution    | convention    | coordination   |
| core                  | corporate       | corresponding | criteria       |
| deduction             | demonstrate     | document      | dominant       |
| emphasis              | ensure          | excluded      | framework      |
| funds                 | illustrated     | immigration   | implies        |

| initial    | instance   | interaction   | justification   |
|------------|------------|---------------|-----------------|
| layer      | link       | location      | maximum         |
| minorities | negative   | outcomes      | partnership     |
| philosophy | physical   | proportion    | published       |
| reaction   | registered | reliance      | removed         |
| scheme     | sequence   | sex           | shift           |
| specified  | sufficient | task          | technical       |
| techniques | technology | validity      | volume          |

1. Based on our purposefully designed _____________ for inclusion and exclusion, this study has identified 31 articles describing ERPP instructional programmes led by language teachers.

2. One might at this point pause and consider potential threats to the _____________ of our case study, other than its small-sized sample.

3. Due to time _____________, we did not focus on scaffolding the recommendations section, only providing students with some general instructions.

4. The majority of articles were _____________ in 2020, although a small number were _____________ in 2019.

5. The present study _____________ that the explicit teaching of language, informed by SFL, had a valuable impact on both teachers and learners.

| List 4: access   | adequate    | annual         | apparent      |
|------------------|-------------|----------------|---------------|
| approximated     | attitudes   | attributed     | civil         |
| code             | commitment  | communication  | concentration |
| conference       | contrast    | cycle          | debate        |
| despite          | dimensions  | domestic       | emerged       |
| error            | ethnic      | goals          | granted       |
| hence            | hypothesis  | implementation | implications  |
| imposed          | integration | internal       | investigation |
| job              | label       | mechanism      | obvious       |
| occupational     | option      | output         | overall       |
| parallel         | parameters  | phase          | predicted     |
| principal        | prior       | professional   | project       |
| promote          | regime      | resolution     | retained      |
| series           | statistics  | status         | stress        |
| subsequent       | sum         | summary        | undertaken    |

1. We then develop our hypothesis that short-term and immersive experiences… can influence generalised _____________ toward authority and justice in the larger society.

2. Our _____________ has several limitations. Our patient sample is small, and results may not be generalisable.

3. Citation is a _____________ to sustain knowledge and persuade readers into the reliability of the arguments presented.

4. In the present paper, therefore, we present such a review, focusing on the instructional initiatives _____________ by language teachers who typically work with EAL students or academics who wish to or need to publish.

5. The paper also discusses the _____________ of this research for genre theory and ESP instruction.

| List 5: academic   | adjustment   | alter        | amendment    |
|--------------------|--------------|--------------|--------------|
| aware              | capacity     | challenge    | clause       |
| compounds          | conflict     | consultation | contact      |
| decline            | discretion   | draft        | enable       |
| energy             | enforcement  | entities     | equivalent   |
| evolution          | expansion    | exposure     | external     |
| facilitate         | fundamental  | generated    | generation   |
| image              | liberal      | licence      | logic        |
| marginal           | medical      | mental       | modified     |
| monitoring         | network      | notion       | objective    |
| orientation        | perspective  | precise      | prime        |
| psychology         | pursue       | ratio        | rejected     |
| revenue            | stability    | styles       | substitution |
| sustainable        | symbolic     | target       | transition   |
| trend              | version      | welfare      | whereas      |

1. Many nursing students were well _____________ of patients' physical needs, so they initiated the dialogue for patient participation and provided patients with the space to talk about how they felt during the nursing task.

2. The primary _____________ of this study is to clarify which blood pressure (BP) measure is the best predictor of cardiovascular disease.

3. During this formative period, many educational systems (especially in Europe) saw _____________ 
changes in their social structures and institutional practices.

4. As COVID-19 batters the world and its economy, it's time to rethink _____________ pathways for our planet.

5. Human language _____________ us to refer to various aspects of communication itself.

| List 6: abstract   | accurate       | acknowledged   | aggregate    |
|--------------------|----------------|----------------|--------------|
| allocation         | assigned       | attached       | author       |
| bond               | brief          | capable        | cited        |
| cooperative        | discrimination | display        | diversity    |
| domain             | edition        | enhanced       | estate       |
| exceed             | expert         | explicit       | federal      |
| fees               | flexibility    | furthermore    | gender       |
| ignored            | incentive      | incidence      | incorporated |
| index              | inhibition     | initiatives    | input        |
| instructions       | intelligence   | interval       | lecture      |
| migration          | minimum        | ministry       | motivation   |
| neutral            | nevertheless   | overseas       | preceding    |
| presumption        | rational       | recovery       | revealed     |
| scope              | subsidiary     | tapes          | trace        |
| transformation     | transport      | underlying     | utility      |

1. In this system, articles in highly _____________ journals such as Science, Nature or Cell count for more than articles in journals whose content is _____________ less frequently.

2. This study set its _____________ on Japanese and English RAIs published in local (Japanese) and international (English) journals to explore the corpora produced for local Japanese and international audiences.

3. During the analysis, data were _____________ to different categories through a recursive induction-deduction process…
4. We would like to address this gap, fuelled by a number of _____________ research questions. 5. As indicated above, the significance of this research will be _____________ by taking into consideration the social and cultural dimensions of language teaching and coaching science.

| List 7: adaptation   | adults       | advocate   | aid           |
|----------------------|--------------|------------|---------------|
| channel              | chemical     | classical  | comprehensive |
| comprise             | confirmed    | contrary   | converted     |
| couple               | decades      | definite   | deny          |
| differentiation      | disposal     | dynamic    | eliminate     |
| empirical            | equipment    | extract    | file          |
| finite               | foundation   | global     | grade         |
| guarantee            | hierarchical | identical  | ideology      |
| inferred             | innovation   | insert     | intervention  |
| isolated             | media        | mode       | paradigm      |
| phenomenon           | priority     | prohibited | publication   |
| PAGE | 114           |              |            |               |

quotation release reverse simulation solely somewhat submitted successive survive thesis topic transmission ultimately unique visible voluntary

1. The Chemistry groups posted tweets to promote their research, to inform of new _____________ or of their academic activities and achievements, and to strengthen their disciplinary networks.

2. This investigation produced a _____________ (comprehensive) analysis of registers of student writing in the British system.

3. On the _____________, it means that on top of the great inter-national inequality in carbon emissions, there are also even greater emission inequalities between individuals within countries.

4. The appraisal system _____________ three subsystems: attitude (dealing with feelings, judgements of people, and appreciation of things); graduation (focusing on the amplification of attitudes); and engagement (indicating attitude sources).

5. _____________ to reduce greenhouse gas emissions strive to promote gender balance so that men and women have equal rights to participate in, and benefit from, decision-making about such 1. We resolved these _____________ by conducting more discussions until we achieved unanimous decisions.

2. A suggestion could be seen as an _____________ criticism.

| List 8: abandon   | accompanied   | accumulation   | ambiguous     |
|-------------------|---------------|----------------|---------------|
| appendix          | appreciation  | arbitrary      | automatically |
| bias              | chart         | clarity        | conformity    |
| commodity         | complement    | contemporary   | contradiction |
| crucial           | currency      | denote         | detected      |
| deviation         | displacement  | dramatic       | eventually    |
| exhibit           | exploitation  | fluctuations   | guidelines    |
| highlighted       | implicit      | induced        | inevitably    |
| infrastructure    | inspection    | intensity      | manipulation  |
| minimised         | nuclear       | offset         | paragraph     |
| plus              | practitioners | predominantly  | prospect      |
| radical           | random        | reinforced     | restore       |
| revision          | schedule      | tension        | termination   |
| theme             | thereby       | uniform        | vehicle       |
| via               | virtually     | widespread     | visual        |

3. Generally speaking, although business and leadership communication courses are _____________ 
in universities around the world, entire courses dedicated to financial communication are relatively less common.

4. The spread across texts was important given the wide variety of sub-disciplines within the field of mechanical engineering. Not having this spread across texts may have led to _____________ in the data in terms of some sub-disciplines being underrepresented or even omitted. 

5. A cognitively designed textbook focuses on the need for students to develop abilities based on active and conscious _____________ of ideas. 

| List 9: accommodation   | analogous   | anticipated   | assurance                            |
|-------------------------|-------------|---------------|--------------------------------------|
| attained                | behalf      | bulk          | ceases                               |
| coherence               | coincide    | commenced     | incompatible                         |
| concurrent              | confined    | controversy   | conversely                           |
| device                  | devoted     | diminished    | distorted/distortion - equal figures |
| duration                | erosion     | ethical       | format                               |
| founded                 | inherent    | insights      | integral                             |
| intermediate            | manual      | mature        | mediation                            |
| medium                  | military    | minimal       | mutual                               |
| norms                   | overlap     | passive       | portion                              |
| preliminary             | protocol    | qualitative   | refine                               |
| relaxed                 | restraints  | revolution    | rigid                                |
| route                   | scenario    | sphere        | subordinate                          |
| supplementary           | suspended   | team          | temporary                            |
| trigger                 | unified     | violation     | vision                               |

1. We are aware of the fact that there is much _____________ surrounding the concept of activity, for it can be examined in varying degrees.

2. Key questions in COVID-19 are the _____________ and determinants of infectious virus shedding. 3. Researchers and practitioners must continue to revise and _____________ the language we use to convey asset-based understandings of learners.

4. In this section, we first outline the key features of _____________ research, providing a background for the current project.

5. Overall, publications in international journals are highly preferred and have become 
_____________ to this research area.

| List 10: adjacent   | albeit   | assembly   | collapse   |
|---------------------|----------|------------|------------|
| colleagues          | compiled | conceived  | convinced  |

| depression   | encountered   | enormous    | forthcoming     |
|--------------|---------------|-------------|-----------------|
| inclination  | integrity     | intrinsic   | invoked         |
| levy         | likewise      | nonetheless | notwithstanding |
| odd          | ongoing       | panel       | persistent      |
| posed        | reluctant     | so-called   | straightforward |
| undergo      | whereby       |             |                 |

1. Not everyone, though, as mentioned above, is _____________ that what we are seeing online is not just old wine in new bottles.

2. A corpus was _____________ from the printed materials of each module. 3. The aim of the article was to show that literature is a tool of awareness and that it changes our perception of the world, _____________ it changes our personality and attitudes.

4. The _____________ discussion therefore reports on findings from a large-scale study involving 1,254 doctoral dissertations from a single Canadian research university.

5. _____________ databases do not necessarily allow scientists to solve long COVID mysteries, such as how well vaccination protects against the condition.

Source: http://www.victoria.ac.nz/lals/resources/academicwordlist/most-frequent Please read all of the words in the list.

Instructions
- If you know what the word means, put a star.

- If you are not sure what the word means, underline it. - If you have no idea what the word means, leave the word unmarked until you know what it means.

- After you have completed this task, check the meanings of the words that you do not know in a dictionary. 

To learn just grammar for academic writing is insufficient; we also need to learn about **collocations**. Collocation refers to the words that can be used with the target word. E.g. 

Draw a conclusion Make a conclusion

![49_image_0.png](49_image_0.png) Conduct a study Proceed a study

Do not always trust what you find on the internet (e.g. Yahoo Knowledge, or any online forum) because the information source has little credibility. There is no need to ask someone (a native speaker of English or an English teacher) either. Best solution: Use a corpus whenever we are unsure

![49_image_1.png](49_image_1.png)

1. **Just the Word** www.just-the-word.com (British English, free)
You can use **Just the Word** to choose the appropriate English words and expressions. It functions as both a thesaurus and a dictionary and is highly helpful for learning collocations. Entre in the word in the search box and hit combinations. Read through the results that come up. The clusters show words that are related in meaning. The unclustered words are not closely related to each other. You can click on the links to review example sentences.

![50_image_0.png](50_image_0.png)

![50_image_1.png](50_image_1.png)

Sketch Engine provides more functions and examples. First, sign up for a 30-day free trial account and log in. Then select "British National Corpus" under "Corpora" and select "Word Sketch" on the left-hand side panel. Enter the search term in the box labelled "study". Press "Go/show Word Sketch". You can then see the collocations of the search term sorted by grammatical function. Click ... and view real-life examples.

| examples.                |                         |                               |                    |        |            |          |          |
|--------------------------|-------------------------|-------------------------------|--------------------|--------|------------|----------|----------|
| 9                        | WORD SKETCH             | British National Corpus (BNC) | SUBSCRIBE          |        |            |          |          |
| study as noun 30,457×    | q                       | +                             |                    |        |            |          |          |
| ::: a x                  | ::: 0 x                 | t                             | :: a x             | t      | :: a x     | ::: 0, x | ::: 0, x |
| nouns and verbs          | verbs with "study" as   | verbs with "study" as         | "study" and/or     |        |            |          |          |
| modifiers of "study"     | prepositional phrases   |                               |                    |        |            |          |          |
| modified by "study"      | object                  | subject                       |                    |        |            |          |          |
| skill                    | undertake               | study                         |                    |        |            |          |          |
| case                     | .                       | ..                            | show               | .      | "study" of |          |          |
| o                        | case studies            | of study skills.              | studies have shown |        |            |          |          |
| conduct                  | management              |                               |                    |        |            |          |          |
| recent                   | protocol                | study conducted.              | suggest            | .      |            |          |          |
| o                        | :                       | management and busi
studies                               |                    |        |            |          |          |
| a recent study           | the study protocol was
approved by                         | studies suggest that          |                    |        |            |          |          |
| cmmission                |                         |                               |                    |        |            |          |          |
| detailed                 | indicate                | research                      |                    |        |            |          |          |
| a study commissioned by  | :                       |                               |                    |        |            |          |          |
| period                   |                         |                               |                    |        |            |          |          |
| detailed study of        | studies indicate        | patient                       | "study" in         |        |            |          |          |
| during the study period. | publish                 |                               |                    |        |            |          |          |
| .                        | previous                | study published               | examine            | survey |            |          |          |
| population               |                         |                               |                    |        |            |          |          |
| previous studies         | study examines the      |                               |                    |        |            |          |          |
| the study population     | design                  | analysis                      | from "study        |        |            |          |          |
| present                  | confirm                 |                               |                    |        |            |          |          |
| tour                     | study was designed to   | conclusion                    | "study" by         |        |            |          |          |
| In the present study     | randomise               | study confirms                |                    |        |            |          |          |
| study tour               |                         |                               |                    |        |            |          |          |
| feasibility              | in conclusion , this st |                               |                    |        |            |          |          |
| randomised study         | find                    | "study" on                    |                    |        |            |          |          |
| leave                    |                         |                               |                    |        |            |          |          |
| a feasibility study      | study found that        |                               |                    |        |            |          |          |
| study leave              | perform                 | project                       | by "study          |        |            |          |          |
| N                        | pilot                   | studies were perfor           | reveal             |        |            |          |          |
| group                    | work                    | on "study                     |                    |        |            |          |          |
| a pilot study            | bse                     | carry                         |                    |        |            |          |          |

Activity 2.9 Collocation Use the above online corpora to (1) identify the collocations of the following academic words, and (2) write one example in the spaces provided 1. evidence (n) (modifier of evidence) e.g. clear evidence 2. scope (n) (modifier of scope) e.g. considerable scope 3. analysis (n) (as the subject) e.g. collection and analysis of ….. 4. findings (modifier of findings) e.g. principal findings 5. study (n) (modifier of study) e.g. recent study 6. argument (n) (as an object of) e.g. support an argument 7. trend (n) (modifier of trend) e.g. a current trend 8. objective (adj) (modifies ….) e.g. an objective measure 9. controversial (adj) (modifies…..) e.g. a controversial issue 10. approach (adj) (modifier of approach) e.g. a systematic approach 

## Reporting Verbs

People do different things with words; when a writer says something, he/she may be arguing against an established theory and/or explaining his/her own point of view. We must learn enough reporting verbs to describe with greater precision what people mean when they say something. 

Watch this video for detail: https://www.youtube.com/watch?v=tUysEhMKC2E

![53_image_0.png](53_image_0.png)

Reporting verbs can be broadly divided into THREE types.

| 1.          | Verbs showing the purpose of speaking   |           |          |           |
|-------------|-----------------------------------------|-----------|----------|-----------|
| acknowledge | add                                     | admit     | advise   | agree     |
| allege      | announce                                | answer    | argue    | ask       |
| assert      | assure                                  | claim     | comment  | complain  |
| concede     | confirm                                 | contend   | continue | convince  |
| declare     | demand                                  | deny      | describe | discuss   |
| dispute     | enquire                                 | guarantee | hint     | imply     |
| inform      | insist                                  | maintain  | mention  | note      |
| object      | observe                                 | persuade  | predict  | proclaim  |
| promise     | propose                                 | reassure  | recall   | recommend |
| record      | refuse                                  | remark    | remind   | repeat    |
| reply       | report                                  | request   | respond  | reveal    |
| rule        | state                                   | stipulate | suggest  | tell      |
| urge        | warn                                    | write     |          |           |
| 2.          | Verbs of thinking and knowing           |           |          |           |
| accept      | agree                                   | assume    | believe  | consider  |
| doubt       | estimate                                | expect    | feel     | foresee   |
| guess       | hold                                    | judge     | know     | prefer    |
| reason      | reckon                                  | reflect   | resolve  | suppose   |
| think       | understand                              | want      | wish     | wonder    |
| worry       |                                         |           |          |           |

| realise   | see   |
|-----------|-------|

| 3.       | Verbs of learning and perceiving   |        |         |          |
|----------|------------------------------------|--------|---------|----------|
| conclude | discover                           | find   | gather  | infer    |
| learn    | note                               | notice | observe | perceive |

Sources: Leech, G., & Short, M. (1981). *Style in fiction*. Longman.

Sinclair, J. (1992). *Collins COBUILD English grammar*. HarperCollins.

## Implications Of Reporting Verbs

Reporting verbs may have the implied meaning from the author of the source text. When these reporting verbs are used within the context of the sentence, one can gain further insight into the author's true meaning. The APA style of in-text citations can use reporting verbs to effectively display the intentions of the authors through their implications. For example, if one uses the reporting verb 'to state' the implication would be that of simply the telling or saying of something with more or less a neutral tone. Here is a list of verbs that are similar to the reporting verbs 'say or tell' but have subtle differences in their implied meaning. The list of verbs below gives definitions to reporting verbs that commonly used when presenting facts, data or ideas to describe research. 

1. Add - One may want to say more about something present in the research. 2. Assert - One wants to say something strongly to support the research. 3. Assume - One wants to state something without proof. 4. Agree - One wants to approve of another's research or ideas. 5. Allege/claim - One reads the research results but is not totally sure if they are correct. 6. Complain - One would like to state that the idea or research is unfavorable. 7. Disclose - One would like to talk about an idea or research that was previously unknown. 8. Explain - One would like to say that the research or the idea is clear and novel. 9. Imply - The research is slightly vague but one can still understand the ideas or the research. 10. Indicate - The ideas can be understood through critical thought. 11. Insinuate - The research lacks enough evidence to be stated directly. 12. Mention - The idea is stated in fact while discussing other ideas or research. 13. Point out - The idea that is stated is more than likely true. 14. Reveal - The information or ideas from the research are not known. 15.Speculate - The idea does not have sufficient evidence so one can deduce the meaning.

Activity 2.10 Reporting Verbs Choose the reporting verb that would be the most suitable for the situation mentioned below.

1. You read about an idea in an article that seems to be new. The author of the article wanted to share the findings as they were quite unique. _____________________ 
2. You read some research where the author states ideas very strongly. _____________________ 3. In an article, the author mentions several theories and hypotheses. However, the claims are inconclusive so one can only guess what the results mean. _____________________ 
4. The author of one of the articles you read has many ideas that can only be understood as a whole. 5. The research does not have enough conclusive evidence to draw from so the author uses this word. _____________________ 
6. The authors of the article simply would like to let the readers know about something specific in their research. _____________________ 
7. The authors of the article write something to help the readers understand the research better. 8. The authors of the article want to place blame on someone or something, but they do not have definitive proof. _____________________ 
Source: Dent-Young, J. (1994). The language of English studies: A handbook for advanced students of English / John Dent-
Young (1st ed.). Chinese University Press.

Source: Hart, S. (2017). *Expand your English: A guide to improving your academic vocabulary*. Hong Kong University Press. 

https://doi.org/10.2307/j.ctt1zqrn4p.26 Note: 
Reporting verbs fit into different sentence patterns and some can fit into more than one.

# Structure 1: Reporting Verb + That + Main Idea

- Vally and D'Souza (2019) argue *that* social networking sites (SNSs) have dramatically revolutionised the way in which people communicate and interact with each other
- Anrijs et al. (2018) argue the undergoing a digital detox could likely exacerbate stress in individuals who may be using smartphones excessively and experience a strong feeling of distress. 

- Coyne et al. (2020) believe *that t*he use of social networking sites (SNSs) is now a normative part of Western adolescent development.

- Hartanto et al. (2021) point out that adolescents between 13 and 18 years of age are also vulnerable, with a 52% increase in the prevalence of depression in 2017.

- In research seeking to understand the prevalence of depression in modern society, Hartanto et al. (2021) claim that social media use is a key risk factor.

- Radtke et al. (2021) maintain *that u*nlike other electronic devices, smartphones enable the use of such functions almost anytime and anywhere, with numerous consequences for our daily lives.

- Turel et al. (2018) acknowledge *that* the concept of excessive SNS use, sometimes termed as SNS "addiction", has emerged as a potential disorder that merits research.

- Radtke et al. (2021) suggest *that* smartphone use can impair well-being, a trend that has become an issue of great concern to both the public and researchers.

## Structure 2: Reporting Verb + Preposition (As/To/For/With/Of)

- Turel et al. (2018) define technology as anything that could cause symptoms related to addiction.

- In his research, Radtke et al. (2021) defined 'digital detox' as a period of time in which a person reduces or all together stops using electronic devices.

- Vally and D'Souza (2019) argue for the great social capital and maintenance of relationships from using an electronic device.

- Coyne et al. (2019) disagree with Hartanto et al. (2021) in the view that social media use causes anxiety and depression.

- Anrijs et al. (2018) warn of increasing technostress becoming more pervasive.

# Structure 3: Reporting Verb + Noun (Noun Phrase)

- Anrijs et al. (2018) support the necessity to investigate the effects of digital detox and changes in stress levels.

- Coyne et al. (2019) discuss the positive effects of escapism and diversion from everyday life when using smartphones.

- Radtke et al (2022) identify the relationship between the use of electronic devices and mental health.

- In his discussion on child brides in Yemen, Lee (2011) highlights the role of government authorities and Islamic leaders in this growing problem.

- Turel (2018) validates the argument that Excessive SNS users are likely aware of the harm that their problematic state inflicts on their lives
- Vally and D'Souza (2019) applaud the given findings that prolonged abstinence from social media use may hold a range of potentially positive outcomes
- Hartanto et al. (2021) challenge the idea of regulated usage rather than complete abstinence being key to managing the psychological effects of social media.

Reporting verbs/signal phrases used in a literature review Rewrite the following sentences using the provided signal phrases or reporting verb. **Paraphrase** and include the correct in-text citation.

1. Although Radtke et al. (2021) state that digital detox is ubiquitous and, per its definition, an opportunity to reduce stress or focus on social interactions in the physical world, it remains unclear whether digital detox is an effective strategy to promote a healthy way of life in the digital era.

As observed by Radtke et al. (2021)
2. Vally and D' Souza (2019) assert that a brief period of abstinence will improve subjects' experience of well-being.

Vally and D'Souza (2019) argue 3. Coyne et al. (2020) argue that the vast majority of longitudinal research is very short in length, ranging from just a few months to two years.

Coyne et al. (2020) 
4. Turel et al. (2018) articulate the significant harm caused by excessive social networking site use.

Turel et al. (2018) state that 5. Coyne et al. (2019) and Anrijs et al. (2018) concur that the sample size included in the research on social media and mental health was limited.

Coyne et al. (2019) and Anrijs et al. (2018) 
6. Turel et al. (2018) and Hartanto et al. (2021) argue that stress reduction was inconclusive or caused by other factors.

Turel et al. (2018) and Haranto et al. (2012) 
7. As Hartanto et al. (2021) observe, some recent longitudinal studies have also shown that depressive symptoms may precede escalated social media use.

As Hartanto et al. (2021)
8. Turel et al. (2018) emphasise that future research should consider using both stress reduction measures, absolute and relative, while acknowledging that the relative change measure may be more conservative, as our manipulation and analysis did not reveal a difference.

Turel et al. (2018) 
9. In Anrijs et al.'s (2018) view, it is not clear whether coping strategies effectively decrease stress since it can also be argued that detoxing could lead to an increase in stress because of withdrawal-like symptoms and the loss of interconnectedness with other people.

In the view of Anrijs et al. (2018),
10. Coyne et al. (2019) test a causal model of associations between time spent on social media and mental health (anxiety and depression), using both between and within subjects analyses, over an 8-year-period of time, encompassing the transition between adolescence and emerging adulthood Coyne et al. (2019) 

![60_image_0.png](60_image_0.png)

Revising **the Paragraph** The authors of this academic journal did not use reporting verbs or signalling phrases in the construction of this paragraph. Now that you are well-versed in how reporting verbs and signalling phrases can be used to develop more readable sentences, please try to revise the paragraph to improve the flow with relevant reporting verbs. While you re-write this be sure to include a synthesis of ideas.

Note: You do NOT need to **paraphrase** but you do need to use reporting verbs and signalling phrases accurately.

Smartphones come with benefits, such as constant contact with friends, attractive leisure activities, Internet access to an endless supply of information, and positive consequences for knowledge sharing (Lepp et al., 2013; Omar et al., 2016). Conversely, smartphone use can impair well-being, a trend that has become an issue of great concern to both the public and researchers. For instance, research has shown that smartphone use affects health and well-being, performance, and social interactions. Regarding health related problems, studies have found that smartphone use is related to higher depression rates and anxiety (Lepp et al., 2014), sleep difficulties (Thomée, 2018), and also musculoskeletal problems in case of smartphone overuse (İnal et al., 2015). Furthermore, a predominance of empirical results indicates a negative association between smartphone use and academic performance (Amez & Baert, 2020), which corresponds with results showing that smartphone overuse is related to lower work productivity and engagement (e.g. Duke & Montag, 2017). Moreover, smartphone use also increases negative effect or stress and reduces the quality of interactions when individuals focus on their own smartphones during social interactions (so-called phubbing; McDaniel & Radesky, 2018; Nuñez et al., 2020). When you have completed adding reporting verbs and signal phrases, highlight the areas of a synthesis 

![61_image_0.png](61_image_0.png)

![61_image_1.png](61_image_1.png)

![61_image_2.png](61_image_2.png) of ideas.

Source: Radtke, T., Apel, T., Schenkel, K., Keller, J., & von Lindern, E. (2022). Digital detox: An effective solution in the smartphone era? A systematic literature review. *Mobile Media & Communication, 10*(2), 190–215. 

![61_image_3.png](61_image_3.png)

![61_image_4.png](61_image_4.png) https://doi.org/10.1177/20501579211028647

# Use Of Tenses In Academic Writing

| Present simple   |
|------------------|

| Present simple is the basic tense of most academic writing. Specifically, it is used: - To "frame" your paper: in your introduction, the present simple tense describes what  we already know about the topic; in the conclusion, it says what we now know about the topic  and what further research is still needed. - To make general statements, conclusions, or interpretations about previous research or data,  focusing on what is known now: e.g. The data suggest… The research shows… - To introduce evidence or support in the structure: e.g. There is evidence that…   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

- To show strong agreement with a conclusion or theory from a previous paper, but not specific findings or data:
e.g. Chan (2021) concludes that…

## Simple Past

| Simple past is used for two main functions in most academic fields: - To introduce other people's research into your text when you are describing a specific study,  usually carried out by named researchers. The research often provides an example that  supports a general statement or a finding in your research. For example,  The Aspect Hypothesis seems to be universal in suggesting that learners do tensemarking for verbs that are lexico-semantically more event-like (i.e. achievement, such as  shut the door) and accomplishment verbs (e.g. built a house), and then mark increasingly  less event-like verbs (i.e. activities, such as slept; and states, such as I knew it) in  stages…[General claim]  Tickoo (2001) involved secondary and university students in Hong Kong, and the Aspect  Hypothesis was examined. Findings showed that… - To describe the methods and data of your completed experiment. For example,  A questionnaire was administered…  A paired sample t-test and a one-way ANOVA were conducted to examine if participants  in different groups improved significantly from the pre-test to the post-test.  The participants were taught by three different teachers to avoid the Hawthorne  effect…   |
|---|

# Present Perfect Tense

The **present perfect** is mostly used for referring to previous research in the field. Since the present perfect is a *present* tense, it implies that the result is still true and relevant today. - The subject of active present perfect verbs is often general:
e.g. Researchers **have found**, Studies **have suggested**.

- The present perfect forms a connection between the past (previous research) and the present 
(your study). You tell readers what *has been* found and then how you will contribute to the field.

e.g. The effectiveness of Processing Instruction (PI) **has been demonstrated** in studies over the past 25 years involving at least 15 structures…[previous research] e.g. While the preceding studies may well give some insights into the challenges posed by English tense to Cantonese ESL learners, these studies **have probably ignored** the underlying representation of tense in the interlanguage grammars of Cantonese ESL learners. [gap]
- Passive voice is common in the present perfect tense to describe previous findings without referring directly to the original paper:
e.g. …has been studied; it has been reported that…
Adapted from: The Writing Center, University of North Carolina at Chapel Hill http://writingcenter.unc.edu/handouts/verb-tenses/ Examples are from this source: Chan, M. (2019). The role of classroom input: Processing instruction, traditional instruction, and implicit instruction in the acquisition of the English simple past by Cantonese ESL learners in Hong Kong. *System, 80*, 246-256. https://doi.org/10.1016/j.system.2018.12.003 There are no strict uses about what tense to use, but there are a number of factors to consider:

## 1. Presentness

You may want to refer to more recent references by using the present tense and references from older publications by using the past tense. e.g. Evans (1998) claimed that…
Chan (2020) suggests…

## 2. Generality

You may want to use the English simple present to indicate that the information or ideas you are reporting on are considered to be generally true. e.g. Chan (2020) considers that explicit instruction is effective in teaching English articles.

## 3. Level Of Support The Reference Offers For Your Own Argument

If the information or research findings you are reporting on do not support what you believe, you are most likely to use the English simple past. This way you refer to them as something strictly in the past and not necessarily 'true' at present.

## 4. Signal To The Reader To Expect Further Discussion Of The Topic

The present perfect tense can operate as a signal to the reader to expect further discussion of the topic (Swales, 1990, p.152), and to claim generality about past literature.

Use of three types of in-text citation in your Literature Review and Argumentative Research Paper

## Three Common Types Of In-Text Citation:

![64_Image_0.Png](64_Image_0.Png)

1. Integral (Author prominent): Verb controlling. The citation acts as the agent and controls a verb, in active or passive voice. For example, Kennedy et al. (2005) reported that parents who reject compulsory vaccination often feel that vaccines are not needed for their children and that their children can overcome infections without the aid of vaccines.

2. Integral (Author prominent): Naming. In naming citations, the citation is a noun phrase or a part of a noun phrase. For example, as indicated by/according to Kennedy et al. (2005), parents who reject compulsory vaccination often feel that vaccines are not needed for their children and that their children can overcome infections without the aid of vaccines.

3. Non-integral (Information prominent): Cite the author's name after the information or at the end of the sentence. For example, parents who reject compulsory vaccination often feel that vaccines are not needed for their children and that their 

## Use Of Secondary Citations

Use secondary sources sparingly, when the original work is out of print or unavailable through usual sources or you do not have access to the primary source. When you write a literature review or a research paper, you may come across an idea that is cited in a textbook but is not the original idea of the author whose book you are reading. In this situation, you will need to make a secondary citation. For example, if you read about Lee's idea in Crosth's book, you should adopt the following format of a secondary citation. According to Lee (as cited in Crosth, 2015), teachers should adopt a variety of teaching methods in the classroom.

Use of et al.

et al. is Latin for 'and others'. If an article is written by 3 or more authors, you should provide the surname of only the first author plus "et al." in every citation, including the first citation. For example, Lee et al. (2005) highlight that leadership style has a major impact on the morale of staff.

In-text citation practice Write the correct in-text citation. The first one has been completed for you.

1. Article Title: Abstinence from social media use, subjective well‐being, stress, and loneliness Author: Zahir Vally and Caroline G. D'Souza Publication: Perspectives in Psychiatric Care Volume number: 55 Issue: 4 Date: July 27,2019 Pages: 752-759 Integral (Author prominent: Naming): According to Vally and D'Souza (2019) Integral (Author prominent: Verb controlling): Vally and D'Souza (2019) argue Non-integral (Information prominent): … (Vally & D'Souza, 2019). 2. Article Title: Short abstinence from online social networking sites reduces perceived stress, especially in excessive users Authors: Ofir Turel, Daniel R. Cavagnaro, Dar Meshi Publication: Psychiatry Research Volume number: 270 Date: November 9th, 2018 Pages: 947-953 Integral (Author prominent: Naming): Integral (Author prominent: Verb controlling): Non-integral (Information prominent): 
For more details, please refer to OWL Purdue Online Writing Lab 

![66_image_0.png](66_image_0.png) https://owl.purdue.edu/owl/research_and_citation/apa_style/apa_formatting_and_style_gui de/reference_list_basic_rules.html Use the two sources to create a reference list in the box below:

![67_image_0.png](67_image_0.png)

End-of-the-unit survey This is the end of Unit 2. Please complete the following survey to measure your knowledge.

Read each statement and tick the appropriate box. Please tick your level of understanding on the Likert scale of 1 to 5.

![67_image_1.png](67_image_1.png)

![67_image_2.png](67_image_2.png)

Good - 4 Fair - 2 Poor - 1

| Statement                                                                                                                                                                                                        | 5   | 4   | 3   | 2   | 1   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|-----|-----|-----|-----|
| Academic Writing Skills                                                                                                                                                                                          |     |     |     |     |     |
| Avoiding plagiarism Quoting Paraphrasing and summarising Synthesising Using specific academic language for  literature reviews Understanding academic word lists Using reporting verbs Writing in-text citations |     |     |     |     |     |

# Self-Learning Online Resources For Unit 2

Hong Kong Polytechnic University: Synthesis Writing

![68_image_0.png](68_image_0.png) http://elc.polyu.edu.hk/CILL/eap/synthesis.aspx On this site, students can learn the specifics of synthesis writing. Students can also work on a number of exercises to test their synthesising abilities. Online Writing Workshop Purdue University: Synthesis Writing

![68_image_1.png](68_image_1.png) https://owl.excelsior.edu/orc/what-to-do-afterreading/synthesizing/synthesizing-activity-1/

## Grammar

![68_Image_2.Png](68_Image_2.Png)

https://owl.purdue.edu/owl/general_writing/grammar/index.html This website provides detailed explanations of various grammar topics. Students can also check their understanding by working on various grammar-related exercises. Hong Kong Polytechnic University: Grammar

![68_image_3.png](68_image_3.png) http://elc.polyu.edu.hk/cill/grammar This website provides explanations and practice exercises on various grammatical structures. Paraphrasing and Quoting and Summarising - **Purdue University Online** 

![68_image_4.png](68_image_4.png) writing workshop https://owl.purdue.edu/owl/research_and_citation/using_research /quoting_paraphrasing_and_summarizing/index.html This website gives information on avoiding plagiarism by paraphrasing, quoting and summarising with examples and exercises. Academic Phrasebank from the University of Manchester

![68_image_5.png](68_image_5.png) https://www.phrasebank.manchester.ac.uk/referring-to-sources/ This website has myriad words and phrases. In other words, a plethora of vocabulary words one will need to write academic texts. Academic word lists 

![68_image_6.png](68_image_6.png) http://www.uefap.com/vocab/select/awl.htm This is the full resource for the academic word list. One should know all of them for academic work. Verbs for reporting

![69_image_0.png](69_image_0.png) https://www.adelaide.edu.au/writingcentre/sites/default/files/ docs/learningguide-verbsforreporting.pdf A very quick and good list of reporting verbs to help with variety and accuracy in writing academic texts. Scribbr - **A quick guide for APA 7th edition** 

![69_image_1.png](69_image_1.png) https://www.scribbr.com/apa-style/apa-seventh-edition-changes/ A very useful website for speedy APA formatting questions. 

# References

Bailey, S. (2011). Academic writing: A handbook for international students (3rd *ed.)*. Routledge. Bashir, H., & Bhat, S. (2016). Effects of social media on mental health: A review. The International Journal of Indian Psychology, 4, 125-131. https://doi.org/10.25215/0403.134 Bolton, K. (2009). Culture of confidence, not of complaint: Encouraging proficiency in English. *Youth Hong Kong*, 11-15.

Carr, N. (2010, June 5). Does the Internet make you dumber? *The Wall Street Journal.*
https://www.wsj.com/articles/SB100014240527487040253045752849816447900 98 Chan, M. (2019). The role of classroom input: Processing instruction, traditional instruction, and implicit instruction in the acquisition of the English simple past by Cantonese ESL learners in Hong Kong. *System, 80*, 246-256. https://doi.org/10.1016/j.system.2018.12.003 Clinton, P. (2013, October 15). Manned Mars flight: Impossible dream? *Space Science*,
16-18.

ELC, The Hong Kong Polytechnic University. (23 March 2012). *Synthesis*. 

https://elc.polyu.edu.hk/CILL/eap/synthesis.aspx Englishing. (10 Apr 2020). ESL writing - *summarizing and paraphrasing*. [Video]. YouTube. 

https://www.youtube.com/watch?v=PigfCpCg15c Epipheo. (2013, May 6). *What the internet is doing to our brains?* [Video]. YouTube. 

https://www.youtube.com/watch?v=cKaWJ72x1rI
Evans, S. (2010). Business as usual: The use of English in the professional world in Hong Kong. *English for Specific Purposes*, 29(3), 153–167.

https://doi.org/10.1016/j.esp.2009.11.005 Hamp-Lyons, L., & Courter, K. (1984). *Research matters.* Rowley. Newbury House. Hasman, M. (2001). The role of English in the 21st Century. English Teaching Forum Online, 39(1), 1-2.

Jacota, L. (2009). English: Using it or losing it? *Youth Hong Kong,* 4-7. Jamaludin, K.A., Alias, N., & DeWitt, D. (2015). Research and trends in the studies of homeschooling practices: A review on selected journals. Turkish Online Journal of Educational Technology, 14, 111-119.

Johnson, D. W., & Johnson, R. T. (2009). An educational psychology success story: Social interdependence theory and cooperative learning. *Educational Researcher, 38*(5), 365–379. https://doi.org/10.3102/0013189X09339057 LearnEnglish. (2012, Sep 12). *MOOCs are moving forward.* LearnEnglish with KT. (2016, Sep 27). Reporting verbs - *English grammar lesson.* [Video]. 

YouTube. https://www.youtube.com/watch?v=tUysEhMKC2E
Leech, G., & Short, M. (1981). *Style in fiction*. Longman. Lundstrom, K., Diekema, A. R., Leary, H., Haderlie, S., & Holliday, W. (2015). Teaching and learning information synthesis: An intervention and rubric based assessment. 

Communications in Information Literacy, 9 (1), 60-82.

https://doi.org/10.15760/comminfolit.2015.9.1.176 Oshima, A., & Hogue, A. (2006). Writing academic English: The Longman academic writing series, level 4 (4th ed.). Pearson Longman.

Raymond, S. & Nickerson (1999). How we know and sometimes misjudge what others know: Imputing one's own knowledge to others. *Psychological Bulletin, 125*(6), 737.

Sinclair, J. (1992). *Collins COBUILD English grammar*. HarperCollins. Scribbr. (2019, Oct 31). *How to paraphrase in 5 easy steps.* [Video]. YouTube. 

https://www.youtube.com/watch?v=oiM0x0ApVL8 Spivey, N. (1989). Constructing constructivism reading research in the United States. 

Occasional Paper, 12. Carnegie Mellon.

Swales, J. (1990). *Genre analysis. English in academic and research settings.* Cambridge University Press.